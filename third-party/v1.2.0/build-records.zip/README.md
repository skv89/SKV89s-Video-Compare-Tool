# Third-party build records — Video Compare v1.2.0

This archive supplies matching multimedia package build records, recipes, original lockfiles and source mappings. It is not an application download and contains no private Video Compare source.

## Source downloads and licenses

The [complete source index and distribution terms](https://github.com/skv89/SKV89s-Video-Compare-Tool/blob/v1.2.0/third-party/v1.2.0/README.md) provide the exact corresponding source downloads, checksums, original license information, and dependency replacement instructions.

- [MSYS2 source downloads](https://github.com/skv89/SKV89s-Video-Compare-Tool/blob/v1.2.0/third-party/v1.2.0/MSYS2_SOURCES.md)
- [Rust source downloads](https://github.com/skv89/SKV89s-Video-Compare-Tool/blob/v1.2.0/third-party/v1.2.0/RUST_SOURCES.md)
- `SOURCE_INDEX.json` in this archive contains the same exact URLs, versions, hashes and dependency mappings in machine-readable form. Source payloads are downloaded separately from those URLs.

## Included records

- `package-records/`: the 106 bundled binary packages' original `.BUILDINFO` / `.PKGINFO` and readable source recipes.
- `cargo-locks/`: original source Cargo lockfiles.
- `rust-adjustment/`: official registry index snapshots for the recorded librsvg preparation adjustment.
- `recipe-correspondence.json`: source recipes compared with each binary's recorded recipe hash.
- `runtime-closure.json`, `candidate-runtime-files.json`, `RUNTIME_FILES.json`: exact package/file correspondence.
- `license-grant-evidence.json`: original grant excerpts for ambiguous catalog labels, identified by source archive, member and hash.
- `FILES.json`: the complete archive file/hash inventory (excluding itself).

Use Windows MSYS2 UCRT64 and each source package's PKGBUILD plus the dependency versions recorded in `.BUILDINFO`. Recipes contain patches, configuration/compiler options and install commands. The source index explains building and replacing compatible dependencies. No installed MSYS2 environment or general build tools are included here.

The librsvg 2.63.4-1 recipe runs `cargo update -p windows-sys@0.61.2 --precise 0.60.2` before its frozen build. The historical post-prepare lockfile was not recovered. The original lock, exact recipe/patch, recorded environment and checksum-verified compatible source superset are supplied or directly linked. No exact historical 0.53.x patch choice or byte-identical rebuild is claimed.
