# Maintainer: wirx6 <wirx654@gmail.com>

_realname=aom
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=3.15.2
pkgrel=1
pkgdesc='AV1 codec library (mingw-w64)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://aomedia.org/"
msys2_repository_url="https://aomedia.googlesource.com/aom"
msys2_changelog_url="https://aomedia.googlesource.com/aom/+/refs/heads/main/CHANGELOG"
msys2_references=(
  "archlinux: aom"
  "cygwin: aom"
  "gentoo: media-libs/libaom"
  "cpe: cpe:/a:aomedia:aomedia"
)
msys2_ignore_vulnerabilities=(
  "CVE-2021-30475" # fixed since 3.1.0
  "CVE-2021-30474" # fixed since 3.1.0
  "CVE-2021-30473" # fixed since 3.1.0
)
license=('spdx:BSD-2-Clause')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-libwinpthread")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-git"
             $([[ "${CARCH}" == "aarch64" ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm")
             "${MINGW_PACKAGE_PREFIX}-perl"
             "${MINGW_PACKAGE_PREFIX}-python")
source=("https://storage.googleapis.com/aom-releases/libaom-${pkgver}.tar.gz"{,.asc})
sha256sums=('67bb54b245f33ed98600e08269e6139986e48114e14042474ddd8885801dfddc'
            'SKIP')
validpgpkeys=('B002F08B74A148DAA01F7123A48E86DB0B830498') # AOMedia release signing key <av1-discuss@aomedia.org>

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DENABLE_EXAMPLES=OFF \
      -DENABLE_TESTS=OFF \
      -S "libaom-${pkgver}" \
      -B "build-${MSYSTEM}"

  ${MINGW_PREFIX}/bin/cmake --build "build-${MSYSTEM}"
}

package() {
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install "build-${MSYSTEM}"

  install -Dm644 "${srcdir}"/libaom-${pkgver}/LICENSE "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
  install -Dm644 "${srcdir}"/libaom-${pkgver}/PATENTS "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/PATENTS
}
