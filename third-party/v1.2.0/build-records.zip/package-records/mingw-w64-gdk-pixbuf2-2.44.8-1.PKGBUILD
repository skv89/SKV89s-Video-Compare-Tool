# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Maintainer: Ray Donnelly <mingw.android@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=gdk-pixbuf2
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-docs")
pkgver=2.44.8
pkgrel=1
pkgdesc="An image loading library (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://gitlab.gnome.org/GNOME/gdk-pixbuf"
msys2_repository_url='https://gitlab.gnome.org/GNOME/gdk-pixbuf'
msys2_references=(
  "cpe: cpe:/a:gnome:gdk-pixbuf"
  "cpe: cpe:/a:gnome:gdkpixbuf"
)
license=('spdx:LGPL-2.1-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-gettext-runtime"
         "${MINGW_PACKAGE_PREFIX}-glib2"
         "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
         "${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-libtiff")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-gobject-introspection"
             "${MINGW_PACKAGE_PREFIX}-gettext-tools"
             "${MINGW_PACKAGE_PREFIX}-gi-docgen"
             "${MINGW_PACKAGE_PREFIX}-python-docutils")
optdepends=("${MINGW_PACKAGE_PREFIX}-libwmf: Load .wmf and .apm"
            "${MINGW_PACKAGE_PREFIX}-libavif: Load .avif"
            "${MINGW_PACKAGE_PREFIX}-libheif: Load .heif, .heic, and .avif"
            "${MINGW_PACKAGE_PREFIX}-libjxl: Load .jxl"
            "${MINGW_PACKAGE_PREFIX}-librsvg: Load .svg, .svgz, and .svg.gz"
            "${MINGW_PACKAGE_PREFIX}-webp-pixbuf-loader: Load .webp")
install=${_realname}-${MSYSTEM}.install
source=("https://download.gnome.org/sources/gdk-pixbuf/${pkgver%.*}/gdk-pixbuf-${pkgver}.tar.xz"
        0003-fix-dllmain.patch
        0004-build-all-loaders-plus-gdi.patch
        fix-missing-meson-dep.patch
        gdk-pixbuf-query-loaders.hook.in)
noextract=("gdk-pixbuf-${pkgver}.tar.xz")
sha256sums=('919f529512961a12e81cd4b4b466a48c3933469e7f9a310c6513cd4fb252ba3c'
            '21bd9b2ba1447267c84f1b445cbcf50c62299254856c1c227cc7ba4babc9f27e'
            'f265628da99c0bc2a9a9a40a27d7ea0b8b783bf38200c14ee8db4ed879facbec'
            'c7a0e09fd611a6de0ed91348ba6776ad5c2c4fee4d834c61628318a374bc9318'
            '6277c30e763c7889a3446e2ce8c7b8dbe7212678497b2905582de8159831e3fb')

_apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -p1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}"/
  tar --exclude tests/test-images/reftests/tga -xf "gdk-pixbuf-${pkgver}.tar.xz"
  cd "${srcdir}"/gdk-pixbuf-${pkgver}

  _apply_patch_with_msg \
    0003-fix-dllmain.patch \
    fix-missing-meson-dep.patch

  # build all loaders + all gdi loaders static and just don't register
  # the gdi loaders we don't need so the external ones get used
  # (everything except wmf/emf atm)
  _apply_patch_with_msg 0004-build-all-loaders-plus-gdi.patch
}

build() {
  local -a _static_flags=(
    -DGIO_STATIC_COMPILATION
    -DGLIB_STATIC_COMPILATION
    -DGMODULE_STATIC_COMPILATION
    -DGOBJECT_STATIC_COMPILATION
  )

  local -a _meson_options=(
    --prefix=${MINGW_PREFIX}
    --wrap-mode=nodownload
    --auto-features=enabled
    --buildtype=plain
    -Dinstalled_tests=false
    -Drelocatable=true
    -Dnative_windows_loaders=true
    -Dglycin=disabled
    -Dandroid=disabled
    -Dothers=enabled
  )

  # Does not enable DLL_EXPORT, keeps DllMain far away (#17643)
  # gir disabled. ERROR: can't resolve libraries to shared libraries
  CFLAGS+=" ${_static_flags[@]}" \
  CXXFLAGS+=" ${_static_flags[@]}" \
  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    "${_meson_options[@]}" \
    --default-library=static \
    -Dbuiltin_loaders=windows \
    -Ddocumentation=false \
    -Dintrospection=disabled \
    "gdk-pixbuf-${pkgver}" \
    "build-${MSYSTEM}-static"

  ${MINGW_PREFIX}/bin/meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    "${_meson_options[@]}" \
    --default-library=shared \
    -Dbuiltin_loaders=all \
    -Ddocumentation=true \
    "gdk-pixbuf-${pkgver}" \
    "build-${MSYSTEM}-shared"

  ${MINGW_PREFIX}/bin/meson compile -C "build-${MSYSTEM}-shared"
}

package_gdk-pixbuf2() {
  ${MINGW_PREFIX}/bin/meson install -C "${srcdir}/build-${MSYSTEM}-static" --destdir "${pkgdir}"
  ${MINGW_PREFIX}/bin/meson install -C "${srcdir}/build-${MSYSTEM}-shared" --destdir "${pkgdir}"

  for hook in gdk-pixbuf-query-loaders; do
    local hook_path="${srcdir}/${MINGW_PACKAGE_PREFIX}-${hook}.hook";
    cp "${srcdir}/${hook}.hook.in" "${hook_path}"
    sed -s "s|@MINGW_HOOK_TARGET_PREFIX@|${MINGW_PREFIX:1}|g" -i "${hook_path}"
    sed -s "s|@MINGW_PREFIX@|${MINGW_PREFIX}|g" -i "${hook_path}"
    install -Dt "$pkgdir/usr/share/libalpm/hooks" -m644 "${hook_path}"
  done

  mkdir -p dest${MINGW_PREFIX}/share
  mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share/doc

  install -Dm644 "${srcdir}/gdk-pixbuf-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}

package_gdk-pixbuf2-docs() {
  pkgdesc+=" (documentation)"
  depends=()
  optdepends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
