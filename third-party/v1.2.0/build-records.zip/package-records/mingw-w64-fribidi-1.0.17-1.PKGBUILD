# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=fribidi
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.0.17
pkgrel=1
pkgdesc="A Free Implementation of the Unicode Bidirectional Algorithm (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:LGPL-2.1-or-later')
url="https://github.com/fribidi/fribidi"
msys2_repository_url='https://github.com/fribidi/fribidi'
msys2_references=(
  "cpe: cpe:/a:gnu:fribidi"
)
depends=()
makedepends=("${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("${msys2_repository_url}/releases/download/v${pkgver}/fribidi-${pkgver}.tar.xz")
sha256sums=('6949dcde27d41cebad1fd741fcafc36d55a1020d2d872d4a6eb3914caabbada2')

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson.exe setup \
      --prefix=${MINGW_PREFIX} \
      --buildtype plain \
      --prefix=${MINGW_PREFIX} \
       -Ddocs=false \
       --default-library static \
       build-${MSYSTEM}-static \
      ${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/meson.exe compile -C build-${MSYSTEM}-static

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson.exe setup \
      --prefix=${MINGW_PREFIX} \
      --buildtype plain \
      --prefix=${MINGW_PREFIX} \
       -Ddocs=false \
       --default-library shared \
       build-${MSYSTEM}-shared \
      ${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/meson.exe compile -C build-${MSYSTEM}-shared
}

check() {
  meson test -C build-${MSYSTEM}-static
  meson test -C build-${MSYSTEM}-shared
}

package() {
  meson install -C build-${MSYSTEM}-static --destdir="${pkgdir}"
  meson install -C build-${MSYSTEM}-shared --destdir="${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
