# Maintainer: Some One <some.one@some.email.com>

_realname=vid.stab
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.1.2
pkgrel=1
pkgdesc="Video stabilization library (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='http://public.hronopik.de/vid.stab'
msys2_repository_url='https://github.com/georgmartius/vid.stab'
license=('spdx:GPL-2.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-omp")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "git")
_hash='2d82492533bf5004bc2c4f8213a1b622c45f6a44'
source=(""vid.stab-${pkgver}::git+https://github.com/georgmartius/vid.stab.git#commit=${_hash}""
        "0001-OpenMP.patch"
        "0002-disable-sse-on-arm.patch")
sha256sums=('fa083365228201372c1728f502c12ba1b6183f0d0e5571061925cf6d530080c2'
            '902d237a2cbdbec032379a2b23ba3abd0bd4f4455169c7c4994edbaf5137e1f5'
            'c11232d1dad550363f1d69137e2ddfb7f159c8ba86040e65dc376bd757d58ca7')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _fname in "$@"
  do
    msg2 "Applying ${_fname}"
    patch -Nbp1 -i "${srcdir}"/${_fname}
  done
}

prepare() {
  cd "$srcdir"/${_realname}-${pkgver}

  apply_patch_with_msg \
    0001-OpenMP.patch \
    0002-disable-sse-on-arm.patch
}

build() {
  cd "$srcdir"/${_realname}-${pkgver}

  msg2 "Building shared library"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-shared && cd "${srcdir}"/build-${MSYSTEM}-shared

  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      ../${_realname}-${pkgver}

  cmake --build .


  msg2 "Building static library"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-static && cd "${srcdir}"/build-${MSYSTEM}-static

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      ../${_realname}-${pkgver}

  cmake --build .
}

#check() {
#  cd "${srcdir}"/build-${MSYSTEM}-shared
#  make check
#}

package() {
  msg2 "Installing static library"
  cd "${srcdir}"/build-${MSYSTEM}-static
  DESTDIR="${pkgdir}" cmake --install .

  msg2 "Installing shared library"
  cd "${srcdir}"/build-${MSYSTEM}-shared
  DESTDIR="${pkgdir}" cmake --install .

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
