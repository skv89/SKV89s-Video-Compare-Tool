# Maintainer: kasper93 <kasper93@gmail.com>

_realname=glad
pkgbase=mingw-w64-python-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-python-${_realname}"
pkgver=2.0.8
pkgrel=3
pkgdesc='Multi-Language Vulkan/GL/GLES/EGL/GLX/WGL Loader-Generator based on the official specs (mingw-w64)'
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/Dav1dde/glad'
msys2_references=(
  'purl: pkg:pypi/glad2'
)
license=('spdx:MIT')
depends=("${MINGW_PACKAGE_PREFIX}-python"
         "${MINGW_PACKAGE_PREFIX}-python-jinja")
makedepends=("${MINGW_PACKAGE_PREFIX}-python-build"
             "${MINGW_PACKAGE_PREFIX}-python-installer"
             "${MINGW_PACKAGE_PREFIX}-python-setuptools")
options=('!strip')
source=(${url}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz)
sha256sums=('44f06f9195427c7017f5028d0894f57eb216b0a8f7c4eda7ce883732aeb2d0fc')

build() {
  cd "${srcdir}"
  cp -r "${_realname}-${pkgver}" "python-build-${MSYSTEM}" && cd "python-build-${MSYSTEM}"

  "${MINGW_PREFIX}"/bin/python -m build --wheel --skip-dependency-check --no-isolation
}

package() {
  cd "${srcdir}/python-build-${MSYSTEM}"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    ${MINGW_PREFIX}/bin/python -m installer --prefix=${MINGW_PREFIX} \
    --destdir="${pkgdir}" dist/*.whl

  install -Dm644 LICENSE -t "${pkgdir}${MINGW_PREFIX}/share/licenses/$_realname/"
  install -Dm644 README.md -t "${pkgdir}${MINGW_PREFIX}/share/doc/$_realname/"
}
