# Maintainer: Miloš Komarčević <miloskomarcevic@aim.com>

_realname=lerc
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=4.1.1
pkgrel=1
pkgdesc="Limited Error Raster Compression library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/Esri/lerc"
msys2_repository_url='https://github.com/Esri/lerc'
msys2_references=(
  'purl: pkg:github/esri/lerc'
)
license=('spdx:Apache-2.0')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=("${url}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('fe2860e10635166cd9f2144e429ec6b870d471e9957f5812ba2da0973770b022')

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-static"

  cmake --build "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-shared"

  cmake --build "build-${MSYSTEM}-shared"
}

package() {
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-static"

  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-shared"

  install -Dm644 "${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
