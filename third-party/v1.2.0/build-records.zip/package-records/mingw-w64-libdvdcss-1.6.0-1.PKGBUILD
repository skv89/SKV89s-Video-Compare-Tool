# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libdvdcss
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.6.0
pkgrel=1
pkgdesc="Portable abstraction library for DVD decryption (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.videolan.org/developers/libdvdcss.html"
msys2_repository_url="https://code.videolan.org/videolan/libdvdcss"
license=("spdx:GPL-2.0-or-later")
makedepends=("${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-cc")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
source=("https://code.videolan.org/videolan/libdvdcss/-/archive/${pkgver}/libdvdcss-${pkgver}.tar.gz")
sha256sums=('3c5596b845c867095bee3fe693f643d95278c1a1d0c49be61aff950e3fafa81a')

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      "build-${MSYSTEM}" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package() {
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
