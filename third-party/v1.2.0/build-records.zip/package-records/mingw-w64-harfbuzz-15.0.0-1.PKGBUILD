# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=harfbuzz
pkgbase="mingw-w64-${_realname}"
pkgname=(
  "${MINGW_PACKAGE_PREFIX}-${_realname}"
  $([[ ${CARCH} == i686 ]] || echo \
    "${MINGW_PACKAGE_PREFIX}-${_realname}-cairo" \
    "${MINGW_PACKAGE_PREFIX}-${_realname}-icu" \
    "${MINGW_PACKAGE_PREFIX}-${_realname}-utils" \
    "${MINGW_PACKAGE_PREFIX}-${_realname}-docs")
)
pkgver=15.0.0
pkgrel=1
pkgdesc="OpenType text shaping engine (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://harfbuzz.github.io/'
msys2_repository_url='https://github.com/harfbuzz/harfbuzz/'
msys2_changelog_url='https://github.com/harfbuzz/harfbuzz/blob/main/NEWS'
msys2_references=(
  "archlinux: harfbuzz"
  "cpe: cpe:/a:harfbuzz_project:harfbuzz"
)
license=('spdx:MIT')
depends=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  "${MINGW_PACKAGE_PREFIX}-freetype"
  "${MINGW_PACKAGE_PREFIX}-glib2"
  "${MINGW_PACKAGE_PREFIX}-graphite2"
  "${MINGW_PACKAGE_PREFIX}-libpng"
  "${MINGW_PACKAGE_PREFIX}-zlib"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-gobject-introspection"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
  "${MINGW_PACKAGE_PREFIX}-python"
  "${MINGW_PACKAGE_PREFIX}-ragel"
  $([[ ${CARCH} == i686 ]] || echo \
    "${MINGW_PACKAGE_PREFIX}-cairo" \
    "${MINGW_PACKAGE_PREFIX}-chafa" \
    "${MINGW_PACKAGE_PREFIX}-gtk-doc" \
    "${MINGW_PACKAGE_PREFIX}-icu")
)
checkdepends=(
  "${MINGW_PACKAGE_PREFIX}-python-fonttools"
  "${MINGW_PACKAGE_PREFIX}-python-setuptools"
)
source=(
  "https://github.com/harfbuzz/harfbuzz/releases/download/${pkgver}/${_realname}-${pkgver}.tar.xz"
  "001-fix-build-with-chafa.patch"
  "002-make-library-type-in-cmake-config-unknown.patch"
)
noextract=("${_realname}-${pkgver}.tar.xz")
sha256sums=('968536e9abd782f07f7954044c0c4020199fcdd39b41d221ec42d2a3be4a44df'
            '26b37a1ca9872973905ecb96bcbe3f054472252320956faa74428206900d360e'
            '189dc3cb2f9a0fd07d6499cee3307985f68e6b9d28d581d15c365b33f2012552')

prepare() {
  echo "Extracting ${_realname}-${pkgver}.tar.xz..."
  tar -xJf "${_realname}-${pkgver}.tar.xz" || true

  cd "${_realname}-${pkgver}"
  patch -Np1 -i "${srcdir}/001-fix-build-with-chafa.patch"
  patch -Np1 -i "${srcdir}/002-make-library-type-in-cmake-config-unknown.patch"
}

build() {
  local -a _static_flags=(
    -DGIO_STATIC_COMPILATION
    -DGLIB_STATIC_COMPILATION
    -DGMODULE_STATIC_COMPILATION
    -DGOBJECT_STATIC_COMPILATION
    -DGRAPHITE2_STATIC
    -DCAIRO_WIN32_STATIC_BUILD
  )

  declare -a _meson_opts=(
    --prefix="${MINGW_PREFIX}"
    --buildtype=plain
    --wrap-mode=nofallback
    -Dauto_features=enabled
    -Dgobject=enabled
    -Dgraphite2=enabled
    -Dgdi=enabled
    -Ddirectwrite=enabled
    -Dtests=disabled
    -Dgpu=disabled
  )

  if [[ ${CARCH} != i686 ]]; then
    _meson_opts+=(
      "-Dchafa=enabled"
      "-Dcairo=enabled"
      "-Dicu=enabled"
      "-Ddocs=enabled"
      "-Dutilities=enabled"
    )
  else
    _meson_opts+=(
      "-Dchafa=disabled"
      "-Dcairo=disabled"
      "-Dicu=disabled"
      "-Ddocs=disabled"
      "-Dutilities=disabled"
    )
  fi

  CFLAGS+=" ${_static_flags[@]}" \
    CXXFLAGS+=" ${_static_flags[@]}" \
    MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
    --default-library=static \
    -Dintrospection=disabled \
    "${_meson_opts[@]}" \
    "build-${MSYSTEM}-static" \
    "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
    --default-library=shared \
    -Dintrospection=enabled \
    "${_meson_opts[@]}" \
    "build-${MSYSTEM}-shared" \
    "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-shared"
}

check() {
  cd "build-${MSYSTEM}-shared"

  meson setup -Dtests=enabled "${srcdir}/${_realname}-${pkgver}"
  meson compile
  meson test
}

package_harfbuzz() {
  pkgdesc+=" (mingw-w64)"

  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"

  meson install -C "build-${MSYSTEM}-shared" --destdir "${pkgdir}"

  if [[ ${CARCH} != i686 ]]; then

  mkdir -p "${srcdir}/dest-docs${MINGW_PREFIX}/share"
  mv "${pkgdir}${MINGW_PREFIX}/share/gtk-doc" "${srcdir}/dest-docs${MINGW_PREFIX}/share/gtk-doc"

  mkdir -p "${srcdir}/dest-utils${MINGW_PREFIX}/bin"
  mv "${pkgdir}${MINGW_PREFIX}"/bin/*.exe "${srcdir}/dest-utils${MINGW_PREFIX}/bin/"

  mkdir -p "${srcdir}/dest-cairo${MINGW_PREFIX}/bin"
  mkdir -p "${srcdir}/dest-cairo${MINGW_PREFIX}/include/harfbuzz/"
  mkdir -p "${srcdir}/dest-cairo${MINGW_PREFIX}/lib/pkgconfig"
  mv "${pkgdir}${MINGW_PREFIX}"/bin/libharfbuzz-cairo*.dll "${srcdir}/dest-cairo${MINGW_PREFIX}/bin/"
  mv "${pkgdir}${MINGW_PREFIX}"/include/harfbuzz/hb-cairo.h "${srcdir}/dest-cairo${MINGW_PREFIX}/include/harfbuzz/"
  mv "${pkgdir}${MINGW_PREFIX}"/lib/libharfbuzz-cairo*.a "${srcdir}/dest-cairo${MINGW_PREFIX}/lib/"
  mv "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/harfbuzz-cairo.pc "${srcdir}/dest-cairo${MINGW_PREFIX}/lib/pkgconfig/"

  mkdir -p "${srcdir}/dest-icu${MINGW_PREFIX}/bin"
  mkdir -p "${srcdir}/dest-icu${MINGW_PREFIX}/include/harfbuzz/"
  mkdir -p "${srcdir}/dest-icu${MINGW_PREFIX}/lib/pkgconfig"
  mv "${pkgdir}${MINGW_PREFIX}"/bin/libharfbuzz-icu*.dll "${srcdir}/dest-icu${MINGW_PREFIX}/bin/"
  mv "${pkgdir}${MINGW_PREFIX}"/include/harfbuzz/hb-icu.h "${srcdir}/dest-icu${MINGW_PREFIX}/include/harfbuzz/"
  mv "${pkgdir}${MINGW_PREFIX}"/lib/libharfbuzz-icu*.a "${srcdir}/dest-icu${MINGW_PREFIX}/lib/"
  mv "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/harfbuzz-icu.pc "${srcdir}/dest-icu${MINGW_PREFIX}/lib/pkgconfig/"

  fi

  cd "${srcdir}/${_realname}-${pkgver}"
  install -Dm644 COPYING -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}"
}

package_harfbuzz-cairo() {
  pkgdesc+=" - Cairo integration (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-cairo"
    "${MINGW_PACKAGE_PREFIX}-harfbuzz"
  )

  mv "${srcdir}/dest-cairo/"* "${pkgdir}/"
}

package_harfbuzz-icu() {
  pkgdesc+=" - ICU integration (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-harfbuzz"
    "${MINGW_PACKAGE_PREFIX}-icu"
  )

  mv "${srcdir}/dest-icu/"* "${pkgdir}/"
}

package_harfbuzz-utils() {
  pkgdesc+=" - Utilities (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-cairo"
    "${MINGW_PACKAGE_PREFIX}-harfbuzz"
    "${MINGW_PACKAGE_PREFIX}-harfbuzz-cairo"
    $([[ ${CARCH} == i686 ]] || echo "${MINGW_PACKAGE_PREFIX}-chafa")
  )

  mv "${srcdir}/dest-utils/"* "${pkgdir}/"
}

package_harfbuzz-docs() {
  pkgdesc+=" - Documentation (mingw-w64)"
  depends=()

  mv "${srcdir}/dest-docs/"* "${pkgdir}/"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
