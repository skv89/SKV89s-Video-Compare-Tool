# Maintainer: Christoph Reiter <reiter.christoph@gmail.com>
# Contributor: Biswapriyo Nath <nathbappai@gmail.com>

_realname=spirv-headers
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
epoch=2
pkgver=1.4.363.0
pkgrel=1
pkgdesc='Machine-readable files for the SPIR-V Registry (mingw-w64)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://www.khronos.org/registry/spir-v/'
msys2_repository_url="https://github.com/KhronosGroup/SPIRV-Headers"
msys2_references=(
  'anitya: 230542'
  'archlinux: spirv-headers'
  'gentoo: dev-util/spirv-headers'
)
license=('spdx:MIT')
groups=("${MINGW_PACKAGE_PREFIX}-vulkan-devel")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=(https://github.com/KhronosGroup/SPIRV-Headers/archive/vulkan-sdk-${pkgver}/${_realname}-${pkgver}.tar.gz)
sha256sums=('5b3a0d099f5c7649e29c0938476c462e71d66ad89a0bde42fa1ba3eb476956c9')

prepare() {
  cd SPIRV-Headers-vulkan-sdk-${pkgver}
}

build() {
  mkdir -p build-${MSYSTEM} && cd build-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -G "Ninja" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    ../SPIRV-Headers-vulkan-sdk-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install ./

  install -Dm644 "${srcdir}"/SPIRV-Headers-vulkan-sdk-${pkgver}/README.md "${pkgdir}"${MINGW_PREFIX}/share/doc/${_realname}/README.md
  install -Dm644 "${srcdir}"/SPIRV-Headers-vulkan-sdk-${pkgver}/LICENSE "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
}
