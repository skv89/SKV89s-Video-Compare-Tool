# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=opencore-amr
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.1.6
pkgrel=1
pkgdesc="Open source implementation of the Adaptive Multi Rate (AMR) speech codec (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clang32' 'clangarm64')
url="https://opencore-amr.sourceforge.io/"
license=("Apache")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
options=('strip' 'staticlibs')
source=("https://downloads.sourceforge.net/${_realname}/${_realname}-${pkgver}.tar.gz")
sha256sums=('483eb4061088e2b34b358e47540b5d495a96cd468e361050fae615b1809dc4a1')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
}

build() {
  [[ -d "build-${MINGW_CHOST}" ]] && rm -rf "build-${MINGW_CHOST}"
  mkdir -p "${srcdir}/build-${MINGW_CHOST}"
  cd "${srcdir}/build-${MINGW_CHOST}"
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-shared \
    --enable-static
  make
}

check() {
  cd "${srcdir}/build-${MINGW_CHOST}"
  make test
}

package() {
  cd "${srcdir}/build-${MINGW_CHOST}"
  make DESTDIR="${pkgdir}" install
}
