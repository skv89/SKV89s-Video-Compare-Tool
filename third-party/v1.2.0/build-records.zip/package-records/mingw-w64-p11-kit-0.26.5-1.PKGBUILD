# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Saul Ibarra Corretge <saghul@gmail.com>
# Contributor: Ray Donnelly <mingw.android@gmail.com>

_realname=p11-kit
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.26.5
pkgrel=1
pkgdesc="Library to work with PKCS#11 modules (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://p11-glue.freedesktop.org/p11-kit.html"
msys2_repository_url="https://github.com/p11-glue/p11-kit"
msys2_references=(
  "cpe: cpe:/a:p11-kit_project:p11-kit"
)
license=('spdx:BSD-3-Clause')
depends=(
  "${MINGW_PACKAGE_PREFIX}-libtasn1"
  "${MINGW_PACKAGE_PREFIX}-libffi"
  "${MINGW_PACKAGE_PREFIX}-gettext-runtime"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-gtk-doc"
  "${MINGW_PACKAGE_PREFIX}-gettext-tools"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-ninja"
)
source=(${msys2_repository_url}/releases/download/${pkgver}/${_realname}-${pkgver}.tar.xz{,.sig}
        0002-fix-includes.patch
        0004-fix-abspath-check.all.patch
        pathtools.c
        pathtools.h
        0006-p11-kit-relocation.patch
        0007-mmap-CreateFile-with-FILE_SHARE_READ.patch
        0011-p11-kit-spawn-external.patch
        0012-no-version-script.patch
        0013-fix-reallocarray-decl.patch)
validpgpkeys=('C0F67099B808FB063E2C81117BFB1108D92765AF'  # Stef Walter <stef@thewalter.net>
              '462225C3B46F34879FC8496CD605848ED7E69871'  # Daiki Ueno <ueno@unixuser.org>
              '5D46CB0F763405A7053556F47A75A648B3F9220C'  # Zoltan Fridrich <zfridric@redhat.com>
)
sha256sums=('f2cc09111e44bf3fea58f023180b33acea90aa82d042d6fbb623fbc5ba033bb7'
            'SKIP'
            'aa92f986d3f7dfc119e86f9a8f3987e6ac2562149921820eadbe09218c4df99c'
            'ea4593324db6d2d193733561f0352c6d679d1fb00aed0a2bae0d28aecbe92721'
            'ebf471173f5ee9c4416c10a78760cea8afaf1a4a6e653977321e8547ce7bf3c0'
            '1585ef1b61cf53a2ca27049c11d49e0834683dfda798f03547761375df482a90'
            '59f320862821ac83aab707cc99e064e934d94c9791fc0fea87648aec93ec3721'
            '2b0fc5c54776aca54e306315338323075e7412d8d800f490a31870008c34f8d1'
            '3c4821c36f76fd45c0d1ec83474773e45ccefde4ac92ca88b8493425f7553cb9'
            '15a2729f39e260f7fe8d55a91a399f2512854da626a69bc215470f902fc178cd'
            '83ecf11aaf9a1c6f617790048e80febd7320edae6ba203958349264170956911')

prepare() {
  test ! -d "${startdir}/../mingw-w64-pathtools" || {
    cmp "${startdir}/../mingw-w64-pathtools/pathtools.c" "${srcdir}/pathtools.c" &&
    cmp "${startdir}/../mingw-w64-pathtools/pathtools.h" "${srcdir}/pathtools.h"
  } || exit 1

  cd "${srcdir}/${_realname}-${pkgver}"
  cp -fHv "${srcdir}"/pathtools.[ch] common/

  patch -p1 -i "${srcdir}"/0002-fix-includes.patch
  patch -p1 -i "${srcdir}"/0004-fix-abspath-check.all.patch
  patch -p1 -i "${srcdir}"/0006-p11-kit-relocation.patch
  patch -p1 -i "${srcdir}"/0007-mmap-CreateFile-with-FILE_SHARE_READ.patch
  patch -p1 -i "${srcdir}"/0011-p11-kit-spawn-external.patch
  patch -p1 -i "${srcdir}"/0012-no-version-script.patch
  patch -p1 -i "${srcdir}"/0013-fix-reallocarray-decl.patch
}

build() {
  CFLAGS+=" -Wno-error=incompatible-pointer-types"

  MSYS2_ARG_CONV_EXCL="--prefix=;-D" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --libexecdir=lib \
      -Dsystem_config="${MINGW_PREFIX}/etc/pkcs11" \
      -Dtrust_paths="${MINGW_PREFIX}/etc/pki/ca-trust/source:${MINGW_PREFIX}/share/pki/ca-trust-source" \
      -Dsystemd=disabled \
      -Dbashcompdir="${MINGW_PREFIX}/share/bash-completion/completions" \
      -Dzshcompdir="${MINGW_PREFIX}/share/zsh/site-functions" \
      -Dgtk_doc=true \
      -Dglib_prefix="${MINGW_PREFIX}" \
      -Dman=true \
      -Dtest=false \
      "build-${MSYSTEM}" \
      "${_realname}-${pkgver}"

  MSYS2_ARG_CONV_EXCL="-D" \
    meson compile -C "build-${MSYSTEM}"
}

package() {
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"
}
