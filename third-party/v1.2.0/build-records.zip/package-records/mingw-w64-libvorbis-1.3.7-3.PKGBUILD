# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libvorbis
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.3.7
pkgrel=3
pkgdesc="Vorbis codec library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://xiph.org/"
msys2_repository_url='https://gitlab.xiph.org/xiph/vorbis'
msys2_references=(
  "cpe: cpe:/a:xiph.org:libvorbis"
)
license=('custom')
depends=("${MINGW_PACKAGE_PREFIX}-libogg")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
)
source=(https://downloads.xiph.org/releases/vorbis/${_realname}-${pkgver}.tar.gz)
sha256sums=('0e982409a9c3fc82ee06e08205b1355e5c6aa4c36bca58146ef399621b0ce5ab')

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-shared \
    --enable-static

  make
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  make DESTDIR="${pkgdir}" install
}
