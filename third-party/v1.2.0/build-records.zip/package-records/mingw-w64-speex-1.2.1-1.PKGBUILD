# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=speex
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.2.1
pkgrel=1
pkgdesc="A free codec for free speech (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clang32' 'clangarm64')
license=('BSD')
url="https://speex.org/"
depends=("${MINGW_PACKAGE_PREFIX}-libogg" "${MINGW_PACKAGE_PREFIX}-speexdsp")
options=('strip' '!libtool' 'staticlibs')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
source=("https://gitlab.xiph.org/xiph/speex/-/archive/Speex-${pkgver}/speex-Speex-${pkgver}.tar.gz")
sha256sums=('beaf2642e81a822eaade4d9ebf92e1678f301abfc74a29159c4e721ee70fdce0')

prepare() {
  mv "speex-Speex-${pkgver}" "${_realname}-${pkgver}"
  cd ${srcdir}/${_realname}-${pkgver}

  ./autogen.sh
}

build() {
  [[ -d "build-${MINGW_CHOST}" ]] && rm -rf "build-${MINGW_CHOST}"
  mkdir -p ${srcdir}/build-${MINGW_CHOST} && cd ${srcdir}/build-${MINGW_CHOST}
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --enable-shared \
    --enable-static

  make
}

package() {
  cd ${srcdir}/build-${MINGW_CHOST}
  make DESTDIR="${pkgdir}" install
  install -Dm644 ${srcdir}/${_realname}-${pkgver}/COPYING "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
