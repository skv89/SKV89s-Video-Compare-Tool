# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=fftw
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
_pkgver=3.3.11
pkgver=${_pkgver//-/.}
pkgrel=2
pkgdesc="A library for computing the discrete Fourier transform (DFT) (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.fftw.org/"
msys2_repository_url='https://github.com/FFTW/fftw3'
license=("spdx:GPL-2.0-or-later")
depends=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  $([[ ${MINGW_PACKAGE_PREFIX} == *-clang-* ]] || echo "${MINGW_PACKAGE_PREFIX}-libquadmath" )
  "${MINGW_PACKAGE_PREFIX}-omp"
)
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake")
             #"${MINGW_PACKAGE_PREFIX}-fc") not required at buildtime
source=("https://www.fftw.org/${_realname}-${_pkgver}.tar.gz"
        "0001-detect-arm64-counter.patch"
        "0002-no-dllexport.patch"
        "0003-shared-lib.patch")
sha256sums=('5630c24cdeb33b131612f7eb4b1a9934234754f9f388ff8617458d0be6f239a1'
            '482a045e9a87fb22eebee712db6aaa5dcb1e08336a6feb34d76dc19bcab08bc8'
            'd44e0b25fee59bee3b2fa81ce86762b66158d5e2be7f350d8cf937691aa72b5b'
            'd82e96c8545515b9c83d54356209ee9c4a45bedc3859cb01cf3966dc38fc7a33')

precisions="double float long_double \
           $( [[ ${MINGW_PACKAGE_PREFIX} == *-clang-* ]] || echo "quad" )"

apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  apply_patch_with_msg \
    0001-detect-arm64-counter.patch \
    0002-no-dllexport.patch \
    0003-shared-lib.patch
}

build() {
  for cur in ${precisions}; do
    mkdir -p "${srcdir}"/build-${MSYSTEM}-${cur} && cd "${srcdir}"/build-${MSYSTEM}-${cur}

    msg "Building ${_realname} for ${cur} precision ..."

    # create FFTW3LibraryDepends.cmake by configuring (but not building) with cmake
    local -a _config_cmake=""
    if [ "${cur}" = "float" ]; then
      _config_cmake="-DENABLE_FLOAT=ON"
    elif [ "${cur}" = "long_double" ]; then
      _config_cmake="-DENABLE_LONG_DOUBLE=ON"
    elif [ "${cur}" = "quad" ]; then
      _config_cmake="-DENABLE_QUAD_PRECISION=ON"
    fi

    if [[ $CARCH != aarch64 ]]; then
      _config_cmake+=" -DENABLE_SSE=ON -DENABLE_SSE2=ON -DENABLE_AVX=ON -DENABLE_AVX2=ON"
    fi

    MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
      "${MINGW_PREFIX}"/bin/cmake.exe \
        -Wno-author \
        -GNinja \
        ${_config_cmake} \
        -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
        -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
        -DBUILD_SHARED_LIBS=ON \
        -DENABLE_OPENMP=ON \
        -DENABLE_THREADS=ON \
        ../${_realname}-${_pkgver}

    # build library using autotools
    local -a _config=""
    if [[ $CARCH == aarch64 ]]; then
      _config+="--enable-neon"
    else
      _config+="--enable-sse2 --enable-avx --enable-avx-128-fma --enable-avx2 --enable-avx512"
    fi

    if [ "${cur}" = "float" ]; then
      _config+=" --enable-float"
    elif [ "${cur}" = "long_double" ]; then
      _config="--enable-long-double"
    elif [ "${cur}" = "quad" ]; then
      _config="--enable-quad-precision"
    fi

    # if [[ ${MINGW_PACKAGE_PREFIX} == *-clang-* ]]; then
    #   export F77=flang
    #   _config+=" ac_cv_f77_compiler_gnu=yes"
    # else
    #   export F77=gfortran
    # fi

    FFLAGS=" -O2" \
    ../${_realname}-${_pkgver}/configure \
      --prefix="${MINGW_PREFIX}" \
      --enable-static \
      --enable-shared \
      --enable-threads \
      --enable-openmp \
      --with-our-malloc \
      --with-g77-wrappers \
      --with-windows-f77-mangling \
      ${_config}

    make
  done
}

package() {
  for cur in ${precisions}; do
    msg "Installing ${_realname} for ${cur} precision ..."
    cd "${srcdir}"/build-${MSYSTEM}-${cur}

    make DESTDIR="${pkgdir}" install -C "${srcdir}"/build-${MSYSTEM}-${cur}

    # move .cmake files to correct directory
    local _prec_prefix
    local _file_prefix
    case "${cur}" in
      double)
        _prec_prefix=fftw3
        _file_prefix=FFTW3
        ;;
      float)
        _prec_prefix=fftw3f
        _file_prefix=FFTW3f
        ;;
      long_double)
        _prec_prefix=fftw3l
        _file_prefix=FFTW3l
        ;;
      quad)
        _prec_prefix=fftw3q
        _file_prefix=FFTW3q
        ;;
    esac
    local _staging_prefix=$(cygpath -am "${srcdir}"/build-${MSYSTEM}-${cur})
    sed -e "s|IMPORTED_IMPLIB_RELEASE \"${_staging_prefix}|IMPORTED_IMPLIB_RELEASE \"${MINGW_PREFIX}/lib|g" -i ./FFTW3LibraryDepends.cmake
    sed -e "s|IMPORTED_LOCATION_RELEASE \"${_staging_prefix}|IMPORTED_LOCATION_RELEASE \"${MINGW_PREFIX}/bin|g" -i ./FFTW3LibraryDepends.cmake
    install -Dm644 ./FFTW3LibraryDepends.cmake "${pkgdir}"${MINGW_PREFIX}/lib/cmake/${_prec_prefix}/FFTW3LibraryDepends.cmake
    mv "${pkgdir}"${MINGW_PREFIX}/lib/cmake/fftw3/${_file_prefix}*.cmake "${pkgdir}"${MINGW_PREFIX}/lib/cmake/${_prec_prefix}/
  done
}
