# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libpng
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.6.59
pkgrel=2
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
pkgdesc="A collection of routines used to create PNG format graphics (mingw-w64)"
depends=("${MINGW_PACKAGE_PREFIX}-zlib")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
)
license=('custom')
url="http://www.libpng.org/pub/png/libpng.html"
msys2_repository_url='https://github.com/pnggroup/libpng'
msys2_references=(
  'anitya: 1705'
  "cpe: cpe:/a:greg_roelofs:libpng"
  "cpe: cpe:/a:libpng:libpng"
)
source=("${msys2_repository_url}/archive/refs/tags/v${pkgver}.tar.gz"
        # patch from https://bugzilla.mozilla.org/show_bug.cgi?id=2010431
        "apng.patch")
sha256sums=('2540302a1844ad2b2b501977abecfa850f265f97b78f065a712ab4074a89f5b5'
            'a9c117324291cda7558ab36bec4ba28a34013d76e1ceaf9953749791a9e154a8')
validpgpkeys=('8048643BA2C840F4F92A195FF54984BFA16C640F')  # Glenn Randers-Pehrson (mozilla) <glennrp+bmo@gmail.com>

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  # Add animated PNG (apng) support
  # Some context as to why this is here: https://bugs.gentoo.org/824018
  # Arch dropped it some time ago:
  # https://gitlab.archlinux.org/archlinux/packaging/packages/libpng/-/commit/bc95b152de9709a21c2938d5a
  # Maybe we should too?
  patch -p1 -i "${srcdir}/apng.patch"

  # autoreconf to get updated libtool files with clang support
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../"${_realname}-${pkgver}"/configure \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --prefix=${MINGW_PREFIX} \
    --enable-shared \
    --enable-static

  make

  msg2 "Build contributed programs"
  mkdir -p ".libs/contrib/pngminus" && cd ".libs/contrib/pngminus"
  cp -r "${srcdir}/${_realname}-${pkgver}/contrib/pngminus"/* .
  # libpng.a and libpng.dll.a are basically symlinks to libpng16.a
  # and libpng16.dll.a that are created at "make install" but we are
  # building the contributed programs before the "make install" so
  # we have to link to libpng16.dll.a or libpng16.a if building
  # statically. When building the static programs, we might also
  # want to build with the static version of zlib.
  make PNGINC="-I${srcdir}/${_realname}-${pkgver} -I${srcdir}/build-${MSYSTEM}" \
    CC="${MINGW_PREFIX}/bin/cc" \
    PNGLIB_SHARED="-L../.. -lpng16" \
    PNGLIB_STATIC="../../libpng16.a" \
    ZLIB_STATIC="${MINGW_PREFIX}/lib/libz.a" \
    CFLAGS="$CFLAGS" \
    LDFLAGS="-L../.. $LDFLAGS" \
    png2pnm pnm2png png2pnm-static pnm2png-static
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  # More symbols are exported than scripts/symbols.def
  make -k check || true
}

package () {
  cd "${srcdir}/build-${MSYSTEM}"
  make install DESTDIR="${pkgdir}"

  install -Dm644 "${srcdir}/libpng-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"

  msg2 "Install contributed programs"
  cd ".libs/contrib/pngminus"

  # deploy both the shared lib and static programs in case a developer wants to
  # redistribute those.  I was also building statically for some internal testing.
  install -m755 png2pnm.exe pnm2png.exe png2pnm-static.exe pnm2png-static.exe "${pkgdir}${MINGW_PREFIX}/bin/"
}

