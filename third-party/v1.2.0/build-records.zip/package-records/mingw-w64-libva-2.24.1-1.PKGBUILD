# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>

_realname=libva
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=2.24.1
pkgrel=1
pkgdesc='Video Acceleration (VA) API (mingw-w64)'
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://intel.github.io/libva/'
msys2_repository_url='https://github.com/intel/libva'
msys2_references=(
  'purl: pkg:github/intel/libva'
)
license=('spdx:MIT')
makedepends=("${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://github.com/intel/libva/archive/${pkgver}/${_realname}-${pkgver}.tar.gz"
        "0001-libva-add-driver-path-relocation.patch"
        "0002-libva-allow-static-library.patch")
sha256sums=('0b4a3649ee8d683b9cce2ef094df4fb039d276c0cef7e49337c43d3b297b9f42'
            '1cc40ae0b25f462fa0cb4c4717ea7728e8ff0d83c13197035525ff76c0947ad3'
            'd2892f008523a24fca707b501a56141eae2aee3b2ea1d708a15cc50da6082430')

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}

  patch -Np1 -i "${srcdir}/0001-libva-add-driver-path-relocation.patch"
  patch -Np1 -i "${srcdir}/0002-libva-allow-static-library.patch"
}

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=static \
      "build-${MSYSTEM}-static" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=shared \
      "build-${MSYSTEM}-shared" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-shared"
}

package() {
  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"
  meson install -C "build-${MSYSTEM}-shared" --destdir "${pkgdir}"

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING
}
