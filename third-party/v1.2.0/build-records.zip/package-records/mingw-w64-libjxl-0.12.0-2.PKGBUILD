# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>
# Contributor: Miloš Komarčević <miloskomarcevic@aim.com>

_realname=libjxl
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.12.0
pkgrel=2
pkgdesc='JPEG XL image format reference implementation (mingw-w64)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://jpeg.org/jpegxl/"
msys2_repository_url='https://github.com/libjxl/libjxl'
msys2_references=(
  "cpe: cpe:/a:jpeg:jpeg-xl"
  "cpe: cpe:/a:libjxl_project:libjxl"
)
license=('spdx:BSD-3-Clause')
depends=("${MINGW_PACKAGE_PREFIX}-brotli"
         "${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-giflib"
         "${MINGW_PACKAGE_PREFIX}-highway"
         "${MINGW_PACKAGE_PREFIX}-lcms2"
         "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
         "${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-libwinpthread"
         "${MINGW_PACKAGE_PREFIX}-openexr")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-asciidoc"
             "${MINGW_PACKAGE_PREFIX}-gdk-pixbuf2")
optdepends=("${MINGW_PACKAGE_PREFIX}-gdk-pixbuf2: for gdk-pixbuf loader")
source=("https://github.com/libjxl/libjxl/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('03e9be69a30be4011f559da75328b6d7cea8ad921fabfbd551ce10bf45cdc992')
noextract=("${_realname}-${pkgver}.tar.gz")

prepare() {
  tar -xzf "${_realname}-${pkgver}.tar.gz" || true
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${_extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -DBUILD_TESTING=OFF \
      -DJPEGXL_BUNDLE_LIBPNG=OFF \
      -DJPEGXL_ENABLE_BENCHMARK=OFF \
      -DJPEGXL_ENABLE_DOXYGEN=OFF \
      -DJPEGXL_ENABLE_EXAMPLES=OFF \
      -DJPEGXL_ENABLE_JNI=OFF \
      -DJPEGXL_ENABLE_PLUGINS=OFF \
      -DJPEGXL_ENABLE_SJPEG=OFF \
      -DJPEGXL_ENABLE_SKCMS=OFF \
      -DJPEGXL_ENABLE_TCMALLOC=OFF \
      -DJPEGXL_ENABLE_TOOLS=OFF \
      -DJPEGXL_FORCE_SYSTEM_BROTLI=ON \
      -DJPEGXL_FORCE_SYSTEM_HWY=ON \
      -DJPEGXL_FORCE_SYSTEM_LCMS2=ON \
      -DJPEGXL_VERSION=${pkgver}-${pkgrel} \
      -DJPEGXL_WARNINGS_AS_ERRORS=OFF \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-static"

  cmake --build "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${_extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DBUILD_TESTING=OFF \
      -DJPEGXL_BUNDLE_LIBPNG=OFF \
      -DJPEGXL_ENABLE_BENCHMARK=OFF \
      -DJPEGXL_ENABLE_DOXYGEN=OFF \
      -DJPEGXL_ENABLE_EXAMPLES=OFF \
      -DJPEGXL_ENABLE_JNI=OFF \
      -DJPEGXL_ENABLE_PLUGINS=ON \
      -DJPEGXL_ENABLE_PLUGIN_GIMP210=OFF \
      -DJPEGXL_ENABLE_PLUGIN_MIME=OFF \
      -DJPEGXL_ENABLE_SJPEG=OFF \
      -DJPEGXL_ENABLE_SKCMS=OFF \
      -DJPEGXL_ENABLE_TCMALLOC=OFF \
      -DJPEGXL_FORCE_SYSTEM_BROTLI=ON \
      -DJPEGXL_FORCE_SYSTEM_HWY=ON \
      -DJPEGXL_FORCE_SYSTEM_LCMS2=ON \
      -DJPEGXL_VERSION=${pkgver}-${pkgrel} \
      -DJPEGXL_WARNINGS_AS_ERRORS=OFF \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-shared"

  cmake --build "build-${MSYSTEM}-shared"
}

check() {
  cmake --build "build-${MSYSTEM}-shared" --target test
}

package() {
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-static"
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-shared"

  install -Dm644 "${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
