# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=srt
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.5.7
pkgrel=1
pkgdesc="Secure Reliable Transport (SRT) (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.srtalliance.org/"
msys2_repository_url="https://github.com/Haivision/srt"
msys2_references=(
  "cpe: cpe:/a:srtalliance:secure_reliable_transport"
)
license=('spdx:MPL-2.0')
depends=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  "${MINGW_PACKAGE_PREFIX}-libwinpthread"
  "${MINGW_PACKAGE_PREFIX}-openssl"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
)
source=("${msys2_repository_url}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz"
        0006-no-msvc-compat-headers.patch)
sha256sums=('017cd1e437ef2073a4dd10ddf7b55e86bc3d6ebac0393d13bd22f6a57055d32b'
            '18af8a55e898b12074e797a212eda5e6f3c935dcc37745eb97a60591e80ab64e')
noextract=(${_realname}-${pkgver}.tar.gz)

prepare() {
  tar -xzf "${srcdir}"/${_realname}-${pkgver}.tar.gz -C "${srcdir}" || true

  cd ${_realname}-${pkgver}

  patch -p1 -i "${srcdir}"/0006-no-msvc-compat-headers.patch
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      ${_extra_config[@]} \
      -DCMAKE_POLICY_VERSION_MINIMUM=3.10 \
      -DENABLE_SHARED=ON \
      -DENABLE_STATIC=ON \
      -DENABLE_RELATIVE_LIBPATH=ON \
      -DUSE_ENCLIB=openssl \
      -S ${_realname}-${pkgver} \
      -B build-${MSYSTEM}

  cmake --build build-${MSYSTEM}
}

package() {
  DESTDIR="${pkgdir}" cmake --install build-${MSYSTEM}

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
}
