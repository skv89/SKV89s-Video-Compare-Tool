# Maintainer: Alexey Pavlov <Alexpux@gmail.com>

_realname=gmp
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=6.3.0
pkgrel=2
pkgdesc="A free library for arbitrary precision arithmetic (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clang32' 'clangarm64')
url="https://gmplib.org/"
license=('LGPL3' 'GPL')
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools" "${MINGW_PACKAGE_PREFIX}-cc")
source=(https://ftp.gnu.org/gnu/gmp/${_realname}-${pkgver}.tar.xz{,.sig}
        do-not-use-dllimport.diff
        gmp-staticlib.diff)
sha256sums=('a3c2b80201b89e68616f4ad30bc66aee4927c3ce50e33929ca819d5c43538898'
            'SKIP'
            '385ab704f82c47f3aecc9141f43c96e7b8de2bf0e654dc457ce0f1a039db2c68'
            '7c3cde2634baa2cb1c31404bbfed2d8d7ba33556971ac842a08f2e87667849ab')
validpgpkeys=('343C2FF0FBEE5EC2EDBEF399F3599FF828C67298') # Niels Möller <nisse@lysator.liu.se>"

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  [[ -d ../stash ]] && rm -rf ../stash
  mkdir ../stash
  cp config.{guess,sub} ../stash
  patch -p2 -i ${srcdir}/do-not-use-dllimport.diff
  patch -p1 -i ${srcdir}/gmp-staticlib.diff
  autoreconf -fiv
  cp -f ../stash/config.{guess,sub} .
}

build() {
  local -a extra_config
  case "$CARCH" in
    i?86|x86_64)
      extra_config+=(--enable-fat)
      ;;
    *)
      extra_config+=(--disable-assembly)
      ;;
  esac

  CFLAGS+=" -Wno-attributes -Wno-ignored-attributes"

  # Build static version
  mkdir -p "${srcdir}/static-${MSYSTEM}" && cd "${srcdir}/static-${MSYSTEM}"
  ../${_realname}-${pkgver}/configure \
    --build=${MINGW_CHOST} \
    --prefix=${MINGW_PREFIX} \
    --enable-cxx \
    "${extra_config[@]}" \
    --enable-static \
    --disable-shared
  make

  # Build shared version
  mkdir -p "${srcdir}/shared-${MSYSTEM}" && cd "${srcdir}/shared-${MSYSTEM}"
  ../${_realname}-${pkgver}/configure \
    --build=${MINGW_CHOST} \
    --prefix=${MINGW_PREFIX} \
    --enable-cxx \
    "${extra_config[@]}" \
    --disable-static \
    --enable-shared
  make
}

check() {
  cd "${srcdir}/static-${MSYSTEM}"
  make check
}

package() {
  cd "${srcdir}/static-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install
  cd "${srcdir}/shared-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install
}
