# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=libjpeg-turbo
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=3.2.0
pkgrel=1
pkgdesc="JPEG image codec with accelerated baseline compression and decompression (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://libjpeg-turbo.virtualgl.org/"
msys2_repository_url="https://github.com/libjpeg-turbo/libjpeg-turbo"
msys2_pgp_keys_url="https://libjpeg-turbo.org/Downloads/DigitalSignatures"
msys2_references=(
  "cpe: cpe:/a:d.r.commander:libjpeg-turbo"
  "cpe: cpe:/a:libjpeg-turbo:libjpeg-turbo"
)
license=(custom:'BSD-like')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             $( [[ "${CARCH}" == "aarch64" ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm" ))
provides=("${MINGW_PACKAGE_PREFIX}-libjpeg")
conflicts=("${MINGW_PACKAGE_PREFIX}-libjpeg")
replaces=("${MINGW_PACKAGE_PREFIX}-libjpeg")
source=(https://github.com/libjpeg-turbo/libjpeg-turbo/releases/download/${pkgver}/libjpeg-turbo-${pkgver}.tar.gz{,.sig}
        "0001-header-compat.mingw.patch"
        "libjpeg-turbo-1.3.1-libmng-compatibility.patch")
sha256sums=('6f30092cef9fb839779646608f4ee14ae3cbac989c47fa05e841b0841f09878e'
            'SKIP'
            'f0609ad801831a549cbc15eeee5ab45fb9df344e607491f6f1ad762519d50089'
            '2154ecce25b3b2aae5eeabd52c8a1480ec78f1cd50bb8e989e30de54d50e3ec6')
validpgpkeys=('0338C8D8D9FDA62CF9C421BD7EC2DBB6F4DBF434')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  patch -p1 -i "${srcdir}"/0001-header-compat.mingw.patch
  patch -p1 -i "${srcdir}"/libjpeg-turbo-1.3.1-libmng-compatibility.patch
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake \
    -GNinja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    ${_extra_config[@]} \
    -DWITH_JPEG8=ON \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build .
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"
  ${MINGW_PREFIX}/bin/ctest || true
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .

  cp "${srcdir}"/${_realname}-${pkgver}/src/{jinclude,transupp}.h "${pkgdir}"${MINGW_PREFIX}/include/

  # Licenses
  # See https://www.libjpeg-turbo.org/About/License
  cd "${srcdir}/${_realname}-${pkgver}"
  install -Dm644 README.ijg            "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/README.ijg"
  install -Dm644 README.md  "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/README.md"
  install -Dm644 LICENSE.md  "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE.md"
  install -Dm644 simd/nasm/jsimdext.inc "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/simd/jsimdext.inc"
}
