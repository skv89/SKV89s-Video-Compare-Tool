# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=librsvg
pkgbase="mingw-w64-${_realname}"
pkgname=(
  "${MINGW_PACKAGE_PREFIX}-${_realname}"
  "${MINGW_PACKAGE_PREFIX}-${_realname}-docs"
)
pkgver=2.63.4
pkgrel=1
pkgdesc="SVG rendering library (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://wiki.gnome.org/Projects/LibRsvg"
msys2_repository_url="https://gitlab.gnome.org/GNOME/librsvg"
msys2_references=(
  'archlinux: librsvg'
  'aur:' # ignore librsvg-git
  'cpe: cpe:/a:gnome:librsvg'
  'gentoo: gnome-base/librsvg'
  'purl: pkg:cargo/librsvg'
)
license=("spdx:LGPL-2.1-or-later")
depends=(
  "${MINGW_PACKAGE_PREFIX}-cairo"
  "${MINGW_PACKAGE_PREFIX}-gdk-pixbuf2"
  "${MINGW_PACKAGE_PREFIX}-libxml2"
  "${MINGW_PACKAGE_PREFIX}-pango"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cargo-c"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-gi-docgen"
  "${MINGW_PACKAGE_PREFIX}-gobject-introspection"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-python-docutils"
  "${MINGW_PACKAGE_PREFIX}-rust"
  "${MINGW_PACKAGE_PREFIX}-vala"
)
optdepends=(
  "${MINGW_PACKAGE_PREFIX}-gtk3: for rsvg-view-3"
)
source=(
  "https://download.gnome.org/sources/librsvg/${pkgver%.*}/${_realname}-${pkgver}.tar.xz"
  "0002-avoid-link-whole.patch"
)
noextract=("${_realname}-${pkgver}.tar.xz")
sha256sums=('31f07d9350dad3f8964fd613c31309ac160fdef13dfac59df6fd082de78d6e8f'
            '4cb597eef01a636ad7007b3a47b76e395f30b2347183b5acb1af94d39577a239')

prepare() {
  bsdtar -xf "${_realname}-${pkgver}.tar.xz" 2>/dev/null || true

  cd "${_realname}-${pkgver}"

  # https://gitlab.gnome.org/GNOME/librsvg/-/issues/1210
  patch -Np1 -i "${srcdir}/0002-avoid-link-whole.patch"
  cargo update -p windows-sys@0.61.2 --precise 0.60.2
  cargo fetch --locked
}

build() {
  # https://github.com/msys2/MINGW-packages/pull/13622#issuecomment-1285820970
  export WINAPI_NO_BUNDLED_LIBRARIES=1

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
    --prefix="${MINGW_PREFIX}" \
    --wrap-mode=nodownload \
    --auto-features=enabled \
    --default-library=static \
    --buildtype=plain \
    -Dintrospection=disabled \
    -Davif=disabled \
    -Dtests=false \
    -Ddocs=disabled \
    -Dpixbuf-loader=disabled \
    -Drsvg-convert=disabled \
    "build-${MSYSTEM}-static" \
    "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
    --prefix="${MINGW_PREFIX}" \
    --wrap-mode=nodownload \
    --auto-features=enabled \
    --buildtype=plain \
    -Davif=disabled \
    -Dpixbuf-loader=enabled \
    "build-${MSYSTEM}" \
    "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package_librsvg() {
  conflicts=("${MINGW_PACKAGE_PREFIX}-${_realname}-2.40")
  replaces=("${MINGW_PACKAGE_PREFIX}-${_realname}-2.40")

  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING.LIB" -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}"

  mkdir -p "${srcdir}/dest${MINGW_PREFIX}/share"
  mv "${pkgdir}${MINGW_PREFIX}/share/doc" "${srcdir}/dest${MINGW_PREFIX}/share/doc"
}

package_librsvg-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv "${srcdir}/dest/"* "${pkgdir}/"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
