# Maintainer: Christopher Degawa <ccom@randomderp.com>

_realname=dav1d
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.5.4
pkgrel=1
pkgdesc="AV1 cross-platform decoder focused on speed and correctness (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://code.videolan.org/videolan/dav1d'
msys2_repository_url='https://code.videolan.org/videolan/dav1d'
msys2_references=(
  'anitya: 18920'
  "cpe: cpe:/a:videolan:dav1d"
)
license=('spdx:BSD-2-Clause')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-nasm"
  "${MINGW_PACKAGE_PREFIX}-xxhash"
)
source=("https://downloads.videolan.org/pub/videolan/dav1d/${pkgver}/dav1d-${pkgver}.tar.xz"{,.asc}
        "0001-dll-version.patch")
sha256sums=('686616b7c69eb88d44459391ab25cac13b6647a3b288835c5784e71c1514a5c5'
            'SKIP'
            '7fc584e69c156d7d9805b38912f07f417ccd1cce5fe4ee457761e8bea9128d04')
validpgpkeys=('65F7C6B4206BD057A7EB73787180713BE58D1ADC') # VideoLAN Release Signing Key

prepare() {
  cd "${_realname}-${pkgver}"

  patch -Np1 -i "${srcdir}/0001-dll-version.patch"
}

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix=${MINGW_PREFIX} \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library both \
      "${_extra_config[@]}" \
      build-${MSYSTEM} \
      ${_realname}-${pkgver}

  meson compile -C build-${MSYSTEM}
}

check() {
  meson setup --reconfigure -Denable_tests=true build-${MSYSTEM} ${_realname}-${pkgver}
  meson test -C build-${MSYSTEM}
}

package() {
  meson install -C build-${MSYSTEM} --destdir "${pkgdir}"

  # License
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/doc/PATENTS" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/PATENTS"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/README.md" "${pkgdir}${MINGW_PREFIX}/share/doc/${_realname}/README.md"
}
