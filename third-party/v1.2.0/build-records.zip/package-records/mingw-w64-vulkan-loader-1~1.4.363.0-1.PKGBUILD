# Maintainer: J. Peter Mugaas <jpmugaas@suddenlink.net>
# Contributor: wirx6 <wirx654@gmail.com>

_realname=Vulkan-Loader
pkgbase=mingw-w64-vulkan-loader
pkgname=("${MINGW_PACKAGE_PREFIX}-vulkan-loader")
provides=("${MINGW_PACKAGE_PREFIX}-vulkan")
pkgver=1.4.363.0
pkgrel=1
epoch=1
pkgdesc='Vulkan Installable Client Driver (ICD) Loader (mingw-w64)'
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.khronos.org/vulkan/"
msys2_repository_url="https://github.com/KhronosGroup/Vulkan-Loader"
msys2_references=(
  'anitya: 230557'
  'archlinux: vulkan-icd-loader'
  'cpe: cpe:2.3:a:khronos:vulkan'
  'gentoo: media-libs/vulkan-loader'
)
license=('spdx:Apache-2.0')
groups=("${MINGW_PACKAGE_PREFIX}-vulkan-devel")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-python"
             "${MINGW_PACKAGE_PREFIX}-vulkan-headers")
source=("https://github.com/KhronosGroup/${_realname}/archive/vulkan-sdk-${pkgver}/${_realname}-${pkgver}.tar.gz"
        001-fix-import-library-name.patch)
sha256sums=('941eff558fc74f248745fb7df367640cf89a8457f216dae498a74ae14b6ba6f7'
            '3b4a05ba0d8df9cdde475fee056e8c67891ce1b02ff4ce37216beec5ae783d24')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying $_patch"
    patch -Np1 -i "${srcdir}/$_patch"
  done
}

prepare() {
  cd "${srcdir}"/${_realname}-vulkan-sdk-${pkgver}
  apply_patch_with_msg \
    001-fix-import-library-name.patch
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  CFLAGS+=" -D__STDC_FORMAT_MACROS -Wno-unused-function" \
  CPPFLAGS+=" -D__STDC_FORMAT_MACROS" \
  CXXFLAGS+=" -D__USE_MINGW_ANSI_STDIO -D__STDC_FORMAT_MACROS -fpermissive -Wno-unused-function" \
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -G "Ninja" \
    "${extra_config[@]}" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DUSE_MASM=OFF \
    -DBUILD_TESTS=OFF \
    $([[ ${CARCH} != i686 ]] && echo "-DUSE_GAS=ON") \
    ../${_realname}-vulkan-sdk-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .

  install -Dm644 "${srcdir}"/${_realname}-vulkan-sdk-${pkgver}/LICENSE.TXT "${pkgdir}"${MINGW_PREFIX}/share/licenses/vulkan-loader/LICENSE
}
