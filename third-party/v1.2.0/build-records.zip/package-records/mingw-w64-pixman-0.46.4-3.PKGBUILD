# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=pixman
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.46.4
pkgrel=3
pkgdesc="The pixel-manipulation library for X and cairo (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://gitlab.freedesktop.org/pixman/pixman"
msys2_repository_url='https://gitlab.freedesktop.org/pixman/pixman'
msys2_references=(
  'cpe: cpe:/a:pixman:pixman'
)
license=('spdx:MIT')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-libpng"
             "${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
source=("https://xorg.freedesktop.org/releases/individual/lib/pixman-${pkgver}.tar.xz")
noextract=("pixman-${pkgver}.tar.xz")
sha256sums=('a098c33924754ad43f981b740f6d576c70f9ed1006e12221b1845431ebce1239')

prepare() {
  tar -xf "${srcdir}/pixman-${pkgver}.tar.xz" -C "${srcdir}" 2>/dev/null || true

  cd "${_realname}-${pkgver}"
}

build() {
  mkdir -p build-${MSYSTEM} && cd build-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  meson setup \
    --prefix="${MINGW_PREFIX}" \
    --buildtype plain \
    -Ddefault_library=both \
    -Dgtk=disabled \
    -Da64-neon=disabled \
    ../${_realname}-${pkgver}

  meson compile
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  meson test
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  DESTDIR="${pkgdir}" meson install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
