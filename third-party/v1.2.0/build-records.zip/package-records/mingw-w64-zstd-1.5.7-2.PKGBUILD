# Maintainer: Chocobo1

_realname=zstd
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.5.7
pkgrel=2
pkgdesc="Zstandard - Fast real-time compression algorithm (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://facebook.github.io/zstd/'
msys2_repository_url="https://github.com/facebook/zstd"
msys2_references=(
  "cpe: cpe:/a:facebook:zstandard"
)
license=('spdx:BSD-3-Clause OR GPL-2.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=("https://github.com/facebook/zstd/releases/download/v${pkgver}/${_realname}-${pkgver}.tar.gz"{,.sig}
        zstd-1.4.0-fileio-mingw.patch)
sha256sums=('eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3'
            'SKIP'
            '283e584477a8f70c9bea86a500486dd11dfcb59b22690fd94deb44a3f95a6668')
validpgpkeys=('4EF4AC63455FC9F4545D9B7DEF8FE99528B52FFD') # Zstandard Release Signing Key <signing@zstd.net>
noextract=(${_realname}-${pkgver}.tar.gz)

prepare() {
  tar -xzf ${_realname}-${pkgver}.tar.gz || true
  cd "${srcdir}/${_realname}-${pkgver}"
  patch -Np1 -i "${srcdir}/zstd-1.4.0-fileio-mingw.patch"
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      -DBUILD_SHARED_LIBS=ON \
      "${extra_config[@]}" \
      -DZSTD_BUILD_CONTRIB=ON \
      -DBUILD_TESTING=OFF \
      -DZSTD_PROGRAMS_LINK_SHARED=ON \
      ../${_realname}-${pkgver}/build/cmake

  ${MINGW_PREFIX}/bin/cmake --build .
}


package() {
  cd "${srcdir}"/build-${MSYSTEM}

  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
