# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=openjpeg
pkgbase=mingw-w64-${_realname}2
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}2"
pkgver=2.5.4
pkgrel=2
pkgdesc="An open source JPEG 2000 codec (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.openjpeg.org/"
msys2_repository_url='https://github.com/uclouvain/openjpeg'
msys2_references=(
  'gentoo: media-libs/openjpeg'
  "cpe: cpe:/a:uclouvain:openjpeg"
)
license=("spdx:BSD-2-Clause")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-lcms2"
         "${MINGW_PACKAGE_PREFIX}-libtiff"
         "${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-zlib")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=(https://github.com/uclouvain/openjpeg/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz
        0004-mingw-disable-java.patch
        0006-openjpeg-2.1.0-stdcall-for-all-win.patch
        https://github.com/uclouvain/openjpeg/commit/1ad9bec2c12ee445ce23e660f5e4fe870b9d5e09.patch)
sha256sums=('a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a'
            'adade9b29e4292b642d547644e26fab6e193bbfe31d25f07d89a8c35e4d0993d'
            '44679801b740ddb75edd4b55031c5f70a02eaf4f8e5eba5f3ad1b397b2ec4aed'
            '173965285e2494cc001cf05fbbce815c31af5a3eda65e435f52070462cbad634')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying $_patch"
    patch -Nbp1 -i "${srcdir}/$_patch"
  done
}

del_file_exists() {
  for _fname in "$@"
  do
    if [ -f $_fname ]; then
      rm -rf $_fname
    fi
  done
}
# =========================================== #
prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  apply_patch_with_msg \
   0004-mingw-disable-java.patch

  # Required for static linking in 32 bit, adds stdcall decorations in static libs
  apply_patch_with_msg \
    0006-openjpeg-2.1.0-stdcall-for-all-win.patch

  # https://github.com/uclouvain/openjpeg/issues/1595
  apply_patch_with_msg \
    1ad9bec2c12ee445ce23e660f5e4fe870b9d5e09.patch
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  msg "Build static version"
  mkdir -p "${srcdir}"/build-static-${MSYSTEM} && cd "${srcdir}"/build-static-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake \
    -G"Ninja" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    ${_extra_config[@]} \
    -DBUILD_SHARED_LIBS=OFF \
    -DBUILD_STATIC_LIBS=ON \
    -DBUILD_TESTING=OFF \
    -DCMAKE_SYSTEM_PREFIX_PATH=${MINGW_PREFIX} \
    -DBUILD_JPIP=OFF \
    -DBUILD_JAVA=OFF \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake --build ./

  msg "Build shared version"
  mkdir -p "${srcdir}"/build-shared-${MSYSTEM} && cd "${srcdir}"/build-shared-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake \
    -G"Ninja" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
    ${_extra_config[@]} \
    -DBUILD_SHARED_LIBS=ON \
    -DBUILD_STATIC_LIBS=OFF \
    -DBUILD_TESTING=ON \
    -DCMAKE_SYSTEM_PREFIX_PATH=${MINGW_PREFIX} \
    -DBUILD_JPIP=ON \
    -DBUILD_JAVA=OFF \
    -DBUILD_DOC=OFF \
    -DBUILD_PKGCONFIG_FILES=ON \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake --build ./
}

package() {
  cd "${srcdir}/build-static-${MSYSTEM}"
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  cd "${srcdir}/build-shared-${MSYSTEM}"
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE

  # remove path reference in cmake
  local PREFIX_WIN=$(cygpath -wm ${MINGW_PREFIX})
  shopt -s globstar
  for _f in "${pkgdir}${MINGW_PREFIX}"/lib/cmake/**/*.cmake; do
    sed -e "s|${PREFIX_WIN}|\$\{_IMPORT_PREFIX\}|g" -i ${_f}
    sed -e "s|${MINGW_PREFIX}|\$\{_IMPORT_PREFIX\}|g" -i ${_f}
  done
}
