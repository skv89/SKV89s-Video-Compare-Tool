# Maintainer: kasper93 <kasper93@gmail.com>

_realname=libdovi
_sourcename=dovi_tool-${_realname}
pkgbase=mingw-w64-${_realname}
pkgname=${MINGW_PACKAGE_PREFIX}-${_realname}
pkgver=3.4.0
pkgrel=1
pkgdesc='Library to read and write Dolby Vision metadata (C-API)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/quietvoid/dovi_tool/tree/main/dolby_vision'
msys2_repository_url='https://github.com/quietvoid/dovi_tool'
license=('spdx:MIT')
msys2_references=(
  'archlinux: libdovi'
  'purl: pkg:cargo/dolby_vision'
  'purl: pkg:github/quietvoid/dovi_tool'
)
makedepends=("${MINGW_PACKAGE_PREFIX}-rust"
             "${MINGW_PACKAGE_PREFIX}-cargo-c")
source=("${msys2_repository_url}/archive/libdovi-${pkgver}.tar.gz")
sha256sums=('8eac4d1c3134f53e8eb216db6450307a737425844113e480d1e9713c142a9fa2')

prepare() {
  cd "${srcdir}/${_sourcename}-${pkgver}/dolby_vision"

  cargo fetch --target "${RUST_CHOST}"
}

build() {
  cd "${srcdir}/${_sourcename}-${pkgver}/dolby_vision"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    cargo cbuild \
      --meson-paths \
      --release \
      --frozen \
      --all-features \
      --prefix="${MINGW_PREFIX}"
}

check() {
  cd "${srcdir}/${_sourcename}-${pkgver}/dolby_vision"

  cargo test \
    --release \
    --frozen \
    --all-features
}

package() {
  cd "${srcdir}/${_sourcename}-${pkgver}/dolby_vision"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    cargo cinstall \
        --meson-paths \
        --release \
        --frozen \
        --all-features \
        --prefix="${MINGW_PREFIX}" \
        --destdir="${pkgdir}"

  install -Dm644 LICENSE "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
