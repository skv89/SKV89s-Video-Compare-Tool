# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>

_realname=zvbi
pkgbase="mingw-w64-${_realname}"
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=0.2.46
pkgrel=1
pkgdesc='VBI capture and decoding library (mingw-w64)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='http://zapping.sourceforge.net/cgi-bin/view/ZVBI/WebHome'
msys2_repository_url='https://github.com/zapping-vbi/zvbi'
msys2_references=(
  "cpe: cpe:/a:zapping-vbi:zvbi"
)
license=('spdx:GPL-2.0-or-later AND BSD-2-Clause AND LGPL-2.1-or-later AND MIT')
depends=(
  "${MINGW_PACKAGE_PREFIX}-gettext-runtime"
  "${MINGW_PACKAGE_PREFIX}-libiconv"
  "${MINGW_PACKAGE_PREFIX}-libpng"
  "${MINGW_PACKAGE_PREFIX}-libwinpthread"
)
makedepends=(
  'git'
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-gettext-tools"
)
source=(
  "git+https://github.com/zapping-vbi/zvbi.git#tag=v${pkgver}"
  "0001-zvbi-no-undefined.patch"
)
sha256sums=('6bfa25de6d2aa560dd52cb48ee0a12562597e441e4de33752016a6852c9a8601'
            'c29b9fb68e48dee88b6a881478a51ce6b7277f5b3c2fedbfab71cd0270c66e47')

prepare() {
  cd "${_realname}"

  git apply "${srcdir}/0001-zvbi-no-undefined.patch"

  NOCONFIGURE=1 ./autogen.sh
}

build() {
  mkdir -p "build-${MSYSTEM}" && cd "build-${MSYSTEM}"

  "../${_realname}/configure" \
    --prefix="${MINGW_PREFIX}" \
    --build="${MINGW_CHOST}" \
    --host="${MINGW_CHOST}" \
    --target="${MINGW_CHOST}" \
    --disable-examples \
    --disable-tests \
    --enable-static \
    --enable-shared

  make
}

package() {
  cd "build-${MSYSTEM}"

  make install DESTDIR="${pkgdir}"

  cd "${srcdir}/${_realname}"
  install -Dm644 COPYING.md -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}"
}
