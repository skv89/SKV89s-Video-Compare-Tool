# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libdvdread
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=7.1.1
pkgrel=1
pkgdesc="Provides a simple foundation for reading DVD video disks (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.videolan.org/developers/libdvdnav.html"
msys2_repository_url="https://code.videolan.org/videolan/libdvdread"
license=('spdx:GPL-2.0-or-later')
makedepends=(
    "${MINGW_PACKAGE_PREFIX}-meson"
    "${MINGW_PACKAGE_PREFIX}-ninja"
    "${MINGW_PACKAGE_PREFIX}-pkgconf"
    "${MINGW_PACKAGE_PREFIX}-cc"
)
depends=("${MINGW_PACKAGE_PREFIX}-libdvdcss")
source=("https://code.videolan.org/videolan/libdvdread/-/archive/${pkgver}/libdvdread-${pkgver}.tar.gz")
sha256sums=('01a690d1b442dfbbf66e5bbe58604ddc42d5aba4334b7c9680d9d4dbd116c74d')
validpgpkeys=('65F7C6B4206BD057A7EB73787180713BE58D1ADC') # VideoLAN Release Signing Key

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      "build-${MSYSTEM}" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package() {
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
