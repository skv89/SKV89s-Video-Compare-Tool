# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libunistring
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.4.2
pkgrel=1
pkgdesc="Library for manipulating Unicode strings and C strings. (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.gnu.org/software/libunistring"
msys2_repository_url="https://git.savannah.gnu.org/gitweb/?p=libunistring.git"
msys2_references=(
  "cpe: cpe:2.3:a:gnu:libunistring"
)
license=('spdx:LGPL-3.0-or-later OR GPL-3.0-or-later')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
depends=("${MINGW_PACKAGE_PREFIX}-libiconv")
source=("https://ftp.gnu.org/gnu/libunistring/${_realname}-${pkgver}.tar.gz"{,.sig})
sha256sums=('e82664b170064e62331962126b259d452d53b227bb4a93ab20040d846fec01d8'
            'SKIP')
validpgpkeys=('E0FFBD975397F77A32AB76ECB6301D9E1BBEAC08') # Bruno Haible (Free Software Development) <bruno@clisp.org>

prepare() {
  cd "${srcdir}"/libunistring-${pkgver}
  autoreconf -fiv
}

build() {
  #export lt_cv_deplibs_check_method='pass_all'
  mkdir -p "${srcdir}/build-static-${MSYSTEM}" && cd "${srcdir}/build-static-${MSYSTEM}"

  ../libunistring-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --enable-threads=windows \
    --disable-shared

  make

  mkdir -p "${srcdir}/build-shared-${MSYSTEM}" && cd "${srcdir}/build-shared-${MSYSTEM}"
  ../libunistring-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --enable-threads=windows \
    --disable-static

  make
}

package() {
  cd "${srcdir}/build-static-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}/build-shared-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING.LIB" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE.LIB"
}
