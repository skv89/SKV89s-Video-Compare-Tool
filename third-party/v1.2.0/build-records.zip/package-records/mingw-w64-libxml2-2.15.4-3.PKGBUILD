# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=libxml2
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         $([[ ${MSYSTEM} == MINGW* ]] || echo "${MINGW_PACKAGE_PREFIX}-${_realname}-docs"))
pkgver=2.15.4
pkgrel=3
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
pkgdesc="XML parsing library, version 2 (mingw-w64)"
depends=(
  "${MINGW_PACKAGE_PREFIX}-libiconv"
  "${MINGW_PACKAGE_PREFIX}-zlib"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-docbook-xsl"
  $([[ ${MSYSTEM} == MINGW* ]] || echo "${MINGW_PACKAGE_PREFIX}-doxygen")
  "${MINGW_PACKAGE_PREFIX}-libxslt"
  $([[ ${MSYSTEM} == MINGW* ]] || echo "${MINGW_PACKAGE_PREFIX}-python")
)
if [[ ${MSYSTEM} != MINGW* ]]; then
optdepends=("${MINGW_PACKAGE_PREFIX}-python: Python bindings")
fi
license=('spdx:MIT')
url="https://gitlab.gnome.org/GNOME/libxml2/-/wikis/home"
msys2_repository_url="https://gitlab.gnome.org/GNOME/libxml2"
msys2_references=(
  "cpe: cpe:/a:xmlsoft:libxml2"
)
install=${_realname}-${MSYSTEM}.install
source=("https://download.gnome.org/sources/libxml2/${pkgver%.*}/${_realname}-${pkgver}.tar.xz"
        https://www.w3.org/XML/Test/xmlts20130923.tar.gz
        0001-do-not-export-DllMain.patch
        0029-xml2-config-win-paths.patch
        0031-apply-msvc-relocation.patch
        0032-cmake-relocation.patch)
sha256sums=('98087fd181d9070724f3fbc65c7377db03038eb92bd882374daff44940138821'
            '9b61db9f5dbffa545f4b8d78422167083a8568c59bd1129f94138f936cf6fc1f'
            'baad28b724738464cebf1a4e3320111b848fd7b14619e5c0134784ef7ad2aa3a'
            '278b4531da3d2aabda080c412c5122b471202dd6df67768b38bb0c31c7a0e508'
            'bcb2565878e524df3e3bcd1631dbcefc205e9b435a2e537c1810996b97c4dd4a'
            'd2bd68da35aa68197f1b0ebed2c01685a7f4c780430840784a861a540d05b130')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _fname in "$@"
  do
    msg2 "Applying ${_fname}"
    patch -Nbp1 -i "${srcdir}"/${_fname}
  done
}
# =========================================== #

prepare() {
  cd "${_realname}-${pkgver}"

  # https://github.com/msys2/MINGW-packages/issues/17820
  # https://github.com/msys2/MINGW-packages/issues/25716
  apply_patch_with_msg \
    0001-do-not-export-DllMain.patch

  apply_patch_with_msg \
    0031-apply-msvc-relocation.patch \
    0032-cmake-relocation.patch

  # https://github.com/msys2/MINGW-packages/issues/10577
  apply_patch_with_msg \
    0029-xml2-config-win-paths.patch

  NOCONFIGURE=1 ./autogen.sh
}

build() {
  # Static build
  msg2 "Building static for ${MSYSTEM}"
  mkdir -p "${srcdir}"/build-static-${MSYSTEM} && cd "${srcdir}"/build-static-${MSYSTEM}
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --without-python \
    --with-modules \
    --with-legacy \
    --with-http \
    --enable-static \
    --disable-shared \
    --with-threads=win32 \
    CFLAGS="${CFLAGS} -DLIBXML_STATIC_FOR_DLL -DNOLIBTOOL"
  make

  declare -a extra_config
  if [[ ${MSYSTEM} != MINGW* ]]; then
    extra_config+=("--with-python" "--with-docs")
  else
    extra_config+=("--without-python" "--without-docs")
  fi

  # Shared build
  msg2 "Building shared for ${MSYSTEM}"
  mkdir -p "${srcdir}"/build-shared-${MSYSTEM} && cd "${srcdir}"/build-shared-${MSYSTEM}
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --with-modules \
    --with-legacy \
    --with-http \
    --disable-static \
    --enable-shared \
    --with-threads=win32 \
    "${extra_config[@]}"
  make
}

check() {
  cd "${srcdir}"/build-shared-${MSYSTEM}
  cp -r ../xmlconf .
  make check
}

package_libxml2() {
  # First install shared
  make -C "${srcdir}"/build-shared-${MSYSTEM} install DESTDIR="${pkgdir}"

  if [[ ${MSYSTEM} != MINGW* ]]; then
  MSYS2_ARG_CONV_EXCL="-p" python -m compileall \
    -o 0 -o 1 -q -s"${pkgdir}" -p"/" "${pkgdir}${MINGW_PREFIX}/lib/python"*
  fi

  # then manually install static
  install -m 0644 "${srcdir}"/build-static-${MSYSTEM}/.libs/libxml2.a "${pkgdir}${MINGW_PREFIX}"/lib/

  # License
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/Copyright" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"

  # Remove hard coded library path from xlm2-config and libxml-2.0.pc files
  local PREFIX_DEPS=$(cygpath -am ${MINGW_PREFIX})
  sed -s "s|${PREFIX_DEPS}\/lib|\${libdir}|g" -i "${pkgdir}"${MINGW_PREFIX}/bin/xml2-config
  sed -s "s|${PREFIX_DEPS}\/lib|\${libdir}|g" -i "${pkgdir}"${MINGW_PREFIX}/lib/pkgconfig/libxml-2.0.pc

  if [[ ${MSYSTEM} != MINGW* ]]; then
    mkdir -p dest${MINGW_PREFIX}/share
    mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share
  fi
}

package_libxml2-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
