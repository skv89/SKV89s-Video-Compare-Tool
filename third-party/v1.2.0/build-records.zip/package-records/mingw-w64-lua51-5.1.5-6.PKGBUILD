# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: David Macek <david.macek.0@gmail.com>
# Contributor: Ray Donnelly <mingw.android@gmail.com>

_realname=lua51
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=5.1.5
pkgrel=6
pkgdesc="A powerful light-weight programming language designed for extending applications. Version 5.1.x (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clang32' 'clangarm64')
url="https://www.lua.org/"
license=('MIT')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc")
options=('staticlibs' 'strip' 'emptydirs')
source=("${url}/ftp/lua-${pkgver}.tar.gz"
        '0001-When-running-lua-on-mintty-or-other.patch'
        '0002-Add-Wl-out-implib-liblua.dll.a-to-AR.patch'
        '0003-Fix-LUA_-DIR-for-MSYS2-FHS-layout.patch'
        'link-implib.patch')
sha256sums=('2640fc56a795f29d28ef15e13c34a47e223960b0240e8cb0a82d9b0738695333'
            'c4ec5b93ee9d0025db9c68a1f795e1065d46ba429d1c1abb521d2629140281a4'
            'd7b455d7b5caed9f3870d0bcc726c724e8b1d8e3f0cae8578bb2148939ffe0a2'
            '799f9d7d033dc401fad86e1c0accc7d2ce187b9caacb9f565468c30a5d22dd38'
            '0dbc3265b6c5270e213fdf3a37beb810bbbf077a8fefc8c886f34a616e9ebd8f')

prepare() {
  cd "${srcdir}/lua-${pkgver}"

  sed -r -e '/^LUA_(SO|A|T)=/ s/lua/lua5.1/' \
    -e '/^LUAC_T=/ s/luac/luac5.1/' \
    -e 's/lua.exe/lua5.1.exe/' \
    -e 's/luac.exe/luac5.1.exe/' \
    -e 's/luac.exe/luac5.1.exe/' \
    -i src/Makefile
  rm -f src/iscygpty.{c,h} || true
  patch -p1 -i "${srcdir}/0001-When-running-lua-on-mintty-or-other.patch"
  patch -p1 -i "${srcdir}/0002-Add-Wl-out-implib-liblua.dll.a-to-AR.patch"
  patch -p1 -i "${srcdir}/0003-Fix-LUA_-DIR-for-MSYS2-FHS-layout.patch"
  patch -p1 -i "${srcdir}/link-implib.patch"
}

build() {
  [[ -d "${srcdir}/build-${CARCH}" ]] && rm -rf "${srcdir}/build-${CARCH}"
  cp -rf "${srcdir}/lua-${pkgver}" "${srcdir}/build-${CARCH}"
  cd "${srcdir}/build-${CARCH}"
  sed -e 's:llua:llua5.1:' \
    -e 's:/include:/include/lua5.1:' \
    -e "s:/usr/local:${MINGW_PREFIX}:" \
    -i etc/lua.pc

  make -j1 \
    AR="ar rcu" \
    RANLIB="ranlib" \
    STRIP="strip" \
    CC="${CC}" \
    mingw
}

package() {
  cd "${srcdir}/build-${CARCH}"
  make \
    TO_BIN="lua5.1.exe luac5.1.exe lua51.dll" \
    TO_LIB="liblua5.1.a liblua5.1.dll.a" \
    INSTALL_DATA='cp -d' \
    INSTALL_TOP="${pkgdir}${MINGW_PREFIX}" \
    INSTALL_INC="${pkgdir}${MINGW_PREFIX}"/include/lua5.1 \
    INSTALL_MAN="${pkgdir}${MINGW_PREFIX}"/share/man/man1 \
    install

  install -Dm644 etc/lua.pc "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/lua5.1.pc

  # Install the documentation
  install -d "${pkgdir}${MINGW_PREFIX}"/share/doc/$_realname
  install -m644 doc/*.{gif,png,css,html} "${pkgdir}${MINGW_PREFIX}"/share/doc/${_realname}
  install -Dm644 COPYRIGHT "${pkgdir}${MINGW_PREFIX}"/share/licenses/${_realname}/COPYRIGHT

  cd "${pkgdir}${MINGW_PREFIX}"/share/man/man1
  mv lua.1 lua5.1.1
  mv luac.1 luac5.1.1
}
