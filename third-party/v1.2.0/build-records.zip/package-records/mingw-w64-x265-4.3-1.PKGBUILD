# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Yuta Nakai <nak5124@live.jp>

_realname=x265
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=4.3
pkgrel=1
pkgdesc='Open Source H265/HEVC video encoder (mingw-w64)'
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('GPL')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-cc"
   $([[ "${CARCH}" != "x86_64" ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm")
)
url='https://www.x265.org'
msys2_repository_url='https://github.com/Multicorewareinc/x265'
msys2_changelog_url='https://x265.readthedocs.io/en/master/releasenotes.html'
msys2_references=(
  "cpe: cpe:/a:multicorewareinc:x265"
  "cpe: cpe:/a:multicorewareinc:x265_high_efficiency_video_coding"
)
source=("${_realname}-${pkgver}.tar.gz"::"https://github.com/Multicorewareinc/x265/releases/download/${pkgver}/x265_${pkgver}.tar.gz"
        "0001-missing-include.patch")
sha256sums=('83c53e4c8bbb8f1e33ed59e10a7d621d1d7801ca853910c3eb41f038b8ffb121'
            '20e240c5365665e254b6030a458376fac16c1797903d607cae5863b280859a8f')


prepare() {
  cd "${srcdir}"/x265_${pkgver}

  patch -p1 -i "${srcdir}"/0001-missing-include.patch

  for d in 8 10 12; do
    if [[ -d "${srcdir}"/build-${MSYSTEM}-${d} ]]; then
      rm -rf "${srcdir}"/build-${MSYSTEM}-${d}
    fi
    mkdir -p "${srcdir}"/build-${MSYSTEM}-${d}
  done
}


build() {
  if [ "${CARCH}" = 'x86_64' ]; then
    _ENABLE_ASM=ON
  else
    _ENABLE_ASM=OFF
  fi

  # 12-bit
  cd "${srcdir}/build-${MSYSTEM}-12"
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  cmake \
    -G Ninja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DHIGH_BIT_DEPTH=ON \
    -DMAIN12=ON \
    -DEXPORT_C_API=OFF \
    -DENABLE_CLI=OFF \
    -DENABLE_SHARED=OFF \
    -DENABLE_ASSEMBLY=${_ENABLE_ASM} \
  ../x265_${pkgver}/source
  cmake --build .

  # 10-bit
  cd "${srcdir}/build-${MSYSTEM}-10"
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  cmake \
    -G Ninja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DHIGH_BIT_DEPTH=ON \
    -DEXPORT_C_API=OFF \
    -DENABLE_CLI=OFF \
    -DENABLE_SHARED=OFF \
    -DENABLE_ASSEMBLY=${_ENABLE_ASM} \
  ../x265_${pkgver}/source
  cmake --build .

  # 8-bit
  cd "${srcdir}/build-${MSYSTEM}-8"
  ln -s ../build-${MSYSTEM}-10/libx265.a libx265_main10.a
  ln -s ../build-${MSYSTEM}-12/libx265.a libx265_main12.a
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  cmake \
    -G Ninja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DENABLE_SHARED=ON \
    -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
    -DENABLE_ASSEMBLY=${_ENABLE_ASM} \
    -DENABLE_HDR10_PLUS=ON \
    -DEXTRA_LIB='x265_main10.a;x265_main12.a' \
    -DEXTRA_LINK_FLAGS='-L .' \
    -DLINKED_10BIT=ON \
    -DLINKED_12BIT=ON \
  ../x265_${pkgver}/source
  cmake --build .

  # merge
  mv libx265.a libx265_main.a
  ar -M <<EOF
CREATE libx265.a
ADDLIB libx265_main.a
ADDLIB libx265_main10.a
ADDLIB libx265_main12.a
SAVE
END
EOF
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-8"

  DESTDIR="${pkgdir}" cmake --install .

  # Properly install missing libhdr10plus.dll
  install -Dm644 libhdr10plus.dll "${pkgdir}libhdr10plus.dll"
}
