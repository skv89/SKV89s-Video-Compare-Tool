# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Andrew Sun <adsun701@gmail.com>

_realname=libwebp
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.6.0
pkgrel=1
pkgdesc="A library to encode and decode images in WebP format (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://developers.google.com/speed/webp/'
msys2_repository_url="https://github.com/webmproject/libwebp"
msys2_references=(
  "cpe: cpe:/a:webmproject:libwebp"
)
license=('spdx:BSD-3-Clause')
depends=("${MINGW_PACKAGE_PREFIX}-giflib"
         "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
         "${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-libtiff")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
provides=("${MINGW_PACKAGE_PREFIX}-libsharpyuv")
source=(${msys2_repository_url}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz
        0001-mingw-cmake-output.patch)
sha256sums=('93a852c2b3efafee3723efd4636de855b46f9fe1efddd607e1f42f60fc8f2136'
            '30ed42b782af427f57049abada30ce6d4d62318ee13014585cb352b570c68e3d')
validpgpkeys=('6B0E6B70976DE303EDF2F601F9C3D6BDB8232B5D')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  patch -Np1 -i "${srcdir}"/0001-mingw-cmake-output.patch
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  cd "${srcdir}/${_realname}-${pkgver}"
  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    "${MINGW_PREFIX}"/bin/cmake.exe \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -DWEBP_ENABLE_SWAP_16BIT_CSP=ON \
      -DWEBP_BUILD_ANIM_UTILS=OFF \
      -DWEBP_BUILD_CWEBP=OFF \
      -DWEBP_BUILD_DWEBP=OFF \
      -DWEBP_BUILD_GIF2WEBP=OFF \
      -DWEBP_BUILD_IMG2WEBP=OFF \
      -DWEBP_BUILD_VWEBP=OFF \
      -DWEBP_BUILD_WEBPINFO=OFF \
      -DWEBP_BUILD_WEBPMUX=OFF \
      -DWEBP_BUILD_EXTRAS=OFF \
      ../${_realname}-${pkgver}

  "${MINGW_PREFIX}"/bin/cmake.exe --build .

  cd "${srcdir}/${_realname}-${pkgver}"
  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    "${MINGW_PREFIX}"/bin/cmake.exe \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DWEBP_ENABLE_SWAP_16BIT_CSP=ON \
      -DWEBP_BUILD_ANIM_UTILS=OFF \
      -DWEBP_BUILD_VWEBP=OFF \
      -DWEBP_BUILD_EXTRAS=OFF \
      ../${_realname}-${pkgver}

  "${MINGW_PREFIX}"/bin/cmake.exe --build .
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-static"

  DESTDIR="${pkgdir}" "${MINGW_PREFIX}"/bin/cmake.exe --install .

  cd "${srcdir}/build-${MSYSTEM}-shared"

  DESTDIR="${pkgdir}" "${MINGW_PREFIX}"/bin/cmake.exe --install .

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING
}
