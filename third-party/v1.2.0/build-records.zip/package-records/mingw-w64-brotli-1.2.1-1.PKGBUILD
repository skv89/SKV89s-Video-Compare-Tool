# Maintainer: J. Peter Mugaas <jpmugaas@suddenlink.net>
# Contributor: Dirk Stolle

_realname=brotli
pkgbase="mingw-w64-${_realname}"
pkgname=(
  "${MINGW_PACKAGE_PREFIX}-${_realname}"
  $([[ ${CARCH} == i686 ]] || echo "${MINGW_PACKAGE_PREFIX}-brotli-testdata")
)
pkgver=1.2.1
pkgrel=1
pkgdesc="Brotli compression library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/google/brotli'
msys2_repository_url='https://github.com/google/brotli'
msys2_references=(
  'anitya: 15235'
  'cpe: cpe:/a:google:brotli'
  'gentoo: app-arch/brotli'
)
license=('spdx:MIT')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
)
source=("https://github.com/google/brotli/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('98d35d11a78dc453aebb7d10c3748f3f73ff78c8267c0dc697b8631f67bf7e8f')

build() {
  cd "${srcdir}/${_realname}-${pkgver}"

  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake --build .

  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    ${MINGW_PREFIX}/bin/cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake --build .
}

check() {
  cd "${srcdir}"/build-${MSYSTEM}-static
  ${MINGW_PREFIX}/bin/ctest . || warning "Tests failed"

  cd "${srcdir}"/build-${MSYSTEM}-shared
  ${MINGW_PREFIX}/bin/ctest . || warning "Tests failed"
}

package_brotli() {
  cd "${srcdir}"/build-${MSYSTEM}-static
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  cd "${srcdir}"/build-${MSYSTEM}-shared
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  install -D -m644 "${srcdir}"/brotli-${pkgver}/LICENSE \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
}

package_brotli-testdata() {
  depends=("${MINGW_PACKAGE_PREFIX}-${_realname}")

  cd brotli-${pkgver}
  install -dm755 "${pkgdir}${MINGW_PREFIX}/share/brotli"
  cp -a tests/testdata "$pkgdir${MINGW_PREFIX}/share/brotli/"
  install -D -m644 "${srcdir}"/brotli-${pkgver}/LICENSE "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}-testdata/LICENSE"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
