# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libdvdnav
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=7.0.0
pkgrel=2
pkgdesc="The library for xine-dvdnav plugin (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.videolan.org/developers/libdvdnav.html"
msys2_repository_url="https://code.videolan.org/videolan/libdvdnav"
license=('spdx:GPL-2.0-or-later')
makedepends=(
    "${MINGW_PACKAGE_PREFIX}-meson"
    "${MINGW_PACKAGE_PREFIX}-ninja"
    "${MINGW_PACKAGE_PREFIX}-pkgconf"
    "${MINGW_PACKAGE_PREFIX}-cc"
)
depends=("${MINGW_PACKAGE_PREFIX}-libdvdread")
source=("https://code.videolan.org/videolan/libdvdnav/-/archive/${pkgver}/libdvdnav-${pkgver}.tar.gz"
        "https://code.videolan.org/videolan/libdvdnav/-/merge_requests/64.patch")
sha256sums=('15d28086937647a95c3d6b083f0a86678cd4dd428914e319c64adf52cadec786'
            '9eb8a19c4b0097f28be923026c9af05416e77ac43129cae853555607c6306e08')
validpgpkeys=('65F7C6B4206BD057A7EB73787180713BE58D1ADC') # VideoLAN Release Signing Key


prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}

  patch -p1 -i "${srcdir}/64.patch"
}

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      "build-${MSYSTEM}" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package() {
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
