# Maintainer: Miloš Komarčević <miloskomarcevic@aim.com>

_realname=highway
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.4.0
pkgrel=3
pkgdesc="C++ library for SIMD (Single Instruction, Multiple Data) (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/google/highway'
msys2_repository_url='https://github.com/google/highway'
msys2_references=(
  'anitya: 205809'
  'gentoo: dev-cpp/highway'
  'purl: pkg:github/google/highway'
)
license=('spdx:Apache-2.0')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
#checkdepends=("${MINGW_PACKAGE_PREFIX}-gtest")
source=("${msys2_repository_url}/releases/download/${pkgver}/${_realname}-${pkgver}.tar.gz"{,.asc})
sha256sums=('36f672ab48ddb3c8555e9e89e16fe400cd7d16c6eb455a1a3d0c146a63ababdc'
            'SKIP')
validpgpkeys=('1EE19F760E8995DEB6E7EAA8D37698ED2BD17D7F')

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  # Static build
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -DBUILD_TESTING=OFF \
      -S ${_realname}-${pkgver} \
      -B build-${MSYSTEM}-static

  cmake --build build-${MSYSTEM}-static

  # Shared build
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DBUILD_TESTING=OFF \
      -S ${_realname}-${pkgver} \
      -B build-${MSYSTEM}-shared

  cmake --build build-${MSYSTEM}-shared
}

# Must build w/ -DBUILD_TESTING=ON and -DHWY_SYSTEM_GTEST=ON above
#check() {
#  cd "${srcdir}"/build-${MSYSTEM}-static
#
#  ${MINGW_PREFIX}/bin/cmake --build . --target test
#}

package() {
  # Static install
  DESTDIR="${pkgdir}" cmake --install build-${MSYSTEM}-static

  # Shared install
  DESTDIR="${pkgdir}" cmake --install build-${MSYSTEM}-shared

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
}
