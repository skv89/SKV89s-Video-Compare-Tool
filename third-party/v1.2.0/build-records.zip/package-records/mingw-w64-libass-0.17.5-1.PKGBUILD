# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libass
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.17.5
pkgrel=1
pkgdesc="A portable library for SSA/ASS subtitles rendering (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/libass/libass'
msys2_repository_url='https://github.com/libass/libass'
msys2_references=(
  "cpe: cpe:/a:libass_project:libass"
)
license=('spdx:ISC')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  $([[ "${MSYSTEM}" == "CLANGARM64" ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm")
)
depends=("${MINGW_PACKAGE_PREFIX}-fribidi"
         "${MINGW_PACKAGE_PREFIX}-fontconfig"
         "${MINGW_PACKAGE_PREFIX}-freetype"
         "${MINGW_PACKAGE_PREFIX}-libunibreak"
         "${MINGW_PACKAGE_PREFIX}-libiconv"
         "${MINGW_PACKAGE_PREFIX}-harfbuzz")
source=(https://github.com/libass/${_realname}/releases/download/${pkgver}/${_realname}-${pkgver}.tar.xz)
sha256sums=('2dca25c0e0c837ddf00b52011b3f82cac1e4ddd3ad018227806b0c2288864acc')

build() {
  CPPFLAGS+=" -DFRIBIDI_LIB_STATIC" \
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=static \
      -Dcoretext=disabled \
      "build-${MSYSTEM}-static" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=shared \
      -Dcoretext=disabled \
      "build-${MSYSTEM}" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package() {
  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"
  meson install -C "build-${MSYSTEM}" --destdir "${pkgdir}"
}
