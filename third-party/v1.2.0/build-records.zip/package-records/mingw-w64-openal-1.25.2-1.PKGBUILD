# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=openal
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.25.2
pkgrel=1
pkgdesc="OpenAL audio library for use with opengl (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/kcat/openal-soft"
msys2_repository_url='https://github.com/kcat/openal-soft'
license=('spdx:GPL-2.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-libmysofa")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-fluidsynth"
             "${MINGW_PACKAGE_PREFIX}-portaudio")
source=("https://github.com/kcat/openal-soft/archive/${pkgver}/${_realname}-${pkgver}.tar.gz"
        '0001-dll-name.patch'
        '0003-openal-not-32.mingw.patch'
        '0004-pkgconfig-add-Cflags-private.patch'
        '0005-mingw-dont-check-libm.patch')
sha256sums=('fb27e5839aa11f0e5b9d33756965291fad5d6909ab928ea1f796f4a1a6877894'
            'fda6cd11b16dadb6eb391b0854c8694938cb722b2df49fd65e0575af99344a14'
            '33dccfc603a48d265341e60bc801976d077e546ab5c91a93e8426eac01bb7ad4'
            'fb62d0ee19f79dc8990686c4341e1bdbc5fe91418f8deb7267b9fb3887a18e83'
            '6b1fa164c4d515dae069a1fcee226a555969b1b981379648ac4e11c742493512')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying $_patch"
    patch -Np1 -i "${srcdir}/$_patch"
  done
}

prepare() {
  mv "${srcdir}/openal-soft-${pkgver}" "${srcdir}/${_realname}-${pkgver}"
  cd "${srcdir}/${_realname}-${pkgver}"

  apply_patch_with_msg \
    0001-dll-name.patch \
    0003-openal-not-32.mingw.patch \
    0004-pkgconfig-add-Cflags-private.patch \
    0005-mingw-dont-check-libm.patch
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  # https://github.com/kcat/openal-soft/issues/1287
  _extra_config+=("-DALSOFT_ENABLE_MODULES=OFF")

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
      "${_extra_config[@]}" \
      -DALSOFT_EXAMPLES=OFF \
      -DALSOFT_UTILS=ON \
      -DALSOFT_NO_CONFIG_UTIL=ON \
      -DLIBTYPE=SHARED \
      -S ${_realname}-${pkgver} \
      -B build-shared-${MSYSTEM}

  cmake --build build-shared-${MSYSTEM}

  # enabling utilities on static causes an undefined reference error.
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${_extra_config[@]}" \
      -DALSOFT_EXAMPLES=OFF \
      -DALSOFT_UTILS=OFF \
      -DALSOFT_NO_CONFIG_UTIL=ON \
      -DLIBTYPE=STATIC \
      -S ${_realname}-${pkgver} \
      -B build-static-${MSYSTEM}

  cmake --build build-static-${MSYSTEM}
}

check() {
  cmake -DALSOFT_TESTS=ON -S ${_realname}-${pkgver} -B build-shared-${MSYSTEM}
  cmake --build build-shared-${MSYSTEM}
  ctest --test-dir build-shared-${MSYSTEM} --output-on-failure || true
}

package() {
  DESTDIR="${pkgdir}" cmake --install build-static-${MSYSTEM}

  DESTDIR="${pkgdir}" cmake --install build-shared-${MSYSTEM}
}
