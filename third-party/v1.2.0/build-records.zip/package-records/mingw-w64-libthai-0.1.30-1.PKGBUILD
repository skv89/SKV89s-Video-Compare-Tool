# Maintainer: Andrew Sun <adsun701@gmail.com>

_realname=libthai
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-docs")
pkgver=0.1.30
pkgrel=1
pkgdesc="Thai language support routines (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://linux.thai.net/projects/libthai"
msys2_repository_url="https://github.com/tlwg/libthai"
msys2_references=(
  "cpe: cpe:/a:linux.thai:libthai"
)
license=('spdx:LGPL-2.1-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-libdatrie")
makedepends=("autoconf-archive"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-doxygen")
source=("https://linux.thai.net/pub/thailinux/software/libthai/${_realname}-${pkgver}.tar.xz"
        'relocatable.patch')
sha256sums=('ddba8b53dfe584c3253766030218a88825488a51a7deef041d096e715af64bdd'
            'f258c748e37a11ce20d307a9a27cf68de9543d79b7e60ebd31c7cf4398b5f6d9')

prepare() {
  cd "${srcdir}/libthai-${pkgver}"
  patch -Np1 -i "${srcdir}"/relocatable.patch
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-static \
    --enable-shared

  make
}

package_libthai() {
  optdepends=("${MINGW_PACKAGE_PREFIX}-libthai-docs: Documentation")

  make -C "${srcdir}"/build-${MSYSTEM} install DESTDIR="${pkgdir}"

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING

  # split docs
  mkdir -p dest${MINGW_PREFIX}/share
  mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share/doc
}

package_libthai-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
