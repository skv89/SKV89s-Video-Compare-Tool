# Maintainer: James Ross-Gowan <rossymiles@gmail.com>

_realname=uchardet
pkgbase="mingw-w64-${_realname}"
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.0.8
pkgrel=2
pkgdesc="An encoding detector library ported from Mozilla (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://www.freedesktop.org/wiki/Software/uchardet/'
msys2_repository_url='https://gitlab.freedesktop.org/uchardet/uchardet'
license=('spdx:MPL-1.1')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=("https://www.freedesktop.org/software/uchardet/releases/${_realname}-${pkgver}.tar.xz"
        0001-fix-pkgconfig-files.patch)
sha256sums=('e97a60cfc00a1c147a674b097bb1422abd9fa78a2d9ce3f3fdcc2e78a34ac5f0'
            'c26a5ebdbeea80f7f28d6ea2405ad86a0a7ceb0782f88bd511c05058b81829d7')

prepare() {
  cd "${_realname}-${pkgver}"
  patch -p1 -i "${srcdir}/0001-fix-pkgconfig-files.patch"
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -G"Ninja" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    "${extra_config[@]}" \
    -S ${_realname}-${pkgver} \
    -B build-${MSYSTEM}

  ${MINGW_PREFIX}/bin/cmake.exe --build build-${MSYSTEM}
}

package() {
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install build-${MSYSTEM}

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING
}
