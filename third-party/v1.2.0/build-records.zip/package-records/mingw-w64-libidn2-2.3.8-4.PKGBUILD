# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libidn2
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
_basever=2.3.8
_subver=
pkgver=${_basever}${_subver}
pkgrel=4
pkgdesc="Implementation of the Stringprep, Punycode and IDNA specifications (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.gnu.org/software/libidn/#libidn2"
msys2_repository_url="https://gitlab.com/libidn/libidn2"
msys2_references=(
  "cpe: cpe:/a:gnu:libidn2"
)
license=('spdx:GPL-2.0-or-later' 'spdx:LGPL-3.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-gettext-runtime"
         "${MINGW_PACKAGE_PREFIX}-libiconv"
         "${MINGW_PACKAGE_PREFIX}-libunistring")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-gettext-tools"
  "${MINGW_PACKAGE_PREFIX}-gtk-doc"
)
source=("https://ftp.gnu.org/gnu/libidn/${_realname}-${pkgver}.tar.gz"{,.sig})
sha256sums=('f557911bf6171621e1f72ff35f5b1825bb35b52ed45325dcdee931e5d3c0787a'
            'SKIP')
validpgpkeys=('B1D2BD1375BECB784CF4F8C4D73CF638C53C06BE') # Simon Josefsson <simon@josefsson.org>

prepare() {
  cd "${srcdir}"/${_realname}-${_basever}

  # https://gitlab.com/libidn/libidn2/-/issues/108
  AUTOPOINT=true autoreconf -ivf
}

build() {
  mkdir -p "${srcdir}/build-shared-${MSYSTEM}" && cd "${srcdir}/build-shared-${MSYSTEM}"
  ../${_realname}-${_basever}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-shared \
    --disable-static \
    --disable-doc \
    --disable-rpath

  make

  export CPPFLAGS="$CPPFLAGS -DIN_LIBUNISTRING -DIDN2_STATIC"
  mkdir -p "${srcdir}/build-static-${MSYSTEM}" && cd "${srcdir}/build-static-${MSYSTEM}"
  ../${_realname}-${_basever}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-static \
    --disable-shared \
    --disable-doc \
    --disable-rpath

  make
}

check() {
  make check -C build-shared-${MSYSTEM} || warning "Tests failed"
  make check -C build-static-${MSYSTEM} || warning "Tests failed"
}

package() {
  cd "${srcdir}/build-static-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}/build-shared-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  find "${pkgdir}${MINGW_PREFIX}" -name '*.def' -o -name '*.exp' | xargs -rtl1 rm
}
