# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libbluray
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.5.0
pkgrel=1
pkgdesc="Library to access Blu-Ray disks for video playback (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://www.videolan.org/developers/libbluray.html'
msys2_repository_url='https://code.videolan.org/videolan/libbluray'
msys2_references=(
  "cpe: cpe:/a:videolan:libbluray"
)
license=('spdx:LGPL-2.1-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-libxml2"
         "${MINGW_PACKAGE_PREFIX}-freetype")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
  "${MINGW_PACKAGE_PREFIX}-cc")
source=(https://download.videolan.org/pub/videolan/libbluray/${pkgver}/${_realname}-${pkgver}.tar.xz)
sha256sums=('f676408e91a5d321abf8b8d4dfdae36205c297dab5c54c3ec519639025f474a2')

build() {
  mkdir -p "${srcdir}/build-static-${MSYSTEM}" && cd "${srcdir}/build-static-${MSYSTEM}"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  meson setup \
    --prefix="${MINGW_PREFIX}" \
    --wrap-mode=nodownload \
    --auto-features=enabled \
    --buildtype=plain \
    --default-library=static \
    -Dc_args="-DLIBXML_STATIC" \
    -Denable_examples=true \
    -Dbdj_jar=disabled \
    -Dlibxml2=enabled \
    -Dfreetype=enabled \
    "../${_realname}-${pkgver}"

  meson compile

  mkdir -p "${srcdir}/build-shared-${MSYSTEM}" && cd "${srcdir}/build-shared-${MSYSTEM}"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  meson setup \
    --prefix="${MINGW_PREFIX}" \
    --wrap-mode=nodownload \
    --auto-features=enabled \
    --buildtype=plain \
    --default-library=shared \
    -Denable_examples=true \
    -Dbdj_jar=disabled \
    -Dlibxml2=enabled \
    -Dfreetype=enabled \
    "../${_realname}-${pkgver}"

  meson compile
}

package() {
  cd "${srcdir}/build-static-${MSYSTEM}"
  DESTDIR="${pkgdir}" meson install

  cd "${srcdir}/build-shared-${MSYSTEM}"
  DESTDIR="${pkgdir}" meson install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
