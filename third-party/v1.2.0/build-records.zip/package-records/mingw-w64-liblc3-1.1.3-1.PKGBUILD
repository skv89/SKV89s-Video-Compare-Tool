# Maintainer: Christoph Reiter <reiter.christoph@gmail.com>

_realname=liblc3
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=1.1.3
pkgrel=1
pkgdesc="Low Complexity Communication Codec library and tools (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/google/liblc3'
license=('spdx:Apache-2.0')
makedepends=("${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://github.com/google/liblc3/archive/refs/tags/v${pkgver}.tar.gz")
sha256sums=('276752ff54ce6a77d54ec133397b9d7e71f90caf3d9afa32d8b0e891b8ecb8af')

build() {
  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=static \
      -Db_lto=false \
      "build-${MSYSTEM}-static" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=shared \
      -Db_lto=false \
      "build-${MSYSTEM}-shared" \
      "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}-shared"
}

package() {
  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"
  meson install -C "build-${MSYSTEM}-shared" --destdir "${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
