# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: AlexWMF <alexxwmf@gmail.com>

_realname=libcdio
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=2.4.0
pkgrel=1
pkgdesc="GNU Compact Disc Input and Control Library (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:GPL-3.0-or-later')
url="https://www.gnu.org/software/libcdio/"
msys2_repository_url='https://github.com/libcdio/libcdio'
msys2_references=(
  "cpe: cpe:/a:gnu:libcdio"
)
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
depends=("${MINGW_PACKAGE_PREFIX}-libiconv"
         "${MINGW_PACKAGE_PREFIX}-libcddb")
source=("https://github.com/libcdio/libcdio/releases/download/${pkgver}/libcdio-${pkgver}.tar.bz2"
        libcdio-0.83-linking.patch)
sha256sums=('8e6a305f81e45a78b41ce696d34497cc208d97075469d7304c11a6d44bf006ac'
            'd88186b2a11726fe5ef10853e0245996b55793552b14230d1f7ba5ee3c54f3ed')
validpgpkeys=('DAA63BC2582034A02B923D521A8DE5008275EC21')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  patch -Np1 -i "${srcdir}/libcdio-0.83-linking.patch"
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --disable-vcd-info \
    --enable-cpp-progs \
    --enable-shared \
    --enable-static \
    --disable-rpath \
    $( [[ ${MINGW_PACKAGE_PREFIX} == *-clang-* ]] && echo "--without-versioned-libs" || true )

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make -j1 DESTDIR="${pkgdir}" install

  sed -i "/LIBCDIO_SOURCE_PATH/s|.*|/* #undef LIBCDIO_SOURCE_PATH */|" \
    "${pkgdir}"${MINGW_PREFIX}/include/cdio/cdio_config.h
}
