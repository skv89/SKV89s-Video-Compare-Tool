# Maintainer: Christoph Reiter <reiter.christoph@gmail.com>

_realname=rav1e
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.8.1
pkgrel=1
pkgdesc='An AV1 encoder focused on speed and safety (mingw-w64)'
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
msys2_references=(
  'archlinux: rav1e'
  'purl: pkg:cargo/rav1e'
)
url=https://github.com/xiph/rav1e/
license=('spdx:BSD-2-Clause')
makedepends=("${MINGW_PACKAGE_PREFIX}-rust"
             "${MINGW_PACKAGE_PREFIX}-cargo-c"
             "${MINGW_PACKAGE_PREFIX}-llvm-tools"
             $([[ "${CARCH}" == "aarch64"  ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm"))
options=('!strip')
source=("https://github.com/xiph/rav1e/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('06d1523955fb6ed9cf9992eace772121067cca7e8926988a1ee16492febbe01e')

prepare() {
  cd "${_realname}-${pkgver}"

  cargo fetch --locked
}

build() {
  cd "${_realname}-${pkgver}"

  export WINAPI_NO_BUNDLED_LIBRARIES=1
  cargo build \
    --frozen \
    --profile release-strip

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    cargo capi build \
      --meson-paths \
      --frozen \
      --profile release-strip \
      --prefix="${MINGW_PREFIX}"
}

check() {
  cd "${_realname}-${pkgver}"

  cargo test \
    --frozen \
    --profile release-strip
}

package() {
  cd "${_realname}-${pkgver}"

  cargo install \
    --frozen \
    --offline \
    --no-track \
    --path . \
    --root "${pkgdir}${MINGW_PREFIX}" \
    --profile release-strip

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    cargo capi install \
      --meson-paths \
      --frozen \
      --prefix="${MINGW_PREFIX}" \
      --destdir="${pkgdir}" \
      --profile release-strip

  # Remove def file
  rm -f "${pkgdir}"${MINGW_PREFIX}/lib/*.def
  # Strip static library manually
  if [[ ${MSYSTEM} != CLANG* ]]; then
    llvm-strip -S "${pkgdir}${MINGW_PREFIX}/lib/librav1e.a"
  fi

  install -Dm644 LICENSE PATENTS -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/"
}
