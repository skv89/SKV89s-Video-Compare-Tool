# Maintainer:  Alexey Pavlov <alexpux@gmail.com>
# Contributor: Alexey Borzenkov <snaury@gmail.com>
# Contributor: Ray Donnelly <mingw.android@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>
# Contributor: wirx6 <wirx654@gmail.com>
# Contributor: Kirill Müller <krlmlr@mailbox.org>
# Contributor: dragon-archer <dragon-archer@outlook.com>

if [[ ${CARCH} != i686 ]]; then
  _enable_ada=yes
  _enable_fortran=yes
  _enable_jit=yes
  _enable_lto=yes
  _enable_objc=yes
  _enable_plugin=yes
  _enable_rust=no
else
  _enable_ada=no
  _enable_fortran=no
  _enable_jit=no
  _enable_lto=yes
  _enable_objc=no
  _enable_plugin=no
  _enable_rust=no
fi

_threads="posix"

_realname=gcc
pkgbase=mingw-w64-${_realname}
pkgname=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  "${MINGW_PACKAGE_PREFIX}-gcc"
  $([[ "$_enable_ada" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-ada")
  $([[ "$_enable_fortran" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-fortran")
  "${MINGW_PACKAGE_PREFIX}-gcc-libs"
  $([[ "$_enable_objc" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-objc")
  $([[ "$_enable_plugin" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-plugin")
  $([[ "$_enable_rust" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-rust")
  "${MINGW_PACKAGE_PREFIX}-libatomic"
  "${MINGW_PACKAGE_PREFIX}-libgcc"
  $([[ "$_enable_jit" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-libgccjit")
  $([[ "$_enable_fortran" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-libgfortran")
  "${MINGW_PACKAGE_PREFIX}-libgomp"
  $([[ "$_enable_objc" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-libobjc")
  "${MINGW_PACKAGE_PREFIX}-libquadmath"
  "${MINGW_PACKAGE_PREFIX}-libstdc++"
  $([[ "$_enable_lto" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-lto-dump")
)
_pkgver=16.2.0
_rc=""
_snapshot=
if [[ -z ${_rc} && -z ${_snapshot} ]]; then
  pkgver=${_pkgver}
  _sourcedir=gcc-${pkgver}
  _url=https://ftp.gnu.org/gnu/gcc/gcc-${pkgver}
else
  pkgver=${_pkgver%%.*}.0.1
  if [[ -z ${_rc} ]]; then
    _version=${_pkgver%%.*}
  else
    _version=${_pkgver}-${_rc}
  fi
  _sourcedir=gcc-${_version}-${_snapshot}
  _url=https://gcc.gnu.org/pub/gcc/snapshots/${_version}-${_snapshot}
fi
_libdir=lib/gcc/${CHOST}/${pkgver}
pkgrel=6
pkgdesc="The GNU Compiler Collection (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64')
url="https://gcc.gnu.org"
msys2_repository_url='https://gcc.gnu.org/git/gitweb.cgi?p=gcc.git'
msys2_references=(
  "cpe: cpe:/a:gnu:gcc"
)
license=('spdx:GPL-3.0-or-later WITH GCC-exception-3.1 AND GFDL-1.3-or-later')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-gcc"
  $([[ "$_enable_ada" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-ada")
  $([[ "$_enable_rust" == "yes" ]] && echo "${MINGW_PACKAGE_PREFIX}-gcc-rust")
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-binutils"
  "${MINGW_PACKAGE_PREFIX}-crt"
  "${MINGW_PACKAGE_PREFIX}-headers"
  "${MINGW_PACKAGE_PREFIX}-gmp"
  "${MINGW_PACKAGE_PREFIX}-isl"
  "${MINGW_PACKAGE_PREFIX}-libiconv"
  "${MINGW_PACKAGE_PREFIX}-mpc"
  "${MINGW_PACKAGE_PREFIX}-mpfr"
  "${MINGW_PACKAGE_PREFIX}-python"
  "${MINGW_PACKAGE_PREFIX}-texinfo"
  "${MINGW_PACKAGE_PREFIX}-windows-default-manifest"
  "${MINGW_PACKAGE_PREFIX}-winpthreads"
  "${MINGW_PACKAGE_PREFIX}-zlib"
  "${MINGW_PACKAGE_PREFIX}-zstd"
)
options=('!emptydirs')
source=(${_url}/${_sourcedir}.tar.xz{,.sig}
        "gdbinit"
        0002-i386-Keep-SEH-enabled-for-Win64-sysv_abi-functions.patch
        0003-Windows-Follow-Posix-dir-exists-semantics-more-close.patch
        0007-Build-EXTRA_GNATTOOLS-for-Ada.patch
        0008-Prettify-linking-no-undefined.patch
        0011-Enable-shared-gnat-implib.patch
        0012-Handle-spaces-in-path-for-default-manifest.patch
        0014-gcc-9-branch-clone_function_name_1-Retain-any-stdcall-suffix.patch
        0020-libgomp-Don-t-hard-code-MS-printf-attributes.patch
        0021-bootstrap-gnattools-Pass-target-sysroot-flags-to-boo.patch
        0022-mingw-Remove-outdated-mingw-stuff.patch
        0023-Ada-Don-t-export-gnat1-s-symbols-on-PE-hosts.patch
        0024-libgfortran-Guard-locale-restoration-for-formatted-I0.patch
        0025-libgfortran-Copy-LC_NUMERIC-string-for-formatted-IO.patch
        0140-gcc-diagnostic-color.patch
        0200-add-m-no-align-vector-insn-option-for-i386.patch
        2001-fix-building-rust-on-mingw-w64.patch
        3001-fix-codeview-crashes.patch)
sha256sums=('e6738e29597f733270731aa90600f37ffdc045079dfc27ec7e8192cc81085c3e'
            'SKIP'
            'bce81824fc89e5e62cca350de4c17a27e27a18a1a1ad5ca3492aec1fc5af3234'
            'fdf4e90a56fc195a8f9a969af39335f158a29f29d42d33c00d908fc47cf5ad24'
            '3fc35067823f87e48dd3bfd265e7593000dc110fa9ad5f16c81b896765fc897a'
            '90d5cb570083f9dea4ac0f0f87e3e8d2230f5052e6f9b946061a20a224a9d195'
            '8d2d53ae26b777d90189240494de1b895c5efa1ebdcdfbf5774f29fc742499d9'
            '5ef4148acc4a2b7ed648d4fe75fab5545e84b4b93a12d6ba4e4ea6061dd635fa'
            'e98805ead7d78ee2a92f237894c4b2b7ddc1688e1b517d8c04f28d440202e40f'
            'fd9bdecb2bbc4796bbc9f00b708dac42ef9e3464a06d6d27e5475cee117de5be'
            'ad1f7b5e7afaaec008b7cbd14feea13a10989fa91bda7003af72d457619bb199'
            '76455c46eec4df95a80bbf7e5bcd2d165f300976c79c1baf0bf7ed20f000cdd4'
            'ec05f8f26698dae4e0e0b58189cbf509185ad6d40b4950b33e28b638bf70c7ae'
            '395dd4df29c295f917aa4a136a0aa72af34eee6320ecc2d92ee717397578398d'
            '976d14f803a211b19d9bf0169c08d4fde05af5cc18073f2fc8efc9a3cb17890a'
            'f591efc820a2c72aefb83179f7cbd3f4654231b68700486bd04ee32e2db61de5'
            'c94004dab1685a6fa9124de86aae742df4136a2e9ff5d5e1ad87ecdc35fbcef4'
            '1484911163634f30324827619c873a6267b377abba0df8bbedfd128163c53ea4'
            'a411f59953553a3d01dd64c79b1acbb91eca092c4cb01bfd26b1c51c3eb798e8'
            'f21f9ab731e9cab8fd4ca8c289497f859ef7004e6fa0507877dc2559ac2071c3')
validpgpkeys=(F3691687D867B81B51CE07D9BBE43771487328A9  # bpiotrowski@archlinux.org
              86CFFCA918CF3AF47147588051E8B148A9999C34  # evangelos@foutrelis.com
              13975A70E63C361C73AE69EF6EEB81F8981C74C7  # richard.guenther@gmail.com
              D3A93CAD751C2AF4F8C7AD516C35B99309B5FA62) # Jakub Jelinek <jakub@redhat.com>

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}
# =========================================== #

prepare() {
  cd "${srcdir}"/${_sourcedir}

  # 0002: https://gcc.gnu.org/git/?p=gcc.git;a=patch;h=b0f09b72d9e1783e8ccaf2d8c1c72b03e3973f0b;hp=e88f8d7bfc811f6d152c42ba009255506f5beba1
  apply_patch_with_msg \
    0002-i386-Keep-SEH-enabled-for-Win64-sysv_abi-functions.patch \
    0003-Windows-Follow-Posix-dir-exists-semantics-more-close.patch \
    0007-Build-EXTRA_GNATTOOLS-for-Ada.patch \
    0008-Prettify-linking-no-undefined.patch \
    0011-Enable-shared-gnat-implib.patch \
    0012-Handle-spaces-in-path-for-default-manifest.patch \
    0014-gcc-9-branch-clone_function_name_1-Retain-any-stdcall-suffix.patch \
    0020-libgomp-Don-t-hard-code-MS-printf-attributes.patch \
    0023-Ada-Don-t-export-gnat1-s-symbols-on-PE-hosts.patch \
    0024-libgfortran-Guard-locale-restoration-for-formatted-I0.patch \
    0025-libgfortran-Copy-LC_NUMERIC-string-for-formatted-IO.patch

  # Avoid hardcoding /mingw or D:/M/${MINGW_PREFIX} in the final installation.
  # Make GCC fully relocatable.
  # See https://github.com/msys2/MINGW-packages/pull/29280 for details.
  apply_patch_with_msg \
    0021-bootstrap-gnattools-Pass-target-sysroot-flags-to-boo.patch \
    0022-mingw-Remove-outdated-mingw-stuff.patch

  # Enable diagnostic color under mintty
  # based on https://github.com/BurntSushi/ripgrep/issues/94#issuecomment-261761687
  apply_patch_with_msg \
    0140-gcc-diagnostic-color.patch

  # workaround for AVX misalignment issue for pass-by-value arguments
  #   cf. https://github.com/msys2/MSYS2-packages/issues/1209
  #   cf. https://sourceforge.net/p/mingw-w64/discussion/723797/thread/bc936130/
  #  Issue is longstanding upstream at https://gcc.gnu.org/bugzilla/show_bug.cgi?id=54412
  #  Potential alternative: https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=939559
  # https://github.com/msys2/MINGW-packages/pull/8317#issuecomment-824548411
  apply_patch_with_msg \
    0200-add-m-no-align-vector-insn-option-for-i386.patch

  apply_patch_with_msg \
    2001-fix-building-rust-on-mingw-w64.patch

  # https://gcc.gnu.org/bugzilla/show_bug.cgi?id=120051
  apply_patch_with_msg \
    3001-fix-codeview-crashes.patch

  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("--disable-libstdcxx-debug")
  else
    _extra_config+=("--enable-libstdcxx-debug")
  fi

  local _boot_ldflags="-static-libstdc++"
  if [[ "${CARCH}" == "i686" ]]; then
    _extra_config+=(
      "--disable-sjlj-exceptions"
      "--with-dwarf2"
    )
    # LDFLAGS is only used for stage1, stage2 and later use --with-boot-ldflags
    LDFLAGS+=" -Wl,--large-address-aware"
    _boot_ldflags+=" -Wl,--large-address-aware"
    local _arch=pentium4
  else
    local _arch=nocona
  fi

  local _languages="c,c++"
  if [ "$_enable_ada" == "yes" ]; then
    _languages+=",ada"
  fi
  if [ "$_enable_fortran" == "yes" ]; then
    _languages+=",fortran"
  fi
  if [ "$_enable_lto" == "yes" ]; then
    _languages+=",lto"
    _extra_config+=("--enable-lto")
  else
    _extra_config+=("--disable-lto")
  fi
  if [ "$_enable_objc" == "yes" ]; then
    _languages+=",objc,obj-c++"
  fi
  if [ "$_enable_plugin" == "yes" ]; then
    _extra_config+=("--enable-plugin")
  fi
  if [ "$_enable_rust" == "yes" ]; then
    _languages+=",rust"
  fi
  if [ "$_enable_jit" == "yes" ]; then
    _languages+=",jit"
  fi

  # so libgomp DLL gets built despide static libdl
  export lt_cv_deplibs_check_method='pass_all'

  # This configure check fails with msvcrt due to
  # https://github.com/mingw-w64/mingw-w64/issues/163
  export gcc_cv_have_tls=yes

  # https://gcc.gnu.org/bugzilla/show_bug.cgi?id=125312
  export glibcxx_cv_atomic_word=yes

  # https://gcc.gnu.org/bugzilla/show_bug.cgi?id=105507#c3
  # At least with mingw32 + dwarf-2 exceptions there can only be one libgcc in
  # process, or exceptions will no longer work. Since some of the gcc deps are
  # linked dynamically like gmp/zlib/zstd and those pull in libgcc we can't
  # allow libgcc to be linked statically. The default is "-static-libstdc++
  # -static-libgcc" for both, so we drop "-static-libgcc" here:
  # GCC 14 Update: Since we dropped 32bit Ada with GCC 14.1 and GCC doesn't use
  # exceptions elsewhere this could in theory be removed, in case it makes problems.
  _extra_config+=(
    "--with-boot-ldflags=${_boot_ldflags}"
    '--with-stage1-ldflags="-static-libstdc++"'
  )

  # In addition adaint.c does `#include <accctrl.h>` which pulls in msxml.h, hacky hack:
  CPPFLAGS+=" -DCOM_NO_WINDOWS_H"

  # local-prefix and native-system-header-dir will be prefixed with sysroot, so don't add ${MINGW_PREFIX} here.
  # --with-build-sysroot has to be an Windows path because it's used by gnatlink.exe, which launch xgcc.exe
  # with `System.OS_Lib.Spawn` which doesn't convert paths.
  ../${_sourcedir}/configure \
    --prefix=${MINGW_PREFIX} \
    --with-sysroot=${MINGW_PREFIX} \
    --with-build-sysroot=$(cygpath -m ${MINGW_PREFIX}) \
    --with-local-prefix=/local \
    --with-native-system-header-dir=/include \
    --libexecdir=${MINGW_PREFIX}/lib \
    --enable-bootstrap \
    --enable-checking=release \
    --with-arch=${_arch} \
    --with-tune=generic \
    --enable-mingw-wildcard \
    --enable-languages=${_languages} \
    --enable-shared \
    --enable-static \
    --enable-libatomic \
    --enable-threads=${_threads} \
    --enable-tls \
    --enable-graphite \
    --enable-fully-dynamic-string \
    --enable-libstdcxx-backtrace=yes \
    --enable-libstdcxx-filesystem-ts \
    --enable-libstdcxx-time \
    --disable-libstdcxx-pch \
    --enable-libgomp \
    --disable-libssp \
    --disable-multilib \
    --disable-rpath \
    --disable-win32-registry \
    --disable-nls \
    --disable-werror \
    --disable-symvers \
    --with-libiconv \
    --with-system-zlib \
    --with-{gmp,mpfr,mpc,isl}=${MINGW_PREFIX} \
    --with-pkgversion="Rev${pkgrel}, Built by MSYS2 project" \
    --with-bugurl="https://github.com/msys2/MINGW-packages/issues" \
    --with-gnu-as \
    --with-gnu-ld \
    --with-libstdcxx-zoneinfo="yes" \
    "${_extra_config[@]}"

  # While we're debugging -fopenmp problems at least.
  # .. we may as well not strip anything.
  if check_option "strip" "n"; then
    sed -i 's,^STRIP = .*$,STRIP = true,g'                   Makefile
    sed -i 's,^STRIP_FOR_TARGET=.*$,STRIP_FOR_TARGET=true,g' Makefile
  fi

  # https://gcc.gnu.org/onlinedocs/gccint/Makefile.html
  # Avoid all paths passed with -DXXX_DIR to be converted and hardcoded in binaries.
  # See https://github.com/msys2/MINGW-packages/pull/29280 for details.
  MSYS2_ARG_CONV_EXCL='-D' \
    make -O STAGE1_CFLAGS="-O2" \
            profiledbootstrap
}

_pick() {
  local p="$1" f d; shift
  for f; do
    d="$srcdir/$p/${f#${pkgdir}/}"
    mkdir -vp "$(dirname "$d")"
    mv -v "$f" "$d"
    rmdir -vp --ignore-fail-on-non-empty "$(dirname "$f")"
  done
}

_install() {
  mkdir -p "${pkgdir}${MINGW_PREFIX}"
  mv -v "${pkgname#${MINGW_PACKAGE_PREFIX}-}"/* "${pkgdir}${MINGW_PREFIX}"
}

_install_GPL3() {
  install -Dm644 "$srcdir/${_sourcedir}/COPYING3" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${pkgname#${MINGW_PACKAGE_PREFIX}-}/COPYING3"
}

_install_RLE() {
  _install_GPL3 # RLE must come with GPL3
  install -Dm644 "$srcdir/${_sourcedir}/COPYING.RUNTIME" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${pkgname#${MINGW_PACKAGE_PREFIX}-}/COPYING.RUNTIME"
}

package_cc-libs() {
  pkgdesc="C++ Standard Library (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libstdc++=${pkgver}-${pkgrel}"
  )
}

package_gcc() {
  pkgdesc="The GNU Compiler Collection - C and C++ frontends (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-binutils"
    "${MINGW_PACKAGE_PREFIX}-crt"
    "${MINGW_PACKAGE_PREFIX}-headers"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libstdc++=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-windows-default-manifest"
    "${MINGW_PACKAGE_PREFIX}-winpthreads"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  optdepends=(
    "${MINGW_PACKAGE_PREFIX}-libatomic"
    "${MINGW_PACKAGE_PREFIX}-libgomp: OpenMP"
    "${MINGW_PACKAGE_PREFIX}-libquadmath: Quad Math"
  )
  provides=("${MINGW_PACKAGE_PREFIX}-cc")
  conflicts=(
    $([[ "$_enable_ada" == "yes" ]] || echo "${MINGW_PACKAGE_PREFIX}-gcc-ada")
    $([[ "$_enable_fortran" == "yes" ]] || echo \
      "${MINGW_PACKAGE_PREFIX}-gcc-fortran" \
      "${MINGW_PACKAGE_PREFIX}-gcc-libgfortran" \
      "${MINGW_PACKAGE_PREFIX}-libgfortran")
    $([[ "$_enable_jit" == "yes" ]] || echo "${MINGW_PACKAGE_PREFIX}-libgccjit")
    $([[ "$_enable_lto" == "yes" ]] || echo \
      "${MINGW_PACKAGE_PREFIX}-gcc-lto-dump" \
      "${MINGW_PACKAGE_PREFIX}-lto-dump")
    $([[ "$_enable_objc" == "yes" ]] || echo "${MINGW_PACKAGE_PREFIX}-gcc-objc")
    $([[ "$_enable_plugin" == "yes" ]] || echo "${MINGW_PACKAGE_PREFIX}-gcc-plugin")
    $([[ "$_enable_rust" == "yes" ]] || echo "${MINGW_PACKAGE_PREFIX}-gcc-rust")
  )
  groups=("${MINGW_PACKAGE_PREFIX}-toolchain")

  cd build-${MSYSTEM}

  make DESTDIR="${pkgdir}" install

  (
    cd "${pkgdir}${MINGW_PREFIX}"

    if [[ "$_enable_ada" == "yes" ]]; then
      _pick gcc-ada bin/gnat{,bind,chop,clean,dll,kr,link,ls,make,name,prep}.exe
      _pick gcc-ada ${_libdir}/ada_target_properties
      _pick gcc-ada ${_libdir}/ada{include,lib}/
      _pick gcc-ada ${_libdir}/gnat1.exe
      _pick gcc-ada share/info/gnat{-style,_rm,_ugn}.info
    fi

    if [[ "$_enable_fortran" == "yes" ]]; then
      _pick gcc-fortran bin/{$CHOST-,}gfortran.exe
      _pick gcc-fortran ${_libdir}/finclude/
      _pick gcc-fortran ${_libdir}/libcaf_{shmem,single}.a
      _pick gcc-fortran ${_libdir}/f951.exe
      _pick gcc-fortran ${_libdir}/include/ISO_Fortran_binding.h
      _pick gcc-fortran lib/libgfortran.spec
      _pick gcc-fortran share/info/gfortran.info
      _pick gcc-fortran share/man/man1/gfortran.1
    fi

    if [[ "$_enable_objc" == "yes" ]]; then
      _pick gcc-objc ${_libdir}/include/objc/
      _pick gcc-objc ${_libdir}/cc1obj*
    fi

    if [[ "$_enable_plugin" == "yes" ]]; then
      _pick gcc-plugin ${_libdir}/plugin/
    fi

    if [[ "$_enable_rust" == "yes" ]]; then
      _pick gcc-rust bin/{$CHOST-,}gccrs.exe
      _pick gcc-rust ${_libdir}/crab1.exe
    fi

    # Note: static libraries and import libraries of core runtime libraries (lib{atomic,gcc,quadmath,stdc++})
    # are currently packed into gcc to keep them as small as possible.
    _pick libatomic bin/libatomic*

    _pick libgcc bin/libgcc_s*

    if [[ "$_enable_jit" == "yes" ]]; then
      _pick libgccjit bin/libgccjit*
      _pick libgccjit include/libgccjit*
      _pick libgccjit lib/libgccjit.dll.a
      _pick libgccjit share/info/libgccjit.info
    fi

    if [[ "$_enable_fortran" == "yes" ]]; then
      _pick libgfortran bin/libgfortran*
      _pick libgfortran lib/libgfortran{.dll,}.a
    fi

    _pick libgomp bin/libgomp*
    _pick libgomp lib/libgomp{.dll,}.a
    _pick libgomp share/info/libgomp.info

    if [[ "$_enable_objc" == "yes" ]]; then
      _pick libobjc bin/libobjc*
      _pick libobjc lib/libobjc{.dll,}.a
    fi

    _pick libquadmath bin/libquadmath*

    _pick libstdc++ bin/libstdc++*

    if [[ "$_enable_lto" == "yes" ]]; then
      _pick lto-dump bin/lto-dump.exe
      _pick lto-dump share/man/man1/lto-dump.1
    fi
  )

  if [[ "$_enable_lto" == "yes" ]]; then
    install -dm755 "${pkgdir}"${MINGW_PREFIX}/lib/bfd-plugins/
    ln -v "${pkgdir}"${MINGW_PREFIX}/${_libdir}/liblto_plugin.dll "${pkgdir}"${MINGW_PREFIX}/lib/bfd-plugins/
  fi

  # Note: GDB doesn't treat ${MINGW_PREFIX}/bin as a safe path by default, may need patching later.
  # Have to install besides the real dll instead of in share/gdb/auto-load as gdb uses the whole Windows path
  # to search for auto-load scripts.
  mv -v "${pkgdir}"${MINGW_PREFIX}/lib/libstdc++.dll.a-gdb.py \
    "${pkgdir}"${MINGW_PREFIX}/bin/libstdc++-6.dll-gdb.py

  # install the libstdc++ man pages, requires doxygen
  # make -C $CHOST/libstdc++-v3/doc DESTDIR="${pkgdir}" doc-install-man

  # Hardlink
  ln -v "${pkgdir}"${MINGW_PREFIX}/bin/gcc.exe "${pkgdir}"${MINGW_PREFIX}/bin/cc.exe
  ln -v "${pkgdir}"${MINGW_PREFIX}/bin/gcc.exe "${pkgdir}"${MINGW_PREFIX}/bin/${CHOST}-cc.exe

  # install "custom" system gdbinit
  install -Dm644 "${srcdir}"/gdbinit "${pkgdir}"${MINGW_PREFIX}/etc/gdbinit
  sed -i 's|%GCC_NAME%|gcc-'${pkgver}'|g' "${pkgdir}"${MINGW_PREFIX}/etc/gdbinit

  # byte-compile python libraries
  python -m compileall -o 0 -o 1 "${pkgdir}"${MINGW_PREFIX}/share/gcc-${pkgver}/

  _install_RLE
}

package_gcc-ada() {
  pkgdesc="Ada frontend for GCC (GNAT) (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )

  _install
  mv -v "${pkgdir}"${MINGW_PREFIX}/${_libdir}/adalib/*.dll "${pkgdir}"${MINGW_PREFIX}/bin/
  _install_RLE
}

package_gcc-fortran() {
  pkgdesc="Fortran frontend for GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libgfortran=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  optdepends=("${MINGW_PACKAGE_PREFIX}-libgomp: OpenMP")
  provides=("${MINGW_PACKAGE_PREFIX}-fc")
  license=('spdx:GPL-3.0-or-later')

  _install
  mv -v "${pkgdir}"${MINGW_PREFIX}/lib/libgfortran.spec "${pkgdir}"${MINGW_PREFIX}/${_libdir}/
  _install_RLE
}

# TODO: depends on all gcc libraries like Arch
# Have to wait all old packages depending on gcc-libs are rebuilt to depend on cc-libs, can be check with:
# `LANG=C pacman -Si | grep -E '^(Name|Depends On)' | awk '/^Name/ {name=$3} /^Depends On/ && /gcc-libs/ {print name}'`
package_gcc-libs() {
  pkgdesc="Runtime libraries shipped by GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-cc-libs=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libatomic=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libgomp=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libquadmath=${pkgver}-${pkgrel}"
    # "${MINGW_PACKAGE_PREFIX}-libgfortran=${pkgver}-${pkgrel}"
    # "${MINGW_PACKAGE_PREFIX}-libobjc=${pkgver}-${pkgrel}"
  )
}

package_gcc-objc() {
  pkgdesc="Objective-C frontend for GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libobjc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  license=('spdx:GPL-3.0-or-later')

  _install
  _install_RLE
}

package_gcc-plugin() {
  pkgdesc="Plugin support for GCC (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc<16.1.0-7")

  _install
  _install_RLE
}

package_gcc-rust() {
  pkgdesc="Rust frontend for GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  license=('spdx:GPL-3.0-or-later')

  _install
  _install_GPL3
}

package_libatomic() {
  pkgdesc="GNU Atomic library shipped by GCC (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-libwinpthread")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libs<16.2.0-4")

  _install
  _install_RLE
}

package_libgcc() {
  pkgdesc="Low-level runtime library shipped by GCC (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-libwinpthread")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libs<16.2.0-4")

  _install
  _install_RLE
}

package_libgccjit() {
  pkgdesc="Just-In-Time Compilation with GCC backend (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  license=('spdx:GPL-3.0-or-later')

  _install
  _install_GPL3
}

package_libgfortran() {
  pkgdesc="GNU Fortran runtime library shipped by GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libquadmath=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
  )
  provides=(
    "${MINGW_PACKAGE_PREFIX}-fc-libs"
    "${MINGW_PACKAGE_PREFIX}-gcc-libgfortran"
  )
  replaces=("${MINGW_PACKAGE_PREFIX}-gcc-libgfortran")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libgfortran")

  _install
  _install_RLE
}

package_libgomp() {
  pkgdesc="OpenMP library shipped by GCC (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-libwinpthread")
  provides=("${MINGW_PACKAGE_PREFIX}-omp")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libs<16.2.0-4")
  groups=("${MINGW_PACKAGE_PREFIX}-toolchain")

  _install
  _install_RLE
}

package_libobjc() {
  pkgdesc="Objective-C runtime libraries shipped by GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
  )
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-objc<16.2.0-4")

  _install
  _install_RLE
}

package_libquadmath() {
  pkgdesc="GCC Quad-Precision Math Runtime Library (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libs<16.2.0-4")
  license=('spdx:LGPL-2.1-or-later AND GFDL-1.2-or-later')

  _install

  install -Dm644 "$srcdir/${_sourcedir}/libquadmath/COPYING.LIB" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${pkgname#${MINGW_PACKAGE_PREFIX}-}/COPYING.LIB"
}

package_libstdc++() {
  pkgdesc="C++ runtime libraries shipped by GCC (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-tzdata"
  )
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-libs<16.2.0-4")
  groups=("${MINGW_PACKAGE_PREFIX}-toolchain")

  _install
  _install_RLE
}

package_lto-dump() {
  pkgdesc="Dump link time optimization object files (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gcc=$pkgver-$pkgrel"
    "${MINGW_PACKAGE_PREFIX}-gmp"
    "${MINGW_PACKAGE_PREFIX}-isl"
    "${MINGW_PACKAGE_PREFIX}-libgcc=${pkgver}-${pkgrel}"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread"
    "${MINGW_PACKAGE_PREFIX}-mpc"
    "${MINGW_PACKAGE_PREFIX}-mpfr"
    "${MINGW_PACKAGE_PREFIX}-zlib"
    "${MINGW_PACKAGE_PREFIX}-zstd"
  )
  provides=("${MINGW_PACKAGE_PREFIX}-gcc-lto-dump")
  replaces=("${MINGW_PACKAGE_PREFIX}-gcc-lto-dump")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gcc-lto-dump")
  license=('spdx:GPL-3.0-or-later')

  _install
  _install_GPL3
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
