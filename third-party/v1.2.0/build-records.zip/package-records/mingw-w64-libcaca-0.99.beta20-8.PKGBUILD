# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libcaca
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.99.beta20
pkgrel=8
pkgdesc="Color AsCii Art library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/cacalabs/libcaca"
msys2_references=(
  "cpe: cpe:/a:libcaca_project:libcaca"
)
license=("LGPL")
makedepends=("${MINGW_PACKAGE_PREFIX}-cppunit"
             "${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             #"${MINGW_PACKAGE_PREFIX}-ncurses"
             "${MINGW_PACKAGE_PREFIX}-python")
depends=("${MINGW_PACKAGE_PREFIX}-fontconfig"
         "${MINGW_PACKAGE_PREFIX}-freetype"
         "${MINGW_PACKAGE_PREFIX}-zlib")
checkdepends=("${MINGW_PACKAGE_PREFIX}-cppunit")
source=(https://github.com/cacalabs/libcaca/releases/download/v${pkgver}/${_realname}-${pkgver}.tar.gz
        0001-win32-is-not-msvc-it-could-be.mingw.patch
        0002-correct-installation-order.mingw.patch
        0006-no-undefined.all.patch
        0010-missing-include.patch)
sha256sums=('8ad74babc63bf665b0b2378d95b4da65b7493c11bd9f3ac600517085b0c4acf2'
            'd7a30c2717d2cc22eee98a635bf885ea057888381c8a452f942931afb5990ded'
            'bd7b8659347406d76579a6d29148016a452b18dfcc1760db1be8b1f4c0786a63'
            '41868030a0e8ec2828476c17918af6d368e84e6aa1e165338000c36cc9898f82'
            '77ba3e75979ee455464fc4cdf2ca6a22dd50b78133c3a299647199011fdd0c1f')

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  patch -p1 -i "${srcdir}"/0001-win32-is-not-msvc-it-could-be.mingw.patch
  patch -p1 -i "${srcdir}"/0002-correct-installation-order.mingw.patch
  patch -p1 -i "${srcdir}"/0006-no-undefined.all.patch
  patch -p1 -i "${srcdir}"/0010-missing-include.patch

  autoreconf -fi
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  # wrong result with ucrt
  export ac_cv_func_sprintf_s=yes
  export ac_cv_func_vsnprintf_s=yes

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --enable-static \
    --enable-shared \
    --disable-ncurses \
    --disable-csharp \
    --disable-ruby \
    --disable-doc

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make -j1 DESTDIR="${pkgdir}" install
  find "${pkgdir}${MINGW_PREFIX}" -name '*.def' -o -name '*.exp' | xargs -rtl1 rm

  MSYS2_ARG_CONV_EXCL="-p" python -m compileall \
    -o 0 -o 1 -q -s"${pkgdir}" -p"/" "${pkgdir}${MINGW_PREFIX}/lib/python"*
}
