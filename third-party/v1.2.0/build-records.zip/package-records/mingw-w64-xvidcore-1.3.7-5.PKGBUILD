# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=xvidcore
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.3.7
pkgrel=5
pkgdesc="XviD is an open source MPEG-4 video codec (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('GPL')
url="https://www.xvid.com/"
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
              $( [[ "${CARCH}" != "i686" \
                && "${CARCH}" != "x86_64" ]] \
                || echo "${MINGW_PACKAGE_PREFIX}-nasm" ))
source=(https://downloads.xvid.com/downloads/${_realname}-${pkgver}.tar.bz2
        0001-remove-dll-option-clang.patch)
sha256sums=('aeeaae952d4db395249839a3bd03841d6844843f5a4f84c271ff88f7aa1acff7'
            'e100d96f183bf0e7334ab6ae12ded47a72157fc3976c10db32377ab8cda22715')

prepare() {
  cd "${srcdir}/${_realname}"
  patch -Np1 -i "${srcdir}/0001-remove-dll-option-clang.patch"
}

build() {
  [[ -d "${srcdir}"/build-${MSYSTEM} ]] && rm -rf "${srcdir}"/build-${MSYSTEM}
  cp -rf "${srcdir}"/${_realname} "${srcdir}"/build-${MSYSTEM}

  cd "${srcdir}"/build-${MSYSTEM}/build/generic
  CFLAGS+=" -std=gnu17"
  ./configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST}

  make
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}/build/generic
  make DESTDIR="${pkgdir}" install

  # add lib prefix with static and import library name (#18553)
  mv "${pkgdir}${MINGW_PREFIX}"/lib/{,lib}xvidcore.dll.a
  mv "${pkgdir}${MINGW_PREFIX}"/lib/{,lib}xvidcore.a
}
