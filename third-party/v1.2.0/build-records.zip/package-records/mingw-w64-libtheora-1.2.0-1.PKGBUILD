# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libtheora
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.2.0
pkgrel=1
pkgdesc="An open video codec developed by the Xiph.org (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.theora.org"
msys2_repository_url="https://gitlab.xiph.org/xiph/theora"
license=('spdx:BSD-3-Clause')
depends=("${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-libogg"
         "${MINGW_PACKAGE_PREFIX}-libvorbis")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-doxygen"
             "${MINGW_PACKAGE_PREFIX}-SDL"
             "${MINGW_PACKAGE_PREFIX}-autotools")
source=("https://downloads.xiph.org/releases/theora/${_realname}-${pkgver}.tar.gz"
        001-example.patch)
sha256sums=('279327339903b544c28a92aeada7d0dcfd0397b59c2f368cc698ac56f515906e'
            '5627d26c3316fef71bca037e1834bcba063dbf949ea9293820f0e68b13641105')

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  sed -i "s,EXPORTS,," "win32/xmingw32/libtheoradec-all.def"
  sed -i "s,EXPORTS,," "win32/xmingw32/libtheoraenc-all.def"
  patch -p1 -i "${srcdir}"/001-example.patch

  autoreconf -fiv -I m4
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-${pkgver}/configure \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --prefix=${MINGW_PREFIX} \
    --disable-examples

  # parallel is broken (libtheoraenc is missing sometimes)
  make -j1
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make install DESTDIR="${pkgdir}"
}
