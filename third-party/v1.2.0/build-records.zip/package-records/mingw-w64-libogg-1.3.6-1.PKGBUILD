# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libogg
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.3.6
pkgrel=1
pkgdesc="Ogg bitstream and framing library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://xiph.org/"
msys2_repository_url="https://github.com/xiph/ogg"
license=('spdx:BSD-3-Clause')
makedepends=("${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://downloads.xiph.org/releases/ogg/${_realname}-${pkgver}.tar.gz"
        "libogg-1.3.4-versioned-dll-cmake.patch")
sha256sums=('83e6704730683d004d20e21b8f7f55dcb3383cdf84c0daedf30bde175f774638'
            '18772896694597eb60ab3f9fb6bc7629759d51a7fa0c1645da1f8d7ba11c1bf8')

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  patch -Np1 -i "${srcdir}/libogg-1.3.4-versioned-dll-cmake.patch"
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  # Static
  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -DBUILD_TESTING=OFF \
      "../${_realname}-${pkgver}"

  cmake --build .

  # Shared
  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DBUILD_TESTING=OFF \
      "../${_realname}-${pkgver}"

  cmake --build .
}

package() {
  # Static
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-static"

  # Shared
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-shared"

  # m4
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/ogg.m4 "${pkgdir}"${MINGW_PREFIX}/share/aclocal/ogg.m4

  # License
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING
}
