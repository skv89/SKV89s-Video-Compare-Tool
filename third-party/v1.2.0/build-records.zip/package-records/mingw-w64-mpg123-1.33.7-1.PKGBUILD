# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=mpg123
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.33.7
pkgrel=1
pkgdesc="A console based real time MPEG Audio Player for Layer 1, 2 and 3 (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.mpg123.com/"
msys2_references=(
  "cpe: cpe:/a:mpg123:mpg123"
)
license=('spdx:LGPL-2.1-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             $([[ ${CARCH} == i686 ]] || echo \
               "${MINGW_PACKAGE_PREFIX}-openal" \
               "${MINGW_PACKAGE_PREFIX}-portaudio")
             "${MINGW_PACKAGE_PREFIX}-SDL2")
optdepends=("${MINGW_PACKAGE_PREFIX}-SDL2")
if [[ ${CARCH} != i686 ]]; then
  optdepends+=("${MINGW_PACKAGE_PREFIX}-openal"
               "${MINGW_PACKAGE_PREFIX}-portaudio")
fi
source=("https://sourceforge.net/projects/mpg123/files/mpg123/${pkgver}/mpg123-${pkgver}.tar.bz2"{,.sig})
sha256sums=('31d0e35a4ca567ec9b5ebda6c3062bb4435d6d3eacd6ef0d95cadd7854dc03ee'
            'SKIP')
validpgpkeys=('D021FF8ECF4BE09719D61A27231C4CBC60D5CAFE') # Thomas Orgis <thomas@orgis.org>

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  autoreconf -fi
}

build() {
  export lt_cv_deplibs_check_method='pass_all'
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --enable-shared \
    --enable-static

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING
}
