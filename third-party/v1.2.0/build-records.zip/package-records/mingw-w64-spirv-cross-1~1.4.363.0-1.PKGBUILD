# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>

_realname=spirv-cross
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
epoch=1
pkgver=1.4.363.0
pkgrel=1
pkgdesc="A tool and library for parsing and converting SPIR-V to other shader languages (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/KhronosGroup/SPIRV-Cross/'
msys2_repository_url='https://github.com/KhronosGroup/SPIRV-Cross'
msys2_references=(
  'anitya: 379798'
  'aur: spirv-cross'
  'cpe: cpe:2.3:a:khronos:vulkan'
)
license=('spdx:Apache-2.0')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-glslang"
             "${MINGW_PACKAGE_PREFIX}-python"
             "${MINGW_PACKAGE_PREFIX}-spirv-headers"
             "${MINGW_PACKAGE_PREFIX}-spirv-tools")
source=(https://github.com/KhronosGroup/SPIRV-Cross/archive/vulkan-sdk-${pkgver}/${_realname}-${pkgver}.tar.gz)
sha256sums=('f708982e88b763ef5b0394ed468fc2c3628f68cdab89f2e7a946cd628c04e721')

prepare() {
  cd "${srcdir}/SPIRV-Cross-vulkan-sdk-${pkgver}"

  # Use system provided glslang and spirv-tools binaries.
  sed -e "s|NO_DEFAULT_PATH||g" -i CMakeLists.txt
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -G "Ninja" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    "${_extra_config[@]}" \
    -DSPIRV_CROSS_SHARED=ON \
    -DSPIRV_CROSS_ENABLE_TESTS=OFF \
    "../SPIRV-Cross-vulkan-sdk-${pkgver}"

  ${MINGW_PREFIX}/bin/cmake.exe --build ./
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"
  ${MINGW_PREFIX}/bin/cmake -DSPIRV_CROSS_ENABLE_TESTS=ON ../SPIRV-Cross-vulkan-sdk-${pkgver}
  ${MINGW_PREFIX}/bin/cmake --build .
  ${MINGW_PREFIX}/bin/ctest.exe ./ || warning "Tests failed"
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .

  install -Dm644 "${srcdir}/SPIRV-Cross-vulkan-sdk-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
