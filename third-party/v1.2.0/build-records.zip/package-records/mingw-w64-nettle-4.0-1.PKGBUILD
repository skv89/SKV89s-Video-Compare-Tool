# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: dragon-archer <dragon-archer@outlook.com>

_realname=nettle
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=4.0
pkgrel=1
pkgdesc="A low-level cryptographic library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
msys2_repository_url='https://git.lysator.liu.se/nettle/nettle'
url="https://www.lysator.liu.se/~nisse/nettle"
msys2_references=(
  "cpe: cpe:/a:nettle_project:nettle"
)
license=('spdx:GPL-2.0-or-later' 'spdx:LGPL-3.0-or-later')
depends=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  "${MINGW_PACKAGE_PREFIX}-gmp"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
)
source=("https://ftp.gnu.org/gnu/nettle/nettle-${pkgver}.tar.gz"{,.sig})
sha256sums=('3addbc00da01846b232fb3bc453538ea5468da43033f21bb345cb1e9073f5094'
            'SKIP')
validpgpkeys=('343C2FF0FBEE5EC2EDBEF399F3599FF828C67298') #Niels Möller <nisse@lysator.liu.se>

build() {
  declare -a _extra_config
  case "${CARCH}" in
    i?86|x86_64)
      ;;
    *)
      _extra_config+=(--disable-assembler)
  esac

  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    "${_extra_config[@]}" \
    --enable-shared \
    --enable-public-key

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  # symbols-test fails with `.refptr.__stack_chk_guard` lacking the nettle prefix
  make check || true
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install
}
