# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Andrew Sun <adsun701@gmail.com>

_realname=libtasn1
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=4.21.0
pkgrel=1
pkgdesc="A library for Abstract Syntax Notation One (ASN.1) and Distinguish Encoding Rules (DER) manipulation (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.gnu.org/software/libtasn1/"
msys2_repository_url="https://gitlab.com/gnutls/libtasn1"
msys2_references=(
  "cpe: cpe:/a:free_software_foundation_inc.:libtasn1"
  "cpe: cpe:/a:gnu:libtasn1"
)
license=("GPL3, LGPL")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-gtk-doc")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
source=("https://ftp.gnu.org/gnu/libtasn1/${_realname}-${pkgver}.tar.gz"{,.sig})
        #https://www.gnupg.org/ftp/gcrypt/gnutls/libtasn1/${_realname}-${pkgver}.tar.gz{,.sig})
sha256sums=('1d8a444a223cc5464240777346e125de51d8e6abf0b8bac742ac84609167dc87'
            'SKIP')
validpgpkeys=('B1D2BD1375BECB784CF4F8C4D73CF638C53C06BE') # "Simon Josefsson <simon@josefsson.org>"

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX}\
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-shared \
    --enable-static

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  find "${pkgdir}${MINGW_PREFIX}" -name '*.def' -o -name '*.exp' | xargs -rtl1 rm

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING.LESSERv2 "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING.LESSERv2"
}
