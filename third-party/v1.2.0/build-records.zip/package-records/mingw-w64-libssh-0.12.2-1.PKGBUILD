# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libssh
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.12.2
pkgrel=1
pkgdesc="Library for accessing ssh client services through C libraries (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.libssh.org/"
msys2_repository_url='https://git.libssh.org/projects/libssh.git/'
msys2_issue_tracker_url='https://gitlab.com/libssh/libssh-mirror/-/issues'
msys2_references=(
  'cpe: cpe:/a:libssh:libssh'
)
license=('spdx:LGPL-2.1-or-later')
depends=(
  "${MINGW_PACKAGE_PREFIX}-openssl"
  "${MINGW_PACKAGE_PREFIX}-zlib"
  "${MINGW_PACKAGE_PREFIX}-libwinpthread"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
)
checkdepends=("${MINGW_PACKAGE_PREFIX}-cmocka")
source=("https://www.libssh.org/files/${pkgver%.*}/${_realname}-${pkgver}.tar.xz"{,.asc}
         002-libssh-fix-pkgconfig.patch)
sha256sums=('49560f677d96e3706a904ac2de1116e25f3680937d51e5c92198fcba4a1c1e9f'
            'SKIP'
            '45eb3be0e97f9d50144ac14404545a1a337609b3d650aa3b2c353affefb220cd')
validpgpkeys=('8DFF53E18F2ABC8D8F3C92237EE0FC4DCC014E3D'  # Andreas Schneider <asn@cryptomilk.org>
              '88A228D89B07C2C77D0C780903D5DF8CFDD3E8E7') # libssh release key (release key) <libssh@libssh.org>

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  patch -p1 -i "${srcdir}"/002-libssh-fix-pkgconfig.patch
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    _extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${_extra_config[@]}" \
      -DWITH_GSSAPI=OFF \
      -DUNIT_TESTING=OFF \
      -DBUILD_SHARED_LIBS=OFF \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-static"

  cmake --build "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${_extra_config[@]}" \
      -DWITH_GSSAPI=OFF \
      -DUNIT_TESTING=OFF \
      -DBUILD_STATIC_LIB=OFF \
      -DBUILD_SHARED_LIBS=ON \
      -S "${_realname}-${pkgver}" \
      -B "build-${MSYSTEM}-shared"

  cmake --build "build-${MSYSTEM}-shared"
}

check() {
  cmake -DUNIT_TESTING=ON -S "${_realname}-${pkgver}" -B "build-${MSYSTEM}-shared"
  cmake --build "build-${MSYSTEM}-shared"
  ctest --test-dir "build-${MSYSTEM}-shared" --output-on-failure
}

package() {
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-static"
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-shared"
}
