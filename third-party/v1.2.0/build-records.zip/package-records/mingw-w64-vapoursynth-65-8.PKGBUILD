# Maintainer: Zach Bacon <zachbacon@budgiemedia.rocks>

_realname=vapoursynth
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=65
pkgrel=8
pkgdesc="A video processing framework with simplicity in mind (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.vapoursynth.com/"
msys2_repository_url="https://github.com/vapoursynth/vapoursynth/"
msys2_references=(
  'archlinux: vapoursynth'
)
license=('spdx:LGPL-2.1-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-python"
         "${MINGW_PACKAGE_PREFIX}-zimg")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cython"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-python-setuptools")
source=("https://github.com/vapoursynth/vapoursynth/archive/R${pkgver}/vapoursynth-${pkgver}.tar.gz"
        "0001-wrong-arguments-to-Mem32-constructor.patch"
        "0002-prevent-portable-python.patch"
        "0003-no-registry-setup-py.patch"
        "0004-vapoursynth-check-empty-registry.patch")
sha256sums=('2bde5233b82d914b5e985119ed9cc344e3c27c3c068b5c4ab909176cd1751dce'
            '085331d7c81da760b66864ec34647094384514689e7ea9895e7bd34ed9ce9831'
            'bc75208eb672446a23535455040d0f5a7e49e19e8276773dd9bc30ee87da2e27'
            'a406e46147de0bccbd7353c26a9620a21524376e408131a346ce47df9985b946'
            'b2fac3089dfb73dfb8baf5bf398831e54da498314dae1f399129c41a6b41bda1')

_apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -p1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}/${_realname}-R${pkgver}"

  # Upstream does not support mingw, see
  # https://github.com/vapoursynth/vapoursynth/pull/841

  _apply_patch_with_msg \
    0001-wrong-arguments-to-Mem32-constructor.patch \
    0002-prevent-portable-python.patch \
    0003-no-registry-setup-py.patch \
    0004-vapoursynth-check-empty-registry.patch

  autoreconf -vfi
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  ../${_realname}-R${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --host=${MINGW_CHOST} \
    --build=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-python-module=no

  make
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}/${_realname}-R${pkgver}"/COPYING.LESSER \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING.LESSER

  local PREFIX_WIN=$(cygpath -wm ${MINGW_PREFIX})
  for _f in "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/*.pc; do
    sed -e "s|${PREFIX_WIN}|${MINGW_PREFIX}|g" -i ${_f}
  done

  local _py3ver=$(${MINGW_PREFIX}/bin/python3 -c "import sys;sys.stdout.write('.'.join(map(str, sys.version_info[:2])))")

  rm -f "${pkgdir}"${MINGW_PREFIX}/lib/vapoursynth/*.dll.a
  rm -f "${pkgdir}"${MINGW_PREFIX}/lib/python${_py3ver}/site-packages/*.dll.a

  export LDFLAGS="-L$(cygpath -wm $pkgdir)/${MINGW_PREFIX}/lib $LDFLAGS"
  cd "${srcdir}/${_realname}-R${pkgver}"

  MSYS2_ARG_CONV_EXCL="--prefix=;--install-scripts=;--install-platlib=" \
  ${MINGW_PREFIX}/bin/python setup.py install --prefix=${MINGW_PREFIX} \
    --root="${pkgdir}" --optimize=1
}
