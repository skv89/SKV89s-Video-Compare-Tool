# Maintainer: Andrew Sun <adsun701@gmail.com>

_realname=libdatrie
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-docs")
pkgver=0.2.14
pkgrel=1
pkgdesc="Implementation of double-array structure for representing trie, as proposed by Junichi Aoe. (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://linux.thai.net/projects/datrie'
license=('LGPL')
depends=("${MINGW_PACKAGE_PREFIX}-libiconv")
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-doxygen")
source=("https://linux.thai.net/pub/thailinux/software/libthai/${_realname}-${pkgver}.tar.xz")
sha256sums=('f04095010518635b51c2313efa4f290b7db828d6273e39b2b8858f859dfe81d5')

build() {
  [[ -d "${srcdir}"/build-${MSYSTEM} ]] && rm -rf "${srcdir}"/build-${MSYSTEM}
  cp -rf "${srcdir}"/${_realname}-${pkgver}/. "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}
  export ac_cv_func_malloc_0_nonnull=yes
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-static \
    --enable-shared

  make
}

package_libdatrie() {
  optdepends=("${MINGW_PACKAGE_PREFIX}-libdatrie-docs: Documentation")

  make -C "${srcdir}"/build-${MSYSTEM} install DESTDIR="${pkgdir}"

  # copy trietool executable correctly
  rm -rf "${pkgdir}${MINGW_PREFIX}"/bin/trietool-0.2.exe
  cp -rf "${pkgdir}${MINGW_PREFIX}"/bin/trietool.exe "${pkgdir}${MINGW_PREFIX}"/bin/trietool-0.2.exe

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/COPYING

  # split docs
  mkdir -p dest${MINGW_PREFIX}/share
  mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share/doc
}

package_libdatrie-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
