# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>

_realname=libvpl
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=2.17.0
pkgrel=1
pkgdesc="Intel Video Processing Library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://intel.github.io/libvpl'
msys2_repository_url="https://github.com/intel/libvpl"
msys2_references=(
  'purl: pkg:github/intel/libvpl'
)
license=('spdx:MIT')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
provides=("${MINGW_PACKAGE_PREFIX}-onevpl")
conflicts=("${MINGW_PACKAGE_PREFIX}-onevpl")
replaces=("${MINGW_PACKAGE_PREFIX}-onevpl")
makedepends=("${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://github.com/intel/libvpl/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz"
        0001-fix-pkgconfig-file.patch
        0002-cmake-install-vars-sh.patch
        0003-cmake-fix-32bit-install.patch)
sha256sums=('4de3e2faf1e8307fb282e4a43f443191810f6a6b0a484fffa7995ba1c814c6ec'
            'f23ca1ccbaa9c8e3fd4fd7320996e5be2753cfcdc6e2a25f6def08222a5691cd'
            'b9b1cdcb531ee0b6b1d7eef8bbfb1df8ca1ffe72d76961050dd912203edecc67'
            '21b2cc2f466f636940c8ef81f50dff177aff96d60dc4bc57f58c5c9f016502fe')

apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}"/libvpl-${pkgver}

  apply_patch_with_msg \
    0001-fix-pkgconfig-file.patch \
    0002-cmake-install-vars-sh.patch \
    0003-cmake-fix-32bit-install.patch
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    "${MINGW_PREFIX}"/bin/cmake.exe \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      ../libvpl-${pkgver}

  "${MINGW_PREFIX}"/bin/cmake.exe --build .

  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    "${MINGW_PREFIX}"/bin/cmake.exe \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${extra_config[@]}" \
      -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
      -DBUILD_SHARED_LIBS=ON \
      ../libvpl-${pkgver}

  "${MINGW_PREFIX}"/bin/cmake.exe --build .
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  DESTDIR="${pkgdir}" "${MINGW_PREFIX}"/bin/cmake.exe --install .

  cd "${srcdir}/build-${MSYSTEM}-shared"
  DESTDIR="${pkgdir}" "${MINGW_PREFIX}"/bin/cmake.exe --install .

  rm -r "${pkgdir}${MINGW_PREFIX}/share/vpl/examples"

  install -Dm644 "${srcdir}/libvpl-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
