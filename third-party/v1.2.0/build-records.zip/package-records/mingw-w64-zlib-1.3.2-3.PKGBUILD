# Maintainer: Alexey Pavlov <Alexpux@gmail.com>
# Contributor: Martell Malone <martellmalone@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>
# Contributor: Ray Donnelly <mingw.android@gmail.com>

_realname=zlib
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         "${MINGW_PACKAGE_PREFIX}-minizip")
pkgver=1.3.2
pkgrel=3
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:Zlib')
url="https://www.zlib.net/"
msys2_repository_url="https://github.com/madler/zlib"
msys2_references=(
  "cpe: cpe:/a:gnu:zlib"
  "cpe: cpe:/a:zlib:zlib"
)
msys2_ignore_vulnerabilities=(
  "CVE-2026-22184" # only affects demo program untgz which we don't ship
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-bzip2"
)
source=("https://github.com/madler/zlib/releases/download/v${pkgver}/zlib-${pkgver}.tar.xz"{,.asc}
        01-zlib-1.2.11-1-buildsys.mingw.patch
        03-dont-put-sodir-into-L.mingw.patch
        04-fix-largefile-support.patch
        07-Add-no-undefined-to-link-to-enable-build-shared-vers.patch
        08-Add-bzip2-library-to-pkg-config-file.patch
        https://patch-diff.githubusercontent.com/raw/madler/zlib/pull/1165.patch)
sha256sums=('d7a0654783a4da529d1bb793b7ad9c3318020af77667bcae35f95d0e42a792f3'
            'SKIP'
            'b58b353d976d6fdd9a5094e60fa39439d4f14e9bf8be4a8bd475f2cd47f10226'
            '7287d12db57dcf0f66964c861100bf06ebe1ddcb243e7ee0773fcab1b2935596'
            '8e1cdf8edfc6ac08b0e660ca42a977942a88fab3ff59c01c87ba96500e2c3e63'
            'fb83292f494f649ea7f1835aa4abea61acc593d7f90625741d42cd99cac0e075'
            '0be98a7e660e7c068856f08b9e92d6c73a6b0d88c3e29a9716140b147f7c23c5'
            'af9ce272d3495a27c91e3d37ccfe1146d7e1847ded8b871d86ce3c1875d7cea7')
validpgpkeys=('5ED46A6721D365587791E2AA783FCD8E58BCAFBA')

apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}
  apply_patch_with_msg \
    01-zlib-1.2.11-1-buildsys.mingw.patch \
    03-dont-put-sodir-into-L.mingw.patch \
    04-fix-largefile-support.patch \
    1165.patch

  cd "${srcdir}"/${_realname}-${pkgver}/contrib/minizip
  apply_patch_with_msg \
    07-Add-no-undefined-to-link-to-enable-build-shared-vers.patch \
    08-Add-bzip2-library-to-pkg-config-file.patch
  autoreconf -fi
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  CHOST=${MINGW_CHOST} \
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --shared

  make -j1

  # build minizip
  mkdir -p "${srcdir}/build-mz-${MSYSTEM}" && cd "${srcdir}/build-mz-${MSYSTEM}"

  CFLAGS+=" -DHAVE_BZIP2"
  ../${_realname}-${pkgver}/contrib/minizip/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-demos \
    LIBS="-lbz2"

  make -j1
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"
  make test
}

package_zlib() {
  pkgdesc="Compression library implementing the deflate compression method found in gzip and PKZIP (mingw-w64)"
  if [[ ${MSYSTEM} == MINGW32 ]]; then
    depends=("${MINGW_PACKAGE_PREFIX}-libgcc")
  fi

  cd "${srcdir}/build-${MSYSTEM}"

  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}

package_minizip() {
  pkgdesc="Mini zip and unzip based on zlib (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-zlib"
           "${MINGW_PACKAGE_PREFIX}-bzip2")
  conflicts=("${MINGW_PACKAGE_PREFIX}-minizip-git")
  replaces=("${MINGW_PACKAGE_PREFIX}-minizip-git")
  provides=("${MINGW_PACKAGE_PREFIX}-minizip-git")

  cd "${srcdir}/build-mz-${MSYSTEM}"

  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/minizip/LICENSE"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
