# Maintainer: Alexey Pavlov <Alexpux@gmail.com>
# Contributor: Zach Bacon <11doctorwhocanada@gmail.com>
# Contributor: wirx6 <wirx654@gmail.com>
# Contributor: Ray Donnelly <mingw.android@gmail.com>

_realname=ffmpeg
pkgbase="mingw-w64-${_realname}"
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=9.0.2
pkgrel=2
pkgdesc="Complete solution to record, convert and stream audio and video (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://ffmpeg.org/"
msys2_repository_url='https://git.ffmpeg.org/ffmpeg.git'
msys2_references=(
  "cpe: cpe:/a:ffmpeg:ffmpeg"
)
license=('spdx:GPL-3.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-aom"
         "${MINGW_PACKAGE_PREFIX}-bzip2"
         "${MINGW_PACKAGE_PREFIX}-dav1d"
         "${MINGW_PACKAGE_PREFIX}-fontconfig"
         "${MINGW_PACKAGE_PREFIX}-freetype"
         "${MINGW_PACKAGE_PREFIX}-frei0r-plugins"
         "${MINGW_PACKAGE_PREFIX}-fribidi"
         "${MINGW_PACKAGE_PREFIX}-gmp"
         "${MINGW_PACKAGE_PREFIX}-gnutls"
         "${MINGW_PACKAGE_PREFIX}-gsm"
         "${MINGW_PACKAGE_PREFIX}-harfbuzz"
         "${MINGW_PACKAGE_PREFIX}-lame"
         "${MINGW_PACKAGE_PREFIX}-libass"
         "${MINGW_PACKAGE_PREFIX}-libbluray"
         "${MINGW_PACKAGE_PREFIX}-libcaca"
         "${MINGW_PACKAGE_PREFIX}-libexif"
         "${MINGW_PACKAGE_PREFIX}-libgme"
         "${MINGW_PACKAGE_PREFIX}-libiconv"
         "${MINGW_PACKAGE_PREFIX}-libjxl"
         "${MINGW_PACKAGE_PREFIX}-libmodplug"
         "${MINGW_PACKAGE_PREFIX}-libssh"
         $([[ "${CARCH}" == "i686" ]] || echo "${MINGW_PACKAGE_PREFIX}-libplacebo")
         $([[ "${CARCH}" == "i686" ]] || echo "${MINGW_PACKAGE_PREFIX}-librsvg")
         "${MINGW_PACKAGE_PREFIX}-libsoxr"
         "${MINGW_PACKAGE_PREFIX}-libtheora"
         "${MINGW_PACKAGE_PREFIX}-libva"
         "${MINGW_PACKAGE_PREFIX}-libvorbis"
         "${MINGW_PACKAGE_PREFIX}-libvpx"
         "${MINGW_PACKAGE_PREFIX}-libwebp"
         "${MINGW_PACKAGE_PREFIX}-libxml2"
         "${MINGW_PACKAGE_PREFIX}-libvpl"
         "${MINGW_PACKAGE_PREFIX}-openal"
         "${MINGW_PACKAGE_PREFIX}-opencore-amr"
         "${MINGW_PACKAGE_PREFIX}-openjpeg2"
         "${MINGW_PACKAGE_PREFIX}-opus"
         $([[ "${CARCH}" == "i686" ]] || echo "${MINGW_PACKAGE_PREFIX}-rav1e")
         "${MINGW_PACKAGE_PREFIX}-rtmpdump"
         "${MINGW_PACKAGE_PREFIX}-SDL2"
         "${MINGW_PACKAGE_PREFIX}-speex"
         "${MINGW_PACKAGE_PREFIX}-srt"
         $([[ "${CARCH}" == "i686" ]] || echo "${MINGW_PACKAGE_PREFIX}-svt-av1")
         $([[ "${CARCH}" == "i686" ]] || echo "${MINGW_PACKAGE_PREFIX}-liblc3")
         "${MINGW_PACKAGE_PREFIX}-vid.stab"
         "${MINGW_PACKAGE_PREFIX}-vulkan"
         $([[ "${CARCH}" == "i686" ]] || echo \
           "${MINGW_PACKAGE_PREFIX}-ggml" \
           "${MINGW_PACKAGE_PREFIX}-whisper.cpp")
         "${MINGW_PACKAGE_PREFIX}-libx264"
         "${MINGW_PACKAGE_PREFIX}-x265"
         "${MINGW_PACKAGE_PREFIX}-xvidcore"
         "${MINGW_PACKAGE_PREFIX}-zimg"
         "${MINGW_PACKAGE_PREFIX}-zlib"
         "${MINGW_PACKAGE_PREFIX}-zvbi")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-dlfcn"
             "${MINGW_PACKAGE_PREFIX}-vulkan-headers"
             $([[ ${MINGW_PACKAGE_PREFIX} == *-clang-aarch64* ]] || echo "${MINGW_PACKAGE_PREFIX}-amf-headers")
             $([[ ${MINGW_PACKAGE_PREFIX} == *-clang-aarch64* ]] || echo "${MINGW_PACKAGE_PREFIX}-ffnvcodec-headers")
             $([[ ${MINGW_PACKAGE_PREFIX} == *-clang-aarch64* ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm"))
source=(https://ffmpeg.org/releases/${_realname}-${pkgver}.tar.xz{,.asc}
        "pathtools.c"
        "pathtools.h"
        "0005-Win32-Add-path-relocation-to-frei0r-plugins-search.patch")
validpgpkeys=('FCF986EA15E6E293A5644F10B4322F04D67658D8')
sha256sums=('8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e'
            'SKIP'
            'ebf471173f5ee9c4416c10a78760cea8afaf1a4a6e653977321e8547ce7bf3c0'
            '1585ef1b61cf53a2ca27049c11d49e0834683dfda798f03547761375df482a90'
            '8c74e9b5800dbb41c33a60114712726ec768ad6de8f147c2eb30656fd4c899cc')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _fname in "$@"
  do
    msg2 "Applying ${_fname}"
    patch -Nbp1 -i "${srcdir}"/${_fname}
  done
}

prepare() {
  test ! -d "${startdir}/../mingw-w64-pathtools" || {
    cmp "${startdir}/../mingw-w64-pathtools/pathtools.c" "${srcdir}/pathtools.c" &&
    cmp "${startdir}/../mingw-w64-pathtools/pathtools.h" "${srcdir}/pathtools.h"
  } || exit 1

  cd "${srcdir}/${_realname}-${pkgver}"
  cp -fHv "${srcdir}"/pathtools.[ch] libavfilter/

  apply_patch_with_msg \
    0005-Win32-Add-path-relocation-to-frei0r-plugins-search.patch

  # rename version to avoid conflict with C++20 <version> header
  mv VERSION VERSION.txt
}

build() {
  # Do not let version.sh discover the MINGW-packages repo
  export GIT_DIR=/dev/null

  local -a common_config
  common_config+=(
    --disable-debug
    --disable-stripping
    --disable-doc
    --enable-dxva2
    --enable-d3d11va
    --enable-d3d12va
    --enable-frei0r
    --enable-gmp
    --enable-gnutls
    --enable-gpl
    --enable-iconv
    --enable-libaom
    --enable-libass
    --enable-libbluray
    --enable-libcaca
    --enable-libdav1d
    --enable-libfontconfig
    --enable-libfreetype
    --enable-libfribidi
    --enable-libgme
    --enable-libgsm
    --enable-libharfbuzz
    --enable-libjxl
    --enable-libmodplug
    --enable-libmp3lame
    --enable-libopencore_amrnb
    --enable-libopencore_amrwb
    --enable-libopenjpeg
    --enable-libopus
    --enable-librtmp
    --enable-libssh
    --enable-libsoxr
    --enable-libspeex
    --enable-libsrt
    --enable-libtheora
    --enable-libvidstab
    --enable-libvorbis
    --enable-libx264
    --enable-libx265
    --enable-libxvid
    --enable-libvpx
    --enable-libwebp
    --enable-libxml2
    --enable-libzimg
    --enable-libzvbi
    --enable-openal
    --enable-pic
    --enable-runtime-cpudetect
    --enable-swresample
    --enable-version3
    --enable-vulkan
    --enable-zlib
    --enable-libvpl
  )

  if [[ "${CARCH}" != "i686" ]]; then
    common_config+=(
       --enable-liblc3
       --enable-libplacebo
       --enable-librav1e
       --enable-librsvg
       --enable-libsvtav1
       --enable-whisper
    )
  fi

  if [[ "${MINGW_PACKAGE_PREFIX}" != *clang-aarch64* ]]; then
    common_config+=(
        --enable-amf
        --enable-nvenc
    )
  fi

  for _variant in -static -shared; do
    mkdir -p "${srcdir}/build-${MSYSTEM}${_variant}" && cd "${srcdir}/build-${MSYSTEM}${_variant}"

    if [[ ${_variant} == -static ]]; then
      ENABLE_VARIANT="--enable-static --pkg-config-flags=--static"
    else
      ENABLE_VARIANT=--enable-shared
    fi

    ../${_realname}-${pkgver}/configure \
      --prefix=${MINGW_PREFIX} \
      --target-os=mingw32 \
      --arch=${CARCH%%-*} \
      --cc=${CC} \
      --cxx=${CXX} \
      "${common_config[@]}" \
      --logfile=config.log \
      ${ENABLE_VARIANT}

    make
  done
}

check() {
  for _variant in -static -shared; do
    cd "${srcdir}/build-${MSYSTEM}${_variant}"
    # workaround for conflict with SDL main(), use it if you have SDL installed
    # make check CC_C="-c -Umain"
    make check || true
  done
}

package() {
  for _variant in -static -shared; do
    cd "${srcdir}/build-${MSYSTEM}${_variant}"
    make DESTDIR="${pkgdir}" install
  done
  
  rm -f "${pkgdir}"/${MINGW_PREFIX}/lib/*.def
  rm -f "${pkgdir}"/${MINGW_PREFIX}/bin/*.lib

  local PREFIX_DEPS=$(cygpath -am ${MINGW_PREFIX})
  find "${pkgdir}"${MINGW_PREFIX}/lib/pkgconfig -name *.pc -exec sed -i -e"s|${PREFIX_DEPS}|${MINGW_PREFIX}|g" {} \;
}
