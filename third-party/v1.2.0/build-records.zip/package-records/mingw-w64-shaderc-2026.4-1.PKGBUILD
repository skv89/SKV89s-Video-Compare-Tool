# Maintainer: Biswapriyo Nath <nathbappai@gmail.com>

_realname=shaderc
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=2026.4
pkgrel=1
pkgdesc="Collection of tools, libraries and tests for shader compilation (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/google/shaderc"
msys2_repository_url='https://github.com/google/shaderc'
msys2_references=(
  'archlinux: shaderc'
)
license=('spdx:Apache-2.0')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-glslang"
         "${MINGW_PACKAGE_PREFIX}-spirv-tools")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-python"
             "${MINGW_PACKAGE_PREFIX}-spirv-headers"
             "${MINGW_PACKAGE_PREFIX}-asciidoctor")
source=("https://github.com/google/shaderc/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz"
        "0001-fix-glslang-hlsl-linking-order.patch")
sha256sums=('f06ce5bcca94e5df7f34e115743597d0ad2e13c5fe9213c67dc8c76031241947'
            'af880b221603e2b5c34dd306feeb4fa9af5803ebc841d64ab8e4be0e7455a6ba')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  # https://www.mail-archive.com/devel@lists.fedoraproject.org/msg156020.html
  patch -Nbp1 -i "${srcdir}/0001-fix-glslang-hlsl-linking-order.patch"

  # de-vendor libs and disable git versioning
  sed '/examples/d;/third_party/d' -i CMakeLists.txt
  sed '/build-version/d' -i glslc/CMakeLists.txt
  cat <<- EOF > glslc/src/build-version.inc
"${pkgver}\\n"
"$(pacman -Q "${MINGW_PACKAGE_PREFIX}-spirv-tools"|cut -d \  -f 2|sed 's/-.*//')\\n"
"$(pacman -Q "${MINGW_PACKAGE_PREFIX}-glslang"|cut -d \  -f 2|sed 's/-.*//')\\n"
EOF
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  local -a _extra_config
  if check_option "debug" "y"; then
    _extra_config+=(-DCMAKE_BUILD_TYPE=Debug)
  else
    _extra_config+=(-DCMAKE_BUILD_TYPE=Release)
  fi

  local -a _glslang_inc
  _glslang_inc=$(cygpath -m "${MINGW_PREFIX}/include/glslang")

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -GNinja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    "${_extra_config[@]}" \
    -Dglslang_SOURCE_DIR=${_glslang_inc} \
    -DSHADERC_SKIP_TESTS=ON \
    -DSHADERC_SKIP_EXAMPLES=ON \
    -DSHADERC_ENABLE_WERROR_COMPILE=OFF \
    -DPython_EXECUTABLE="${MINGW_PREFIX}/bin/python.exe" \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./

  # Generate manpage
  # Suppress asciidoctor: ERROR: line 1: non-conforming manpage title
  cd "${srcdir}/${_realname}-${pkgver}/glslc"
  ${MINGW_PREFIX}/bin/asciidoctor -b manpage README.asciidoc -o glslc.1 || true
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/glslc/glslc.1" \
  -t "${pkgdir}${MINGW_PREFIX}/share/man/man1" || true
}
