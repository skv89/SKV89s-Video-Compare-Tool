# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=gnutls
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=3.8.13
pkgrel=3
pkgdesc="A library which provides a secure layer over a reliable transport layer (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:GPL-3.0-or-later' 'spdx:LGPL-2.1-or-later')
url="https://www.gnutls.org/"
msys2_repository_url="https://gitlab.com/gnutls/gnutls"
msys2_references=(
  "cpe: cpe:/a:gnu:gnutls"
)
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-brotli"
         "${MINGW_PACKAGE_PREFIX}-gettext-runtime"
         "${MINGW_PACKAGE_PREFIX}-gmp"
         "${MINGW_PACKAGE_PREFIX}-libidn2"
         "${MINGW_PACKAGE_PREFIX}-libtasn1"
         "${MINGW_PACKAGE_PREFIX}-libunistring"
         "${MINGW_PACKAGE_PREFIX}-libwinpthread"
         "${MINGW_PACKAGE_PREFIX}-nettle"
         "${MINGW_PACKAGE_PREFIX}-p11-kit"
         "${MINGW_PACKAGE_PREFIX}-zlib"
         "${MINGW_PACKAGE_PREFIX}-zstd"
         #"${MINGW_PACKAGE_PREFIX}-unbound"
        )
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-gtk-doc"
             "${MINGW_PACKAGE_PREFIX}-gettext-tools"
             "${MINGW_PACKAGE_PREFIX}-autotools")
options=('!zipman')
# Need remove "autogen" package before building.
source=(https://www.gnupg.org/ftp/gcrypt/gnutls/v${pkgver%.*}/${_realname}-${pkgver}.tar.xz{,.sig}
        0001-fix-build-with-mingw-w64-clang.patch
        0003-gnutls-fix-external-libtasn1-detection.patch
        0004-disable-broken-examples.patch
        0005-remove-coverage-rules.patch)
sha256sums=('ffed8ec1bf09c2426d4f14aae377de4753b53e537d685e604e99a8b16ca9c97e'
            'SKIP'
            '7941d0a98b46b48cc85985a2edf6576a699f854d9147e794c713465ec07958ab'
            '6493f69e782d60fe04de4b0040987e99851c522d0baf2fe25d10b85b63e97863'
            'cbf9e59fb2432d4ac1edcb70734023e074b8058fa4c010a036a40de8449f67fb'
            '10ea5a84459af8d848788cc8871decd3b3cdd542b829883ebe4f6ec28d60578f')
validpgpkeys=('0424D4EE81A0E3D119C6F835EDA21E94B565716F')  # "Simon Josefsson <simon@josefsson.org>"
validpgpkeys+=('1F42418905D8206AA754CCDC29EE58B996865171') # "Nikos Mavrogiannopoulos <nmav@gnutls.org>
validpgpkeys+=('462225C3B46F34879FC8496CD605848ED7E69871') # "Daiki Ueno <ueno@unixuser.org>"
validpgpkeys+=('5D46CB0F763405A7053556F47A75A648B3F9220C') # Zoltan Fridrich <zfridric at redhat.com>
validpgpkeys+=('E987AB7F7E89667776D05B3BB0E9DD20B29F1432') # Alexander Sosedkin <monk at unboiled.info>

apply_patch_with_msg() {
  for _fname in "$@"
  do
    msg2 "Applying ${_fname}"
    patch -Nbp1 -i "${srcdir}"/${_fname}
  done
}

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  apply_patch_with_msg \
    0001-fix-build-with-mingw-w64-clang.patch \
    0003-gnutls-fix-external-libtasn1-detection.patch \
    0004-disable-broken-examples.patch \
    0005-remove-coverage-rules.patch

  WANT_AUTOMAKE=latest autoreconf -fiv -I m4
}

build() {
  # Workaround for localtime_r functions
  CFLAGS+=" -D_POSIX_C_SOURCE -Wno-int-conversion"
  CXXFLAGS+=" -D_POSIX_C_SOURCE -Wno-int-conversion"

  local -a extra_config
  case "${CARCH}" in
    i?86|x86_64)
      ;;
    *)
      extra_config+=(--disable-hardware-acceleration)
      ;;
  esac

  # Weak symbols are broken with GCC + binutils
  # https://github.com/msys2/MINGW-packages/issues/11743
  export gl_cv_have_weak=no

  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  CPPFLAGS+=" -DIN_LIBUNISTRING" \
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --disable-shared \
    --enable-static \
    --enable-cxx \
    --enable-nls \
    --enable-openssl-compatibility \
    --disable-rpath \
    --disable-gtk-doc \
    --with-libiconv-prefix=${MINGW_PREFIX} \
    --without-libintl-prefix \
    --disable-libdane \
    --disable-tests \
    --without-p11-kit \
    "${extra_config[@]}" \
    gl_cv_double_slash_root=yes

  make

  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-shared \
    --disable-static \
    --enable-cxx \
    --enable-nls \
    --enable-openssl-compatibility \
    --disable-rpath \
    --disable-gtk-doc \
    --with-libiconv-prefix=${MINGW_PREFIX} \
    --without-libintl-prefix \
    --disable-libdane \
    --disable-tests \
    "${extra_config[@]}" \
    gl_cv_double_slash_root=yes

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  make -k check || /bin/true

  cd "${srcdir}/build-${MSYSTEM}-shared"
  make -k check || /bin/true
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}/build-${MSYSTEM}-shared"
  make DESTDIR="${pkgdir}" install

  # Since we use --without-p11-kit for the static build
  # use the static .pc which doesn't have p11-kit in Requires.private
  cp "${srcdir}/build-${MSYSTEM}-static/lib/gnutls.pc" "${pkgdir}${MINGW_PREFIX}/lib/pkgconfig/gnutls.pc"

  find "${pkgdir}${MINGW_PREFIX}" -name '*.def' -o -name '*.exp' | xargs -rtl1 rm
  local PREFIX_DEPS=$(cygpath -am ${MINGW_PREFIX})
  find "${pkgdir}"${MINGW_PREFIX}/lib/pkgconfig -name *.pc -exec sed -i -e"s|${PREFIX_DEPS}|${MINGW_PREFIX}|g" {} \;
}
