# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=fontconfig
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=2.18.3
pkgrel=1
pkgdesc="A library for configuring and customizing font access (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://wiki.freedesktop.org/www/Software/fontconfig/"
msys2_repository_url="https://gitlab.freedesktop.org/fontconfig/fontconfig"
msys2_references=(
  "cpe: cpe:/a:fontconfig_project:fontconfig"
)
license=("custom")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-gperf")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-expat"
         "${MINGW_PACKAGE_PREFIX}-freetype")
install=${_realname}-${MSYSTEM}.install
source=("https://gitlab.freedesktop.org/fontconfig/fontconfig/-/archive/${pkgver}/fontconfig-${pkgver}.tar.gz"
        0011-conf-copy-instead-of-symlink.patch
        0012-conf-copy-drive-relative.patch
        fontconfig.hook.in)
sha256sums=('9ae01e1d53acdef56010c5451cd34aa41d325b2faccd8606448d8fa01b2496b3'
            '73ed74a1f4624466084d219e2fbc0d5780da9f63763f1307629251e58cccf2cd'
            'bb754488fbe89158eb756823757a612bdc26c1fdf0389316dc495caf027e4763'
            'ad4ce48983045d7f39b40ca9e04d4be2eaa9177b89dcc516388d779c131a88bc')

prepare() {
  cd "${_realname}-${pkgver}"

  patch -p1 -i "${srcdir}"/0011-conf-copy-instead-of-symlink.patch
  patch -p1 -i "${srcdir}"/0012-conf-copy-drive-relative.patch
}

build() {
  mkdir -p "build-${MSYSTEM}-static" && cd "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --default-library=static \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      -Ddoc-man=disabled \
      -Ddoc-txt=disabled \
      -Ddoc-pdf=disabled \
      -Ddoc-html=disabled \
      -Dcache-build=disabled \
      ../"${_realname}-${pkgver}"

  meson compile

  cd ..
  mkdir -p "build-${MSYSTEM}-shared" && cd "build-${MSYSTEM}-shared"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --default-library=shared \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      -Ddoc-man=disabled \
      -Ddoc-txt=disabled \
      -Ddoc-pdf=disabled \
      -Ddoc-html=disabled \
      -Dcache-build=disabled \
      ../"${_realname}-${pkgver}"

  meson compile
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  DESTDIR="${pkgdir}" meson install

  cd "${srcdir}/build-${MSYSTEM}-shared"
  DESTDIR="${pkgdir}" meson install

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"

  sed -i "s|${MINGW_PREFIX}/etc$|\${prefix}/etc|g" "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/fontconfig.pc
  sed -i "s|${MINGW_PREFIX}/etc/|\${sysconfdir}/|g" "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/fontconfig.pc
  sed -i "s|${MINGW_PREFIX}/var|\${prefix}/var|g" "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/fontconfig.pc

  for hook in fontconfig; do
    local hook_path="${srcdir}/${MINGW_PACKAGE_PREFIX}-${hook}.hook";
    cp "${srcdir}/${hook}.hook.in" "${hook_path}"
    sed -s "s|@MINGW_HOOK_TARGET_PREFIX@|${MINGW_PREFIX:1}|g" -i "${hook_path}"
    sed -s "s|@MINGW_PREFIX@|${MINGW_PREFIX}|g" -i "${hook_path}"
    install -Dt "$pkgdir/usr/share/libalpm/hooks" -m644 "${hook_path}"
  done
}
