# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: James Ross-Gowan <rossymiles@gmail.com>

_realname=mpv
pkgbase="mingw-w64-${_realname}"
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.41.0
pkgrel=10
pkgdesc='Video player based on MPlayer/mplayer2 (mingw-w64)'
arch=('any')
mingw_arch=('ucrt64' 'clang64' 'clangarm64')
url='https://mpv.io/'
msys2_repository_url='https://github.com/mpv-player/mpv'
msys2_references=(
  'anitya: 5348'
  'archlinux: mpv'
  'aur:' # ignore libmpv-git
  'cpe: cpe:/a:mpv:mpv'
  'gentoo: media-video/mpv'
)
license=('spdx:GPL-2.0-or-later')
depends=(
  'winpty'
  "${MINGW_PACKAGE_PREFIX}-ffmpeg"
  "${MINGW_PACKAGE_PREFIX}-lcms2"
  "${MINGW_PACKAGE_PREFIX}-libarchive"
  "${MINGW_PACKAGE_PREFIX}-libass"
  "${MINGW_PACKAGE_PREFIX}-libbluray"
  "${MINGW_PACKAGE_PREFIX}-libcaca"
  "${MINGW_PACKAGE_PREFIX}-libcdio-paranoia"
  "${MINGW_PACKAGE_PREFIX}-libcdio"
  "${MINGW_PACKAGE_PREFIX}-libdvdnav"
  "${MINGW_PACKAGE_PREFIX}-libdvdread"
  "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
  "${MINGW_PACKAGE_PREFIX}-libplacebo"
  "${MINGW_PACKAGE_PREFIX}-lua51"
  "${MINGW_PACKAGE_PREFIX}-mujs"
  "${MINGW_PACKAGE_PREFIX}-rubberband"
  "${MINGW_PACKAGE_PREFIX}-shaderc"
  "${MINGW_PACKAGE_PREFIX}-spirv-cross"
  "${MINGW_PACKAGE_PREFIX}-uchardet"
  "${MINGW_PACKAGE_PREFIX}-vapoursynth"
  "${MINGW_PACKAGE_PREFIX}-vulkan"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
  "${MINGW_PACKAGE_PREFIX}-python-docutils"
  "${MINGW_PACKAGE_PREFIX}-python-rst2pdf"
  "${MINGW_PACKAGE_PREFIX}-vulkan-headers"
)
optdepends=(
  "${MINGW_PACKAGE_PREFIX}-yt-dlp: for video-sharing websites playback"
)
source=(
  "https://github.com/mpv-player/${_realname}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz"
)
sha256sums=('ee21092a5ee427353392360929dc64645c54479aefdb5babc5cfbb5fad626209')

build() {
  local _meson_options=(
    --prefix="${MINGW_PREFIX}"
    --wrap-mode=nodownload
    --buildtype=plain
    -Dcdda=enabled
    -Ddvdnav=enabled
    -Djavascript=enabled
    -Dlibmpv=true
  )

  if [[ "${CARCH}" == 'aarch64' ]]; then
    _meson_options+=(-Dgl=disabled)
  fi

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
    "${_meson_options[@]}" \
    "build-${MSYSTEM}" \
    "${_realname}-${pkgver}"

  meson compile -C "build-${MSYSTEM}"
}

package() {
  DESTDIR="${pkgdir}" meson install -C "build-${MSYSTEM}"

  # mpv needs winpty for key bindings to work on the terminal
  mv "${pkgdir}${MINGW_PREFIX}/bin/mpv.exe" "${pkgdir}${MINGW_PREFIX}/bin/mpv_exe"

  local _exename='mpv'
  cat <<'EOF' >"${pkgdir}${MINGW_PREFIX}/bin/${_exename}"
#!/usr/bin/env bash
export _started_from_console=yes
/usr/bin/winpty "$( dirname ${BASH_SOURCE[0]} )/mpv.exe" "$@"
EOF

  chmod +x "${pkgdir}${MINGW_PREFIX}/bin/${_exename}"

  mv "${pkgdir}${MINGW_PREFIX}/bin/mpv_exe" "${pkgdir}${MINGW_PREFIX}/bin/mpv.exe"
}
