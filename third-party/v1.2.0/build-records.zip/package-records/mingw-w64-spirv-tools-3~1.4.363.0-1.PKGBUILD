# Maintainer: J. Peter Mugaas <jpmugaas@suddenlink.net>
# Contributor: Biswapriyo Nath <nathbappai@gmail.com>

_realname=spirv-tools
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
epoch=3
pkgver=1.4.363.0
pkgrel=1
pkgdesc="API and commands for processing SPIR-V modules (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.khronos.org/vulkan/"
msys2_repository_url="https://github.com/KhronosGroup/SPIRV-Tools"
msys2_references=(
  'archlinux: spirv-tools'
  'gentoo: dev-util/spirv-tools'
)
license=('spdx:Apache-2.0')
groups=("${MINGW_PACKAGE_PREFIX}-vulkan-devel")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-python"
             "${MINGW_PACKAGE_PREFIX}-spirv-headers")
source=("https://github.com/KhronosGroup/SPIRV-Tools/archive/vulkan-sdk-${pkgver}/${_realname}-${pkgver}.tar.gz"
        002-Do-not-statically-link-to-the-C-runtime-with-mingw.patch)
sha256sums=('e6c83a215538fbfd265ccf398d3877985055df1273dbed73912bd05307664688'
            'ff63fc6e786e6b40b3ec5fa7356b671a391e3c29b7660dcc87d799de49754d2a')

prepare() {
  cd SPIRV-Tools-vulkan-sdk-${pkgver}
  patch -p1 -i "${srcdir}"/002-Do-not-statically-link-to-the-C-runtime-with-mingw.patch
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  echo "Building static library"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-static && cd "${srcdir}"/build-${MSYSTEM}-static

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
      -G "Ninja" \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DSPIRV_WERROR=OFF \
      -DBUILD_SHARED_LIBS=OFF \
      -DSPIRV_TOOLS_BUILD_STATIC=ON \
      -DSPIRV_SKIP_EXECUTABLES=ON \
      -DSPIRV_SKIP_TESTS=ON \
      -DSPIRV-Headers_SOURCE_DIR=${MINGW_PREFIX} \
      -DPython3_EXECUTABLE=${MINGW_PREFIX}/bin/python \
      ../SPIRV-Tools-vulkan-sdk-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./

  echo "Building shared library"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-shared && cd "${srcdir}"/build-${MSYSTEM}-shared

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
      -G "Ninja" \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DSPIRV_WERROR=OFF \
      -DBUILD_SHARED_LIBS=ON \
      -DSPIRV_TOOLS_BUILD_STATIC=OFF \
      -DSPIRV_SKIP_TESTS=ON \
      -DSPIRV-Headers_SOURCE_DIR=${MINGW_PREFIX} \
      -DPython3_EXECUTABLE=${MINGW_PREFIX}/bin/python \
      ../SPIRV-Tools-vulkan-sdk-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}-static
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install ./

  cd "${srcdir}"/build-${MSYSTEM}-shared
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install ./

  install -dm755 "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}"
  install -m644 "${srcdir}"/SPIRV-Tools-vulkan-sdk-${pkgver}/LICENSE "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/"

  local _WIN_PREFIX=$(cygpath -am ${MINGW_PREFIX})
  for _f in "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/*.pc; do
    sed -e "s|${_WIN_PREFIX}|${MINGW_PREFIX}|g" -i ${_f}
  done
}
