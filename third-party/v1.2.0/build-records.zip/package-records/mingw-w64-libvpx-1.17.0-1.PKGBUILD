# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libvpx
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.17.0
pkgrel=1
pkgdesc="The VP8/VP9 Codec SDK (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.webmproject.org/"
msys2_repository_url="https://github.com/webmproject/libvpx"
msys2_references=(
  "cpe: cpe:/a:webmproject:libvpx"
)
license=('spdx:BSD-3-Clause')
depends=("${MINGW_PACKAGE_PREFIX}-libwinpthread")
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc"
             $([[ "${CARCH}" == "aarch64" ]] || echo "${MINGW_PACKAGE_PREFIX}-nasm")
             "${MINGW_PACKAGE_PREFIX}-winpthreads")
source=(https://github.com/webmproject/libvpx/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz
        0001-enable-shared-on.mingw.patch)
sha256sums=('1020f184046187baa2985dbde38e0691f49c44088bca7a1842b0236c6081dc0a'
            'f37a24525725cad215d73c538c0b06343b043f2b07553e7dc25835bd68af0695')

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  msg2 "Applying $1"
  patch -Np1 -i "${srcdir}"/$1
}

del_file_exists() {
  for _fname in "$@"
  do
    if [ -f $_fname ]; then
      rm -rf $_fname
    fi
  done
}
# =========================================== #


prepare() {
  cd "${srcdir}"/${_realname}-${pkgver}

  apply_patch_with_msg 0001-enable-shared-on.mingw.patch
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  case "${MINGW_CHOST}" in
    "i686-w64-mingw32")
      _targetarch="x86-win32-gcc"
      EXTRA_CFLAGS="-mstackrealign"
      ;;
    "x86_64-w64-mingw32")
      _targetarch="x86_64-win64-gcc"
      ;;
    "aarch64-w64-mingw32")
      _targetarch="arm64-win64-gcc"
      ;;
  esac

  LD=cc CFLAGS="$EXTRA_CFLAGS $CFLAGS -fno-asynchronous-unwind-tables" \
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --target=${_targetarch} \
    --enable-vp8 \
    --enable-vp9 \
    --enable-vp9-highbitdepth \
    --enable-vp9-temporal-denoising \
    --enable-runtime-cpu-detect \
    --enable-postproc \
    --enable-pic \
    --enable-shared \
    --enable-static \
    --enable-experimental \
    --disable-examples \
    --disable-docs \
    --disable-install-docs \
    --disable-install-srcs \
    --disable-unit-tests

  for _ff in *.mk; do
    sed -i "s/HAVE_GNU_STRIP=yes/HAVE_GNU_STRIP=no/g" $_ff
  done
  make #-j1
}

#These tests seem to take a lot of time
#check() {
#  cd "${srcdir}/build-$MSYSTEM"
#  make test
#}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DIST_DIR="${pkgdir}${MINGW_PREFIX}" install
}
