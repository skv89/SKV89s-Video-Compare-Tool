# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=lz4
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.10.0
pkgrel=1
pkgdesc="Very fast lossless compression algorithm (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clang32' 'clangarm64')
url="https://lz4.github.io/lz4/"
msys2_references=(
  "cpe: cpe:/a:lz4_project:lz4"
)
license=('BSD' 'GPL2')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc")
checkdepends=('diffutils')
options=('staticlibs' 'strip')
source=(${_realname}-${pkgver}.tar.gz::"https://github.com/lz4/lz4/archive/v${pkgver}.tar.gz")
sha256sums=('537512904744b35e232912055ccf8ec66d768639ff3abe5788d90d792ec5f48b')

build() {
  [[ -d "${srcdir}/build-${MSYSTEM}" ]] && rm -rf "${srcdir}/build-${MSYSTEM}"
  cp -rf "${srcdir}/${_realname}-${pkgver}" "${srcdir}/build-${MSYSTEM}"
  cd "${srcdir}/build-${MSYSTEM}"

  make CC=${MINGW_PREFIX}/bin/cc
}

check() {
  cd ${srcdir}
  msg2 "rm -f profile.lz4"
  rm -f profile.lz4 || true

  ${srcdir}/build-${MSYSTEM}/programs/lz4 /etc/profile profile.lz4
  ${srcdir}/build-${MSYSTEM}/programs/lz4 -d profile.lz4 profile
  diff -q /etc/profile profile

  rm profile

#  cd "${srcdir}/build-${MSYSTEM}"
#  make test
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make CC=${MINGW_PREFIX}/bin/cc DESTDIR="${pkgdir}" PREFIX=${MINGW_PREFIX} install
}
