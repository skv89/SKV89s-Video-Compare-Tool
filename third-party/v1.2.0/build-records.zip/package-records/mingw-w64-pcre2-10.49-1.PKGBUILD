# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=pcre2
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=10.49
pkgrel=1
pkgdesc="A library that implements Perl 5-style regular expressions (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://pcre.org/"
msys2_repository_url="https://github.com/PhilipHazel/pcre2"
msys2_changelog_url="https://github.com/PCRE2Project/pcre2/blob/master/NEWS"
msys2_references=(
  "archlinux: pcre2"
  "cpe: cpe:/a:pcre:pcre"
  "cpe: cpe:/a:pcre:pcre2"
)
license=("spdx:BSD-3-Clause")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
)
depends=(
  "${MINGW_PACKAGE_PREFIX}-bzip2"
  #"${MINGW_PACKAGE_PREFIX}-readline"
  "${MINGW_PACKAGE_PREFIX}-wineditline"
  "${MINGW_PACKAGE_PREFIX}-zlib"
)
source=("${msys2_repository_url}/releases/download/${_realname}-${pkgver}/${_realname}-${pkgver}.tar.bz2"{,.sig}
        '0001-pcre2test-wineditline.patch')
sha256sums=('53c156e1ba416a20da8e65395daa132da0d80e76910424caca3fcdae7831d384'
            'SKIP'
            '73400390211bfaf1ad7e5b900335bc48b50d9bd1aa5b864fa54a3e8f666d5eb9')
validpgpkeys=('A95536204A3BB489715231282A98E77EB6F24CA8') # Nicholas Wilson <nicholas@nicholaswilson.me.uk>

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  patch -Np1 -i "${srcdir}/0001-pcre2test-wineditline.patch"
}

build() {
  local -a _common_config=(
    --prefix=${MINGW_PREFIX}
    --build=${MINGW_CHOST}
    --host=${MINGW_CHOST}
    --target=${MINGW_CHOST}
    --enable-jit
    --enable-pcre2-8
    --enable-pcre2-16
    --enable-pcre2-32
    --enable-pcre2grep-libz
    --enable-pcre2grep-libbz2
    --enable-pcre2test-libedit
  )

  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  CPPFLAGS+=" -DPCRE2_STATIC" \
  "${srcdir}/${_realname}-${pkgver}/configure" \
    "${_common_config[@]}" \
    --enable-static \
    --disable-shared

  make

  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  "${srcdir}/${_realname}-${pkgver}/configure" \
    "${_common_config[@]}" \
    --enable-shared \
    --disable-static

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  make check || true

  cd "${srcdir}/build-${MSYSTEM}-shared"
  make check || true
}

package() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}/build-${MSYSTEM}-shared"
  make DESTDIR="${pkgdir}" install

  # License files
  cd "${pkgdir}${MINGW_PREFIX}/share"
  mkdir -p licenses/${_realname}
  mv doc/${_realname}/COPYING licenses/${_realname}
  mv doc/${_realname}/LICENCE.md licenses/${_realname}
}
