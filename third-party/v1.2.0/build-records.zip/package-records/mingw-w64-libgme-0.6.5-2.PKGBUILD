# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libgme
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.6.5
pkgrel=2
pkgdesc="Video game music file emulation/playback library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/libgme/game-music-emu"
msys2_repository_url='https://github.com/libgme/game-music-emu'
msys2_references=(
  "cpe: cpe:/a:game-music-emu_project:game-music-emu"
)
license=('LGPL')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-zlib")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
options=('!emptydirs')
source=("https://github.com/libgme/game-music-emu/releases/download/${pkgver}/${_realname}-${pkgver}-src.tar.gz")
sha256sums=('a133f19278222136ba0d8c27b64a07987ba05fec9d2e6d293ccd8cabdd97ddbb')

build() {
  mkdir "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake \
    -GNinja \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DCMAKE_BUILD_TYPE=Release \
    -DGME_BUILD_SHARED=ON \
    -DGME_BUILD_STATIC=ON \
    -DGME_BUILD_TESTING=OFF \
    -DGME_BUILD_EXAMPLES=OFF \
    -DGME_ENABLE_UBSAN=OFF \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/cmake --build .
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install .

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/license.txt" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/license.txt"
}
