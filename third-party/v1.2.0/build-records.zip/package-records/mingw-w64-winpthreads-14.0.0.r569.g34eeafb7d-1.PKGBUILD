# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Martell Malone <martellmalone@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=winpthreads
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}" "${MINGW_PACKAGE_PREFIX}-libwinpthread")
pkgver=14.0.0.r569.g34eeafb7d
pkgrel=1
_commit='34eeafb7d0e5b037b4644c17defc4f4131ad85cc'
pkgdesc="MinGW-w64 winpthreads library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.mingw-w64.org/"
msys2_repository_url="https://sourceforge.net/p/mingw-w64/mingw-w64/ci/master/tree/mingw-w64-libraries/winpthreads"
# The main license of `winpthreads' is MIT, but parts of this library are
# derived from the "POSIX Threads for Microsoft Windows" library, which is
# licensed under BSD (https://locklessinc.com/articles/pthreads_on_windows/)
license=('spdx:MIT AND BSD-3-Clause')
groups=("${MINGW_PACKAGE_PREFIX}-toolchain")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-crt"
  "${MINGW_PACKAGE_PREFIX}-headers"
  'git'
)
options=('!emptydirs')
source=("mingw-w64"::"git+https://git.code.sf.net/p/mingw-w64/mingw-w64#commit=${_commit}")
sha256sums=('09e0b1df237e310561963ade682286855ef45119550df4ca64e712854bc4aaa6')

pkgver() {
  cd 'mingw-w64'
  git describe --long ${_commit} | sed 's/\([^-]*-g\)/r\1/;s/-/./g;s/^v//g'
}

build() {
  mkdir -p "build-${MSYSTEM}" && cd "build-${MSYSTEM}"

  # https://github.com/msys2/MINGW-packages/issues/7043
  CFLAGS="${CFLAGS//-Wp,-D__USE_MINGW_ANSI_STDIO=1/}"
  CXXFLAGS="${CXXFLAGS//-Wp,-D__USE_MINGW_ANSI_STDIO=1/}"

  # https://github.com/msys2/MINGW-packages/issues/27566
  if [[ ${MSYSTEM} == MINGW32 ]]; then
    LDFLAGS="${LDFLAGS//-Wl,--no-seh/}"
  fi

  declare -a extra_config
  if check_option "debug" "y"; then
    extra_config+=("CFLAGS=-O0 -g -DWINPTHREAD_DBG")
    extra_config+=("CXXFLAGS=-O0 -g -DWINPTHREAD_DBG")
  fi

  ../mingw-w64/mingw-w64-libraries/winpthreads/configure \
    --prefix=${MINGW_PREFIX} \
    --enable-static \
    --enable-shared \
    "${extra_config[@]}"

  # I failed to figure out how to disable stripping, this
  # will have to do instead.
  if check_option "strip" "n"; then
    sed -i 's,^STRIP = .*$,STRIP = true,g'                Makefile
    sed -i 's,^STRIP=.*$,STRIP=true,g'                    libtool
    sed -i 's,old_striplib=.*$strip,old_striplib=true,g'  libtool
    sed -i 's,striplib=.*$,striplib=true,g'               libtool
  fi

  make
}

package_winpthreads() {
  depends=(
    "${MINGW_PACKAGE_PREFIX}-crt"
    "${MINGW_PACKAGE_PREFIX}-libwinpthread=${pkgver}"
  )
  provides=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
  conflicts=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
  replaces=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")

  cd "build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  rm -rf "${pkgdir}${MINGW_PREFIX}/bin"

  install -Dm644 "${srcdir}/mingw-w64/mingw-w64-libraries/${_realname}/COPYING" \
    -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/"
}

package_libwinpthread() {
  provides=("${MINGW_PACKAGE_PREFIX}-libwinpthread-git")
  conflicts=("${MINGW_PACKAGE_PREFIX}-libwinpthread-git")
  replaces=("${MINGW_PACKAGE_PREFIX}-libwinpthread-git")

  cd "build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  rm -rf "${pkgdir}${MINGW_PREFIX}/include"
  rm -rf "${pkgdir}${MINGW_PREFIX}/lib"

  install -Dm644 "${srcdir}/mingw-w64/mingw-w64-libraries/${_realname}/COPYING" \
    -t "${pkgdir}${MINGW_PREFIX}/share/licenses/libwinpthread/"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
