# Maintainer: Andrew Sun <adsun701@gmail.com>

_realname=libsoxr
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.1.3
pkgrel=6
pkgdesc="The SoX Resampler library that aims to give fast and high quality results for any constant resampling ratio (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://sourceforge.net/p/soxr/wiki/Home/"
msys2_repository_url='https://sourceforge.net/p/soxr/code'
license=("spdx:LGPL-2.1-or-later")
depends=("${MINGW_PACKAGE_PREFIX}-omp")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "git")
source=("git+https://git.code.sf.net/p/soxr/code#commit=945b592b70470e29f917f4de89b4281fbbd540c0"
        "0001-libsoxr-fix-pkgconfig-file.patch"
        "0002-libsoxr-fix-documentation-installation.patch"
        "LICENSE-PFFFT")
sha256sums=('SKIP'
            '77c45009fd5b84b56c8b0b5a90dcc6a093d129e571d13afc086c7dfe02c2be96'
            '7c16beb3898279db96b09b365c069071b371a1022f0baf12bb3da9d45d387fdf'
            'a9f3d236f3c14a41a1293f176d4c7c46d85404403417fcb8df6d6c9707104e42')

prepare() {
  cd "${srcdir}/code"
  patch -Np1 -i "${srcdir}/0001-libsoxr-fix-pkgconfig-file.patch"
  patch -Np1 -i "${srcdir}/0002-libsoxr-fix-documentation-installation.patch"
}

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  # Build shared
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake -Wno-author \
  -G"Ninja" \
  -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
  -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
  -DBUILD_EXAMPLES=OFF \
  -DBUILD_TESTS=OFF \
  -DBUILD_SHARED_LIBS=ON \
  -DWITH_AVFFT=OFF \
  -DWITH_LSR_BINDINGS=ON \
  -DWITH_PFFFT=ON \
  -DWITH_OPENMP=ON \
  "${extra_config[@]}" \
  -S code \
  -B build-${MSYSTEM}-shared

  ${MINGW_PREFIX}/bin/cmake --build build-${MSYSTEM}-shared

  # Build static
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake -Wno-author \
  -G"Ninja" \
  -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
  -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
  -DBUILD_EXAMPLES=OFF \
  -DBUILD_TESTS=OFF \
  -DBUILD_SHARED_LIBS=OFF \
  -DWITH_AVFFT=OFF \
  -DWITH_LSR_BINDINGS=ON \
  -DWITH_OPENMP=ON \
  -DWITH_PFFFT=ON \
  "${extra_config[@]}" \
  -S code \
  -B build-${MSYSTEM}-static

  ${MINGW_PREFIX}/bin/cmake --build build-${MSYSTEM}-static
}

package() {
  # Install static
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install build-${MSYSTEM}-static
  # Install shared
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake --install build-${MSYSTEM}-shared

  # License
  install -Dm644 "${srcdir}"/code/LICENCE "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
  install -Dm644 "${srcdir}"/code/COPYING.LGPL "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/
  install -Dm644 "${srcdir}"/LICENSE-PFFFT "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/
}
