# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=jbigkit
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=2.1
pkgrel=6
pkgdesc="Data compression library/utilities for bi-level high-resolution images (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.cl.cam.ac.uk/~mgk25/jbigkit/"
license=('spdx:GPL-2.0')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-libtool"
)
source=("https://www.cl.cam.ac.uk/~mgk25/download/${_realname}-${pkgver}.tar.gz"
        allNewMainMakefile.all.patch
        manfiles.all.patch
        pbmtoolsMakefile.all.patch
        useLibtool.all.patch
        zzz_debug.mingw.patch)
sha256sums=('de7106b6bfaf495d6865c7dd7ac6ca1381bd12e0d81405ea81e7f2167263d932'
            'ce210309c47214599c451e680043dc827980ace647385c4ae26f3725d1054d97'
            'd5cce4c1bae575563cb892c93de349a7747435c175e81ee57d77e65079d11908'
            '7f268260d596275a1bbe803a829baf6c4a6938f9e23e861dd433622e12c2487e'
            '10877f4c14c1251871b8d733b9748d8db66cb4d7e0453cfd92a5b30e1c268e5e'
            'fe579b90d3b34e6d3209af91fcd9f84a172c2e45ca88a8b23e84f8eacd04f941')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  patch -p1 -i "${srcdir}"/allNewMainMakefile.all.patch
  patch -p1 -i "${srcdir}"/manfiles.all.patch
  patch -p1 -i "${srcdir}"/pbmtoolsMakefile.all.patch
  patch -p1 -i "${srcdir}"/useLibtool.all.patch
  patch -p1 -i "${srcdir}"/zzz_debug.mingw.patch
}

build() {
  cp -rf ${_realname}-${pkgver} build-${MSYSTEM}
  cd "${srcdir}/build-${MSYSTEM}"
  unset CFLAGS CPPFLAGS LDFLAGS
  make CC=${CC} prefix=${MINGW_PREFIX}
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" prefix=${MINGW_PREFIX} install
  install -Dm644 COPYING "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}
