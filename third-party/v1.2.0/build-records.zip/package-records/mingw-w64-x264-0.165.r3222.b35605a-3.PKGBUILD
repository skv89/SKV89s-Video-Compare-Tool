# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=x264
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-libx264" "${MINGW_PACKAGE_PREFIX}-x264")
pkgver=0.165.r3222.b35605a
pkgrel=3
pkgdesc="Library for encoding H264/AVC video streams (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.videolan.org/developers/x264.html"
msys2_repository_url="https://code.videolan.org/videolan/x264"
license=("custom")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-ffmpeg"
             "${MINGW_PACKAGE_PREFIX}-l-smash"
             "${MINGW_PACKAGE_PREFIX}-ffms2"
              $( [[ "${CARCH}" != "i686" \
                && "${CARCH}" != "x86_64" ]] \
                || echo "${MINGW_PACKAGE_PREFIX}-nasm" )
             "git")
_commit="b35605ace3ddf7c1a5d67a2eb553f034aef41d55"
source=("${_realname}"::"git+https://code.videolan.org/videolan/${_realname}.git#commit=${_commit}"
        0001-beautify-pc.all.patch
        0002-install-avisynth_c.h.mingw.patch
        0003-pkgconfig-add-Cflags-private.patch)
sha256sums=('e92edc35efe3f8c3effb0c04854de0f8428cc09a218b2062ec3fe44f8ad2aa4e'
            '8e92f4d6c1924664e7c9f5b797070a35f8eabbfce431f996167fe426fc833dda'
            '611d427742347e0dfbcea8d45c8c9b0fd15e29ab0b22207000f8bf5f3ba1a3a9'
            '0cbf016c01291f1b8b97ffabdf7e52a8a8593ddf8d88c782245b60462a18bd60')

pkgver() {
  cd "${srcdir}"/${_realname}

  ./version.sh | grep X264_POINTVER | sed -r 's/^#define X264_POINTVER "([0-9]+\.[0-9]+)\.([0-9]+)M? (.*)"$/\1.r\2.\3/'
}

prepare() {
  cd ${_realname}
  patch -p1 -i "${srcdir}"/0001-beautify-pc.all.patch
  patch -p1 -i "${srcdir}"/0002-install-avisynth_c.h.mingw.patch
  patch -p1 -i "${srcdir}"/0003-pkgconfig-add-Cflags-private.patch
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}/configure \
    --prefix=${MINGW_PREFIX} \
    --host=${MINGW_CHOST} \
    --enable-static \
    --enable-shared

  make

  make DESTDIR="${srcdir}/dest/libx264" install

  mkdir -p "${srcdir}/dest/x264"
  mkdir -p "${srcdir}/dest/x264${MINGW_PREFIX}/bin"
  mv "${srcdir}/dest/libx264${MINGW_PREFIX}/bin/"*.exe "${srcdir}/dest/x264${MINGW_PREFIX}/bin"
}

package_libx264() {
  depends=()

  cp -r "${srcdir}/dest/libx264/"* "${pkgdir}"
}

package_x264() {
  # Note: libx264 is stricly not needed, but existing users of the x264 package
  # before the split expect the library to be included
  depends=(
    "${MINGW_PACKAGE_PREFIX}-ffmpeg"
    "${MINGW_PACKAGE_PREFIX}-l-smash"
    "${MINGW_PACKAGE_PREFIX}-libx264"
    "${MINGW_PACKAGE_PREFIX}-ffms2")
  provides=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
  conflicts=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
  replaces=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")

  cp -r "${srcdir}/dest/x264/"* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
