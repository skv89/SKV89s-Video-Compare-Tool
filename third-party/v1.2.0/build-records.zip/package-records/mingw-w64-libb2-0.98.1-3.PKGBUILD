# Maintainer: J. Peter Mugaas <jpmugaas@suddenlink.net>

_realname=libb2
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=0.98.1
pkgrel=3
pkgdesc="C library providing BLAKE2b, BLAKE2s, BLAKE2bp, BLAKE2sp hash functions (mingw-w64)"
arch=('any')
url='https://blake2.net/'
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('custom:CC0')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://github.com/BLAKE2/${_realname}/releases/download/v$pkgver/${_realname}-$pkgver.tar.gz"
        https://github.com/BLAKE2/libb2/commit/c4283b3469f94d6e209b5f22a4cea6ba1f27d8a8.patch
        https://github.com/BLAKE2/libb2/commit/186ffdfcde580b609ed46af10553924408bed878.patch
        https://github.com/BLAKE2/libb2/commit/1705999115f86418b781e33eeecc969dd169cb86.patch
        https://github.com/BLAKE2/libb2/commit/48e205f0700f7f010e082aed0e273850b09b5907.patch)
sha256sums=('53626fddce753c454a3fea581cbbc7fe9bbcf0bc70416d48fdbbf5d87ef6c72e'
            '659ed91b71240e3137f59b95996c26ada973a5c4245d1943a24f45667a8342af'
            'ad6ded2c28cd141ddcafc45191b9fe0741bd7a90530088eeb837389cc3406e0d'
            '745a67e5abeee1617bbe1e94b35bc1c981aa7c9e22c49fdaf5d8aac4defcb4a4'
            '937bdbee7c1dd7ad2f4185e41889c51c165c99cd6d7cccd0617148e890d545e1')

# libb2's build system discards the $CFLAGS variable.
# We can get around this by putting those flags in $CC.
export CC="${CC-cc} $CFLAGS"

apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}


prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  
  apply_patch_with_msg \
    c4283b3469f94d6e209b5f22a4cea6ba1f27d8a8.patch \
    186ffdfcde580b609ed46af10553924408bed878.patch \
    1705999115f86418b781e33eeecc969dd169cb86.patch \
    48e205f0700f7f010e082aed0e273850b09b5907.patch
}

build() {
  cd "${srcdir}/${_realname}-${pkgver}"
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  # --disable-openmp: https://github.com/msys2/MINGW-packages/pull/10707#issuecomment-1044619096
  ../"${_realname}-${pkgver}"/configure \
    --prefix="${MINGW_PREFIX}" \
    --build="${MINGW_CHOST}" \
    --host="${MINGW_CHOST}" \
    --target="${MINGW_CHOST}" \
    --disable-openmp \
    --enable-static \
    --enable-shared

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  make check
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  make install DESTDIR="${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
