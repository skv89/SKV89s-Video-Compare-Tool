# Maintainer: Andrew Sun <adsun701@gmail.com>

_realname=zimg
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=3.0.6
pkgrel=3
pkgdesc="Scaling, colorspace conversion, and dithering library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/sekrit-twc/zimg"
msys2_repository_url='https://github.com/sekrit-twc/zimg'
license=('spdx:WTFPL')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-libwinpthread")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
source=("https://github.com/sekrit-twc/${_realname}/archive/release-${pkgver}/${_realname}-${pkgver}.tar.gz"
        0001-zimg-export-def-symbols.patch)
noextract=("${_realname}-${pkgver}.tar.gz")
sha256sums=('be89390f13a5c9b2388ce0f44a5e89364a20c1c57ce46d382b1fcc3967057577'
            '6e52d715d19080434392f04b33005fee428368e12176da20555f4059209c8134')

prepare(){
  bsdtar -xzf "${srcdir}/${_realname}-${pkgver}.tar.gz" || bsdtar -xzf "${srcdir}/${_realname}-${pkgver}.tar.gz"
  cd "${srcdir}/${_realname}-release-${pkgver}"
  patch -p1 -i "${srcdir}/0001-zimg-export-def-symbols.patch"
  ./autogen.sh
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../${_realname}-release-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-static \
    --enable-shared

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install
}
