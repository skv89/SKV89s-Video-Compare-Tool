# Maintainer: J. Peter Mugaas <jpmugaas@suddenlink.net>
# Contributor: wirx6 <wirx654@gmail.com>

_realname=Vulkan-Headers
pkgbase=mingw-w64-vulkan-headers
pkgname=("${MINGW_PACKAGE_PREFIX}-vulkan-headers")
pkgver=1.4.363.0
pkgrel=1
epoch=1
pkgdesc='Vulkan header files (mingw-w64)'
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.khronos.org/vulkan/"
msys2_repository_url="https://github.com/KhronosGroup/Vulkan-Headers"
msys2_references=(
  'anitya: 88835'
  'archlinux: vulkan-headers'
  'cpe: cpe:2.3:a:khronos:vulkan'
  'gentoo: dev-util/vulkan-headers'
)
license=('spdx:Apache-2.0')
groups=("${MINGW_PACKAGE_PREFIX}-vulkan-devel")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=("https://github.com/KhronosGroup/${_realname}/archive/vulkan-sdk-${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('4a078be12bef21cfebc09d878b77a63cff9d68f899254a0b00d0e37ef73e7f7e')

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  CFLAGS+=" -D__STDC_FORMAT_MACROS" \
  CPPFLAGS+=" -D__STDC_FORMAT_MACROS" \
  CXXFLAGS+=" -D__USE_MINGW_ANSI_STDIO -D__STDC_FORMAT_MACROS -fpermissive" \
  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
  ${MINGW_PREFIX}/bin/cmake.exe \
    -G "Ninja" \
    "${extra_config[@]}" \
    -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
    -DCMAKE_INSTALL_LIBDIR=lib \
    ../${_realname}-vulkan-sdk-${pkgver}

  ${MINGW_PREFIX}/bin/cmake.exe --build ./
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .

  install -Dm644 "${srcdir}"/${_realname}-vulkan-sdk-${pkgver}/LICENSE.md "${pkgdir}"${MINGW_PREFIX}/share/licenses/vulkan-headers/LICENSE
}
