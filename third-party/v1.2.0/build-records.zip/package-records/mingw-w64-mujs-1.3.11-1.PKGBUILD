# Contributor: Raed Rizqie <raed.rizqie@gmail.com>

_realname=mujs
pkgbase="mingw-w64-${_realname}"
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.3.11
pkgrel=1
pkgdesc='A lightweight Javascript interpreter designed for embedding in other software (mingw-w64)'
arch=('any')
mingw_arch=('ucrt64' 'clang64' 'clangarm64')
url='https://mujs.com/'
msys2_repository_url='https://cgit.ghostscript.com/cgi-bin/cgit.cgi/mujs.git/'
msys2_references=(
  'anitya: 269367'
  'archlinux: mujs'
  'aur:' # ignore mujs-git
  'cpe: cpe:/a:artifex:mujs'
  'gentoo: dev-lang/mujs'
)
msys2_ignore_vulnerabilities=(
  'CVE-2016-10133' # fixed
  'CVE-2016-10141' # fixed
  'CVE-2016-7504' # fixed
  'CVE-2016-9294' # fixed
  'CVE-2017-5627' # fixed
  'CVE-2017-5628' # fixed
)
license=('spdx:ISC')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-python"
  "${MINGW_PACKAGE_PREFIX}-readline"
)
source=(
  "https://mujs.com/downloads/${_realname}-${pkgver}.tar.gz"
  'https://raw.githubusercontent.com/unicode-org/unicodetools/refs/heads/main/unicodetools/data/ucd/16.0.0/UnicodeData.txt'
  'https://raw.githubusercontent.com/unicode-org/unicodetools/refs/heads/main/unicodetools/data/ucd/16.0.0/SpecialCasing.txt'
  '001-makefile-fix.patch'
)
sha256sums=('456a395769daf110a30f9bf6f793044261e261481d5dca33b63cdc8714774ca4'
            'ff58e5823bd095166564a006e47d111130813dcf8bf234ef79fa51a870edb48f'
            '8d5de354eef79f2395a54c9c7dcebbaf3d30fc962d0f85611ea97aa973a0c451'
            'f4020f8a0f3b5d3bcfcb27d5ed9df8b8bba631f60deb2e35e2426ef74e9cc545')

prepare() {
  cd "${_realname}-${pkgver}"

  patch -Np1 -i "${srcdir}/001-makefile-fix.patch"

  # Avoid downloading during the build; also the download is unreliable from GHA.
  cp "${srcdir}/UnicodeData.txt" .
  cp "${srcdir}/SpecialCasing.txt" .
}

build() {
  cd "${_realname}-${pkgver}"

  make prefix="${MINGW_PREFIX}" release
}

package() {
  cd "${_realname}-${pkgver}"

  make DESTDIR="${pkgdir}" prefix="${MINGW_PREFIX}" install

  install -Dm644 COPYING -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/"
  install -Dm644 README -t "${pkgdir}${MINGW_PREFIX}/share/doc/${_realname}/"

  for _file in docs/*; do
    install -Dm644 "${_file}" "${pkgdir}${MINGW_PREFIX}/share/doc/${_realname}/${_file#docs/}"
  done
}
