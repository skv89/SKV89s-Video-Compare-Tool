# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=pango
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-docs")
pkgver=1.58.2
pkgrel=1
pkgdesc="A library for layout and rendering of text (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.pango.org/"
msys2_repository_url="https://gitlab.gnome.org/GNOME/pango"
msys2_references=(
  "cpe: cpe:/a:gnome:pango"
  "cpe: cpe:/a:pango:pango"
)
license=('spdx:LGPL-2.1')
depends=("${MINGW_PACKAGE_PREFIX}-cairo"
         "${MINGW_PACKAGE_PREFIX}-freetype"
         "${MINGW_PACKAGE_PREFIX}-fontconfig"
         "${MINGW_PACKAGE_PREFIX}-glib2"
         "${MINGW_PACKAGE_PREFIX}-harfbuzz"
         "${MINGW_PACKAGE_PREFIX}-fribidi"
         "${MINGW_PACKAGE_PREFIX}-libthai")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-gobject-introspection"
             "${MINGW_PACKAGE_PREFIX}-gi-docgen"
             "${MINGW_PACKAGE_PREFIX}-python-docutils")
source=("https://download.gnome.org/sources/pango/${pkgver:0:4}/${_realname}-${pkgver}.tar.xz")
sha256sums=('342385b6ca3b7c73455d7c80a13b7dbe4489e00bc3bd4c5bd6ed4dce421e374a')

prepare() {
  cd "${_realname}-${pkgver}"
}

build() {
  local -a _static_flags=(
    -DGIO_STATIC_COMPILATION
    -DGLIB_STATIC_COMPILATION
    -DGMODULE_STATIC_COMPILATION
    -DGOBJECT_STATIC_COMPILATION
    -DCAIRO_WIN32_STATIC_BUILD
  )

  mkdir -p build-${MSYSTEM} && cd build-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    --prefix="${MINGW_PREFIX}" \
    --default-library shared \
    --buildtype plain \
    --auto-features=enabled \
    -Ddocumentation=true \
    -Dman-pages=true \
    -Dxft=disabled \
    --wrap-mode=nofallback \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/meson compile

  cd "${srcdir}"
  mkdir -p build-static-${MSYSTEM} && cd build-static-${MSYSTEM}

  CFLAGS+=" ${_static_flags[@]}" \
  CXXFLAGS+=" ${_static_flags[@]}" \
  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    --prefix="${MINGW_PREFIX}" \
    --default-library static \
    --buildtype plain \
    --auto-features=enabled \
    -Ddocumentation=false \
    -Dintrospection=disabled \
    --wrap-mode=nofallback \
    -Dxft=disabled \
    ../${_realname}-${pkgver}

  ${MINGW_PREFIX}/bin/meson compile
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"
  ${MINGW_PREFIX}/bin/meson test || warning "Tests failed"

  cd "${srcdir}/build-static-${MSYSTEM}"
  ${MINGW_PREFIX}/bin/meson test || warning "Tests failed"
}

package_pango() {
  meson install -C "${srcdir}/build-static-${MSYSTEM}" --destdir "${pkgdir}"
  meson install -C "${srcdir}/build-${MSYSTEM}" --destdir "${pkgdir}"

  # remove installed tests, no need and they contain the build path which
  # leads to pkgbuild warnings
  rm -Rf "${pkgdir}${MINGW_PREFIX}/share/installed-tests"
  rm -Rf "${pkgdir}${MINGW_PREFIX}/libexec"

  mkdir -p dest/${MINGW_PREFIX}/share
  mv "${pkgdir}${MINGW_PREFIX}"/share/doc "dest${MINGW_PREFIX}"/share/doc

  # License
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}

package_pango-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
