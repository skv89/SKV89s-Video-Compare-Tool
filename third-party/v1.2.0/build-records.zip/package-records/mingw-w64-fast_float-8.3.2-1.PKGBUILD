# Contributor: Mehdi Chinoune <mehdi.chinoune@hotmail.com>

_realname=fast_float
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=8.3.2
pkgrel=1
pkgdesc="Fast and exact implementation of the C++ from_chars functions for float and double types (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/fastfloat/fast_float'
msys2_repository_url='https://github.com/fastfloat/fast_float'
license=('spdx:Apache-2.0 OR BSL-1.0 OR MIT')
msys2_references=(
  'anitya: 214353'
  'archlinux: fast_float'
  'gentoo: dev-cpp/fast_float'
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
)
source=("${url}/archive/v${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('71bb9e865b888df01351558db5a39586d13ea97ada162156b3a07784d8c1b26b')

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}" \
      "${extra_config[@]}" \
      -S ${_realname}-${pkgver} \
      -B build-${MSYSTEM}

  cmake --build build-${MSYSTEM}
}

package() {
  DESTDIR="${pkgdir}" cmake --install build-${MSYSTEM}

  install -d "${pkgdir}${MINGW_PREFIX}"/share/licenses/${_realname}
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE* -t "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}"
}
