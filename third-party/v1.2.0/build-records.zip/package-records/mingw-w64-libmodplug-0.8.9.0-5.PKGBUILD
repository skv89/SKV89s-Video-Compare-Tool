# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=libmodplug
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=0.8.9.0
pkgrel=5
pkgdesc="A MOD playing library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://modplug-xmms.sourceforge.io/"
msys2_references=(
  "cpe: cpe:/a:konstanty_bialkowski:libmodplug"
)
license=("PublicDomain")
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools")
conflicts=("${MINGW_PACKAGE_PREFIX}-libopenmpt-modplug")
source=("https://downloads.sourceforge.net/modplug-xmms/${_realname}-${pkgver}.tar.gz"
        '010-mingw.patch')
sha256sums=('457ca5a6c179656d66c01505c0d95fafaead4329b9dbaa0f997d00a3508ad9de'
            'bfb4f76dbe4abf618c3352baf4fc316d42f0237f7ffbaaa8b346abff0594c834')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  patch -Np1 -i "${srcdir}/010-mingw.patch"
  # autoreconf to get updated libtool files, for clang support
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  CXXFLAGS+=" -std=gnu++14" \
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --enable-shared \
    --enable-static

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  # Install license
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
}
