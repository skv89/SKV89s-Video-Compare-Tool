# Maintainer: Miloš Komarčević <miloskomarcevic@aim.com>

_realname=SVT-AV1
pkgbase=mingw-w64-svt-av1
pkgname=("${MINGW_PACKAGE_PREFIX}-svt-av1")
pkgver=4.2.0
pkgrel=1
pkgdesc="Scalable Video Technology AV1 encoder (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://gitlab.com/AOMediaCodec/SVT-AV1'
msys2_repository_url='https://gitlab.com/AOMediaCodec/SVT-AV1'
license=('spdx:BSD-3-Clause-Clear')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-cmake"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-nasm"
)
source=("${url}/-/archive/v${pkgver}/${_realname}-v${pkgver}.tar.gz")
sha256sums=('c7b13c4a84bd3751aa35fcc72be13e6875467e7c2216879251a486e5b1e4e740')

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=OFF \
      -DREPRODUCIBLE_BUILDS=ON \
      -DSVT_AV1_LTO=OFF \
      -S "${_realname}-v${pkgver}" \
      -B "build-${MSYSTEM}-static"

  cmake --build "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
    cmake \
      -GNinja \
      -DCMAKE_INSTALL_PREFIX=${MINGW_PREFIX} \
      "${extra_config[@]}" \
      -DBUILD_SHARED_LIBS=ON \
      -DCMAKE_DLL_NAME_WITH_SOVERSION=ON \
      -DREPRODUCIBLE_BUILDS=ON \
      -DSVT_AV1_LTO=OFF \
      -S "${_realname}-v${pkgver}" \
      -B "build-${MSYSTEM}-shared"

  cmake --build "build-${MSYSTEM}-shared"
}

package() {
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-static"

  # pkg-config file adds -DEB_DLL in cflags for shared libs only
  DESTDIR="${pkgdir}" cmake --install "build-${MSYSTEM}-shared"

  install -Dm644 "${srcdir}"/${_realname}-v${pkgver}/LICENSE.md "${pkgdir}"${MINGW_PREFIX}/share/licenses/svt-av1/LICENSE
  install -Dm644 "${srcdir}"/${_realname}-v${pkgver}/PATENTS.md "${pkgdir}"${MINGW_PREFIX}/share/licenses/svt-av1/PATENTS.md
}
