# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Miloš Komarčević <miloskomarcevic@aim.com>

_realname=lcms2
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=2.19.1
pkgrel=1
pkgdesc="Small-footprint color management engine, version 2 (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.littlecms.com/color-engine/"
msys2_repository_url="https://github.com/mm2/Little-CMS/"
msys2_references=(
  'anitya: 9815'
  'gentoo: media-libs/lcms'
  "cpe: cpe:/a:littlecms:lcms"
  "cpe: cpe:/a:littlecms:little_cms"
  "cpe: cpe:/a:littlecms:little_cms_color_engine"
)
license=('spdx:MIT AND GPL-3.0-or-later')
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-meson"
  "${MINGW_PACKAGE_PREFIX}-ninja"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
)
depends=(
  "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
  "${MINGW_PACKAGE_PREFIX}-libtiff"
)
source=("https://github.com/mm2/Little-CMS/releases/download/lcms${pkgver}/${_realname}-${pkgver}.tar.gz")
sha256sums=('bfc54f7bab59fbc921012014a8032e4cba4abd46db47d46b76416a8c0b2815c8')

build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      -Ddefault_library=both \
      -Dutils=true \
      -Dfastfloat=true \
      ../${_realname}-${pkgver}

  meson compile
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}

  DESTDIR="${pkgdir}" meson install

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENSE "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/plugins/fast_float/COPYING.GPL3 "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE-fast_float
}
