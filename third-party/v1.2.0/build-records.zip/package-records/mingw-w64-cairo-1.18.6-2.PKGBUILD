# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=cairo
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
_commit='b43e7c6f3cf7855e16170a06d3a9c7234c60ca94'
pkgver=1.18.6
pkgrel=2
pkgdesc="Cairo vector graphics library (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://cairographics.org/"
msys2_references=(
  "cpe: cpe:2.3:a:cairographics:cairo"
)
license=('spdx:LGPL-2.1-or-later OR MPL-1.1')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-meson"
             "${MINGW_PACKAGE_PREFIX}-ninja"
             "${MINGW_PACKAGE_PREFIX}-pkgconf"
             "${MINGW_PACKAGE_PREFIX}-python"
             "${MINGW_PACKAGE_PREFIX}-python-fonttools"
             "${MINGW_PACKAGE_PREFIX}-gettext-tools"
            )
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-freetype"
         "${MINGW_PACKAGE_PREFIX}-fontconfig"
         "${MINGW_PACKAGE_PREFIX}-gettext-runtime"
         "${MINGW_PACKAGE_PREFIX}-glib2"
         "${MINGW_PACKAGE_PREFIX}-libpng"
         "${MINGW_PACKAGE_PREFIX}-lzo2"
         "${MINGW_PACKAGE_PREFIX}-pixman"
         "${MINGW_PACKAGE_PREFIX}-zlib")
source=("https://cairographics.org/releases/cairo-${pkgver}.tar.xz"
        0001-DWrite-Get-glyph-bitmap-with-D2D-in-selected-cases.patch
        https://gitlab.freedesktop.org/cairo/cairo/-/merge_requests/673.patch)
sha256sums=('1c767308174337a74694da0f3ec069c271452163a1ef4540964c50c301f157d4'
            'ccac43886a0fc1403f04d34bbc977ae3b0bc6086475806a835638d4a55b01b44'
            '98ca730258da7a13f1e7577bc43438f1f7cf0c9ca0fd3bb8231e8c018aa90da7')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  patch -p1 -i "${srcdir}"/0001-DWrite-Get-glyph-bitmap-with-D2D-in-selected-cases.patch
  # https://github.com/msys2/MINGW-packages/issues/31852
  patch -p1 -i "${srcdir}"/673.patch
}

build() {
  local -a _static_flags=(
    -DGIO_STATIC_COMPILATION
    -DGLIB_STATIC_COMPILATION
    -DGMODULE_STATIC_COMPILATION
    -DGOBJECT_STATIC_COMPILATION
  )

  local -a _meson_options
  _meson_options=(
    --prefix=${MINGW_PREFIX}
    --buildtype=plain
    --wrap-mode=nofallback
    -Dauto_features=enabled
    -Dtests=disabled
    -Ddwrite=enabled
    -Dfontconfig=enabled
    -Dfreetype=enabled
    -Dpng=enabled
    -Dtee=enabled
    -Dzlib=enabled
    -Dxlib=disabled
    -Dxcb=disabled
    -Dspectre=disabled
    -Dsymbol-lookup=disabled
  )

  # work around gcc errors
  if [[ "${CC}" == "gcc" ]]; then
    CFLAGS+=" -Wno-error=incompatible-pointer-types"
    CXXFLAGS+=" -Wno-error=incompatible-pointer-types"
  fi

  # Enables CAIRO_WIN32_STATIC_BUILD, keeps DllMain far away (#17643)
  CFLAGS+=" ${_static_flags[@]}" \
  CXXFLAGS+=" ${_static_flags[@]}" \
  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    "${_meson_options[@]}" \
    --default-library=static \
    "${_realname}-${pkgver}" \
    "build-${MSYSTEM}-static"

  meson compile -C "build-${MSYSTEM}-static"

  MSYS2_ARG_CONV_EXCL="--prefix=" \
  ${MINGW_PREFIX}/bin/meson setup \
    "${_meson_options[@]}" \
    --default-library=shared \
    "${_realname}-${pkgver}" \
    "build-${MSYSTEM}-shared"

  meson compile -C "build-${MSYSTEM}-shared"
}

package() {
  meson install -C "build-${MSYSTEM}-static" --destdir "${pkgdir}"
  meson install -C "build-${MSYSTEM}-shared" --destdir "${pkgdir}"

  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING-LGPL-2.1" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING-LGPL-2.1"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING-MPL-1.1" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING-MPL-1.1"
}
