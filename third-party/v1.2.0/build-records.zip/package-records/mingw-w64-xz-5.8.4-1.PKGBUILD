# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=xz
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=5.8.4
pkgrel=1
pkgdesc="Library and command line tools for XZ and LZMA compressed files (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://tukaani.org/xz"
msys2_repository_url="https://github.com/tukaani-project/xz/"
msys2_references=(
  'archlinux: xz'
  "cpe: cpe:/a:tukaani:xz"
)
# TODO: check situation with getopt_long mentioned in COPYING for possible
# removal of LGPL from this field
license=('spdx:0BSD AND LGPL-2.1-or-later AND GPL-2.0-or-later')
depends=("${MINGW_PACKAGE_PREFIX}-gettext-runtime")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-gettext-tools"
             $([[ ${CARCH} == i686 ]] || echo "${MINGW_PACKAGE_PREFIX}-doxygen")
             "po4a")
source=("https://github.com/tukaani-project/xz/releases/download/v${pkgver}/xz-${pkgver}.tar.xz"{,.sig})
sha256sums=('4ce24038fd4221e0d13bc1a2de7a4db56e90b92b3bf75321f6c14be73f65de4b'
            'SKIP')
validpgpkeys=('3690C240CE51B4670D30AD1C38EE757D69184620') # Lasse Collin <lasse.collin@tukaani.org>

prepare() {
  cd "${_realname}-${pkgver}"

  ./autogen.sh
}


build() {
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  declare -a _extra_config
  if [[ ${CARCH} == i686 ]]; then
    _extra_config+=("--disable-doxygen")
  else
    _extra_config+=("--enable-doxygen")
  fi

  # see https://github.com/tukaani-project/xz/releases/tag/v5.6.4
  # pass --disable-nls for msvcrt builds
  if [[ ${MSYSTEM} == MINGW32 || ${MSYSTEM} == MINGW64 ]]; then
    _extra_config+=("--disable-nls")
  fi

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --disable-rpath \
    --disable-lzma-links \
    "${_extra_config[@]}"

  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  make DESTDIR="${pkgdir}" install

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/COPYING* \
    -t "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}
}
