# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=gsm
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.0.24
pkgrel=1
pkgdesc="Shared libraries for GSM 06.10 lossy speech compression (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.quut.com/gsm/"
license=("custom")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-pkgconf")
source=("http://www.quut.com/${_realname}/${_realname}-${pkgver}.tar.gz"
        0001-adapt-makefile-to.mingw.patch
        0002-adapt-config-h-to.mingw.patch
        0003-fix-ln.mingw.patch
        0004-use-cc-instead-of-gcc.patch)
sha256sums=('a3c40c6471928383f4abfcb2e8f24012a1f562be2f17b8d672145d5986681a92'
            '654eaac22889157982d216776bf9de9b33a24e0bea4f8f56b7659cb80627dff3'
            '4baaaf5218f384c7ee204da0617d6f95d3e2fc684faf5a80b892f29930939d07'
            '29973fa21c19f68aa4fecc9cb9d622f5d459eb193907c434eed1e05caa4c2321'
            '07a85325c41e9e4e83f1730ccf1d5c1a0a7b4effcda913a0619d2f984aaa8eab')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver%.*}-pl${pkgver##*.}"
  patch -p1 -i "${srcdir}"/0001-adapt-makefile-to.mingw.patch
  patch -p1 -i "${srcdir}"/0002-adapt-config-h-to.mingw.patch
  patch -p1 -i "${srcdir}"/0003-fix-ln.mingw.patch
  patch -p1 -i "${srcdir}"/0004-use-cc-instead-of-gcc.patch
}

build() {
  cp -r "${srcdir}"/${_realname}-${pkgver%.*}-pl${pkgver##*.} "${srcdir}"/build-${MSYSTEM}
  cd "${srcdir}/build-${MSYSTEM}"
  make
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  # Prepare directories
  install -m755 -d "${pkgdir}${MINGW_PREFIX}"/{bin,lib,include,share/{licenses/${_realname},man/man{1,3}}}

  make -j1 INSTALL_ROOT="${pkgdir}${MINGW_PREFIX}" install

  # Install license
  install -m644 COPYRIGHT "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/license.txt
}
