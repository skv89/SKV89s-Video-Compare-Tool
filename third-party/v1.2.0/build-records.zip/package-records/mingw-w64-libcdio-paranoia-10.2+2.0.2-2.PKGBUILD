# $Id: PKGBUILD 174870 2013-01-08 10:06:34Z jgc $
# Maintainer: Zach Bacon <11doctorwhocanada@gmail.com>
# Contributor: damir <damir@archlinux.org>

_realname=libcdio-paranoia
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=10.2+2.0.2
pkgrel=2
pkgdesc="CD paranoia libraries from libcdio (mingw-w64)"
arch=('any')
mingw_arch=('mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:GPL-2.0-or-later')
url="https://www.gnu.org/software/libcdio/"
msys2_repository_url='https://github.com/libcdio/libcdio-paranoia'
msys2_references=(
  "cpe: cpe:2.3:a:gnu:libcdio"
)
depends=("${MINGW_PACKAGE_PREFIX}-libcdio")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc" "${MINGW_PACKAGE_PREFIX}-autotools")
source=(https://ftp.gnu.org/gnu/libcdio/${_realname}-${pkgver}.tar.bz2{,.sig})
sha256sums=('186892539dedd661276014d71318c8c8f97ecb1250a86625256abd4defbf0d0c'
            'SKIP')
validpgpkeys=('DAA63BC2582034A02B923D521A8DE5008275EC21')

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"
  # autoreconf to get updated libtool files with clang support
  autoreconf -fiv
}

build() {
  mkdir -p "${srcdir}"/build-${MSYSTEM} && cd "${srcdir}"/build-${MSYSTEM}

  CFLAGS+=" -std=gnu17"

  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --build=${MINGW_CHOST} \
    --host=${MINGW_CHOST} \
    --target=${MINGW_CHOST} \
    --enable-cpp-progs \
    --enable-shared \
    --enable-static \
    --disable-example-progs \
    $( [[ ${MINGW_PACKAGE_PREFIX} == *-clang-* ]] && \
      echo "--disable-ld-version-script" || true)

  make
}

package() {
  cd "${srcdir}"/build-${MSYSTEM}
  make -j1 DESTDIR="${pkgdir}" install
}
