# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=opus
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         $([[ ${MSYSTEM} == MINGW* ]] || echo "${MINGW_PACKAGE_PREFIX}-${_realname}-docs"))
pkgver=1.6.1
pkgrel=2
pkgdesc="Codec designed for interactive speech and audio transmission over the Internet (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.opus-codec.org/"
msys2_repository_url="https://github.com/xiph/opus"
msys2_references=(
  "cpe: cpe:2.3:a:opus-codec:opus"
)
license=('spdx:BSD-3-Clause')
makedepends=(
    "${MINGW_PACKAGE_PREFIX}-cc"
    $([[ ${MSYSTEM} == MINGW* ]] || echo "${MINGW_PACKAGE_PREFIX}-doxygen")
    "${MINGW_PACKAGE_PREFIX}-meson"
    "${MINGW_PACKAGE_PREFIX}-ninja"
)
source=("https://downloads.xiph.org/releases/opus/opus-${pkgver}.tar.gz"
        001-aarch64-features.patch)
sha256sums=('6ffcb593207be92584df15b32466ed64bbec99109f007c82205f0194572411a1'
            '5fb0f28264492d6512acb6eec7b5e147c922751f6df30d1317114048eca01516')

apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  apply_patch_with_msg \
    001-aarch64-features.patch
}

build() {
  declare -a extra_config
  if [[ ${MSYSTEM} != MINGW* ]]; then
    extra_config+=("-Ddocs=enabled")
  else
    extra_config+=("-Ddocs=disabled")
  fi

  mkdir -p build-${MSYSTEM} && cd build-${MSYSTEM}

  MSYS2_ARG_CONV_EXCL="--prefix=" \
    meson setup \
      --prefix="${MINGW_PREFIX}" \
      --wrap-mode=nodownload \
      --auto-features=enabled \
      --buildtype=plain \
      --default-library=both \
      -Dasm=disabled \
      -Dcustom-modes=true \
      -Dtests=disabled \
      "${extra_config[@]}" \
      ../${_realname}-${pkgver}

  meson compile
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"
  meson setup -Dtests=enabled ../${_realname}-${pkgver}
  meson compile

  meson test
}

package_opus() {
  meson install -C "${srcdir}/build-${MSYSTEM}" --destdir "${pkgdir}"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/opus.m4" "${pkgdir}${MINGW_PREFIX}/share/aclocal/opus.m4"

  if [[ ${MSYSTEM} != MINGW* ]]; then
    mkdir -p dest${MINGW_PREFIX}/share
    mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share/doc
  fi

  install -Dm644 "${srcdir}/${_realname}-${pkgver}"/COPYING "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
}

package_opus-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
