# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=rtmpdump
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=2.6
pkgrel=2
pkgdesc="A tool to download rtmp streams (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://rtmpdump.mplayerhq.hu/"
msys2_repository_url="https://git.ffmpeg.org/rtmpdump"
msys2_references=(
  "cpe: cpe:/a:rtmpdump_project:rtmpdump"
)
license=('spdx:GPL-2.0-or-later' 'spdx:LGPL-2.1-or-later')
provides=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
conflicts=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
replaces=("${MINGW_PACKAGE_PREFIX}-${_realname}-git")
depends=(
  "${MINGW_PACKAGE_PREFIX}-cc-libs"
  "${MINGW_PACKAGE_PREFIX}-gmp"
  "${MINGW_PACKAGE_PREFIX}-gnutls"
  "${MINGW_PACKAGE_PREFIX}-nettle"
  "${MINGW_PACKAGE_PREFIX}-zlib"
)
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-pkgconf"
  'git'
)
source=("$_realname::git+${msys2_repository_url}#tag=v${pkgver}"
        '0001-mingw.mingw.patch'
        '0002-no-fPIC.mingw.patch'
        '0003-better-w32-threading.all.patch'
        '0004-gnu_printf.all.patch'
        '0005-fix-unused-var-warning.all.patch'
        '0006-deprecated-gnutls-type.all.patch'
        '0007-cast-appropriately-for-nettle.all.patch'
        '0009-correct-cast.all.patch'
        '0012-no-sbin.patch'
        '0013-no-extra-dll.patch'
        '0014-nettle-4.patch')
sha256sums=('0cba5d49d41b5e35a34ea8230124ed853eeeac19091d17a4188a47c31a17d352'
            'cfd82cad49aa6e84f5316befce5d223d1861b6997bfbf7d655503b71878f5423'
            '7c6f0360249996fa6b994bef025b742cdf7748a255f19d8cc46c50bbe4ff99c9'
            '0a2f24ded2c025d324189a8246162f8f906afd0c1650ed31b6e748874ea31ea1'
            'eb6af4f8a570ff8274c0c412901e719cd0ef14badcc88358d7c36cb3ff29df17'
            '4afc6626fa29398a086a9385f251db9c2e5a885cf08b43c7aa88c16a91d72278'
            '717b514c7686a39262edbb84791145cb805261f02a76b71f558db4ca4d9d3c24'
            'c12973df7e9f01020f31acef6778884b02a6d6bdd6310d2d5396b4dcefdbf907'
            'c3ac95d2b39fed97587f0cf379abea50d43708ab5bd5e49f43d618ae383fa108'
            '4ba58ee78346e5e472671006adb91e581177c706b01d71f8e6cbd3aa4e776e2b'
            'a663ed0927d9e1b0487f4a61cf0d5833344dde80741e95b102f8e78495768c89'
            'd91be37b35368db605b25cdc51f3f0c467e3bf6ea68348f7f780e70fb821f361')

apply_patch_with_msg() {
  for _fname in "$@"
  do
    msg2 "Applying ${_fname}"
    patch -Nbp1 -i "${srcdir}"/${_fname}
  done
}

prepare() {
  cd "${srcdir}/${_realname}"

  apply_patch_with_msg \
    0001-mingw.mingw.patch \
    0002-no-fPIC.mingw.patch \
    0003-better-w32-threading.all.patch \
    0004-gnu_printf.all.patch \
    0005-fix-unused-var-warning.all.patch \
    0006-deprecated-gnutls-type.all.patch \
    0007-cast-appropriately-for-nettle.all.patch \
    0009-correct-cast.all.patch \
    0012-no-sbin.patch \
    0013-no-extra-dll.patch \
    0014-nettle-4.patch
}

build() {
  cp -r "${srcdir}/${_realname}" "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  make CC=${CC} LD=ld AR=ar SYS=mingw
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"
  mkdir -p "${pkgdir}"${MINGW_PREFIX}/lib
  make CC=${CC} LD=ld AR=ar SYS=mingw prefix=${MINGW_PREFIX} mandir=${MINGW_PREFIX}/share/man DESTDIR="${pkgdir}" install
}
