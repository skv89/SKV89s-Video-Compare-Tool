# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=gettext
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}-runtime"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-libtextstyle"
         "${MINGW_PACKAGE_PREFIX}-${_realname}-tools")
pkgver=1.0
pkgrel=1
pkgdesc="GNU internationalization library (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://www.gnu.org/software/gettext/"
msys2_repository_url="https://git.savannah.gnu.org/gitweb/?p=gettext.git"
msys2_references=(
  "cpe: cpe:/a:gnu:gettext"
)
# GPL3 for the package as a whole and LGPL for some parts, see the license files
license=('spdx:GPL-3.0-or-later AND LGPL-2.1-or-later')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-ncurses"
             "${MINGW_PACKAGE_PREFIX}-libiconv"
             "groff")
source=(https://ftp.gnu.org/pub/gnu/${_realname}/${_realname}-${pkgver}.tar.lz{,.sig}
        0005-Fix-compilation-of-pthread_sigmask.c.patch
        122-Use-LF-as-newline-in-envsubst.patch
        0021-replace-fsync.patch
        0022-libasprintf.patch
        0024-disable-gnu-format.patch
        0030-fix-build-with-mingw-w64-clang.patch)
sha256sums=('d6342cbe1411a2fe7d139bfed80c2d63b1babc92acfedc72501cc105184f61ee'
            'SKIP'
            'cbc2f533012d646521afa20f8b256917fce040741ff42cf53fb6dd7123a6670a'
            'ec39103d851262c02c27b7038f3c538e03afaefc6aa050311d62519d192ff38c'
            '380dbddee2f9e2feee4c1435e8a942b5d11d0125e60c3350ebb10c19b19011aa'
            'c354f6a7021069c99b90f1c6d6f6a4ccf40a01e9f6742b866df2b5a7286cb868'
            'ce7ccf6dd3a492cab322253cd67310899b546eccc25821c25cbc047a1a984633'
            '9b1b4f0c65b3bc1a3103c921a02c203cecf533d145f0bd90023406e760f81749')
validpgpkeys=('462225C3B46F34879FC8496CD605848ED7E69871'  # Daiki Ueno
              '9001B85AF9E1B83DF1BDA942F5BE8B267C6A406D'  # Bruno Haible
              'E0FFBD975397F77A32AB76ECB6301D9E1BBEAC08') # Bruno Haible (FSF) <bruno@clisp.org>

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}/${_realname}-${pkgver}"

  apply_patch_with_msg \
    0005-Fix-compilation-of-pthread_sigmask.c.patch \
    122-Use-LF-as-newline-in-envsubst.patch

  apply_patch_with_msg \
    0021-replace-fsync.patch \
    0022-libasprintf.patch

  # https://github.com/msys2/MINGW-packages/pull/19047#issuecomment-1960769618
  # https://git.savannah.gnu.org/gitweb/?p=gettext.git;a=commitdiff;h=eef429bbccbff2bca08bafc2ff76f7ec2be93d2a
  apply_patch_with_msg \
    0024-disable-gnu-format.patch

  apply_patch_with_msg \
    0030-fix-build-with-mingw-w64-clang.patch

  libtoolize --automake --copy --force
  WANT_AUTOMAKE=latest ./autogen.sh --skip-gnulib
}

_build() {
  _config_opt=$1

  # gl_cv_func_mkdir_trailing_dot_works=yes was added to avoid having two
  # incompatible declarations of mkdir in the same compilation unit.
  ../${_realname}-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --libexecdir=${MINGW_PREFIX}/lib \
    --disable-java \
    --disable-native-java \
    --disable-csharp \
    ${_config_opt} \
    --enable-threads=win32 \
    --enable-relocatable \
    --without-emacs \
    --disable-openmp \
    --without-cvs \
    --without-git \
    --with-included-libcroco \
    --with-included-libunistring \
    --with-included-libxml \
    --with-included-glib \
    --with-libncurses-prefix=${MINGW_PREFIX} \
    --disable-silent-rules \
    lt_cv_deplibs_check_method='pass_all' \
    gl_cv_func_mkdir_trailing_dot_works=yes

  # to make relocate() in gnulib-lib work
  sed -s "s|${MINGW_PREFIX}|$(cygpath -m ${MINGW_PREFIX})|g" -i gettext-tools/config.h

  make
}

build() {
  export MSYS2_ARG_CONV_EXCL="-DLOCALEDIR=;-DLIBDIR=;-DLOCALE_ALIAS_PATH="

  msg2 "Build static libraries"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-static && cd "${srcdir}"/build-${MSYSTEM}-static
  _build "--enable-static --disable-shared"

  msg2 "Build shared libraries"
  mkdir -p "${srcdir}"/build-${MSYSTEM}-shared && cd "${srcdir}"/build-${MSYSTEM}-shared
  _build "--enable-shared --disable-static"
}

check () {
  cd "${srcdir}"/build-${MSYSTEM}-static

  # ensure that the Windows-specific `%I64*` format family is recognized correctly
  cat >test-I64d.c <<EOF
#include <stdio.h>
#include <stdint.h>
#include <libintl.h>

int main(int argc, char **argv)
{
	char buf[1024] = "(failure)";
	int len = libintl_snprintf(buf, 1024, "hello %llu %I64u 0:%d\n", (uint64_t)123, (uint64_t)123, 0);

	printf("%d, '%s'\n", len, buf);

	return len < 0 ? 1 : 0;
}
EOF
  gcc -Wall -g -o test-I64d.exe test-I64d.c ./gettext-runtime/intl/.libs/libintl.a || return 1
  ./test-I64d.exe || return 1
}

package_gettext-runtime() {
  pkgdesc="GNU internationalization runtime library (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-cc-libs"
    "${MINGW_PACKAGE_PREFIX}-libiconv"
  )
  conflicts=("${MINGW_PACKAGE_PREFIX}-gettext<=0.22.4-3")

  cd "${srcdir}"/build-${MSYSTEM}-static/gettext-runtime
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}"/build-${MSYSTEM}-shared/gettext-runtime
  make DESTDIR="${pkgdir}" install

  # Licenses
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-runtime/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-runtime/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-runtime/intl/COPYING.LIB" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-runtime/intl/COPYING.LIB"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-runtime/libasprintf/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-runtime/libasprintf/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-runtime/libasprintf/COPYING.LIB" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-runtime/libasprintf/COPYING.LIB"
}

package_gettext-libtextstyle() {
  pkgdesc="GNU LIBTEXTSTYLE - Text styling library (mingw-w64)"
  depends=("${MINGW_PACKAGE_PREFIX}-libiconv")
  license=("spdx:GPL-3.0-or-later")

  cd "${srcdir}"/build-${MSYSTEM}-static/libtextstyle
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}"/build-${MSYSTEM}-shared/libtextstyle
  make DESTDIR="${pkgdir}" install

  # License
  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/libtextstyle/COPYING \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/gettext-libtextstyle/COPYING
}

package_gettext-tools() {
  pkgdesc="GNU internationalization tools (mingw-w64)"
  depends=(
    "${MINGW_PACKAGE_PREFIX}-gettext-runtime"
    "${MINGW_PACKAGE_PREFIX}-gettext-libtextstyle"
    "${MINGW_PACKAGE_PREFIX}-cc-libs"
    "${MINGW_PACKAGE_PREFIX}-libiconv"
  )
  provides=("${MINGW_PACKAGE_PREFIX}-gettext=${pkgver}-${pkgrel}")
  conflicts=("${MINGW_PACKAGE_PREFIX}-gettext<=0.22.4-3")
  replaces=("${MINGW_PACKAGE_PREFIX}-gettext")
  license=("spdx:GPL-3.0-or-later")

  cd "${srcdir}"/build-${MSYSTEM}-static/gettext-tools
  make DESTDIR="${pkgdir}" install

  cd "${srcdir}"/build-${MSYSTEM}-shared/gettext-tools
  make DESTDIR="${pkgdir}" install

  # Licenses
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-tools/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-tools/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gettext-tools/gnulib-lib/libxml/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/gettext-tools/gnulib-lib/libxml/COPYING"

  # Not sure where to put them, so put them in the gettext-tools package
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/COPYING"
  install -Dm644 "${srcdir}/${_realname}-${pkgver}/gnulib-local/lib/libxml/COPYING" \
    "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/gnulib-local/lib/libxml/COPYING"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
