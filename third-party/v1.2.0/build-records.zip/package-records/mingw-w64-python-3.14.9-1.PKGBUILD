# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Maintainer: Ray Donnelly <mingw.android@gmail.com>
# Maintainer: Naveen M K <naveen521kk@gmail.com>
# Contributor: Saul Ibarra Corretge <saghul@gmail.com>
# Contributor: Frode Solheim <frode@fs-uae.net>

_primary_python="yes"
_pybasever=3.14
_realname=python

if [[ "${_primary_python}" == "yes" ]]; then
  pkgbase="mingw-w64-${_realname}"
  pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
  provides=("${MINGW_PACKAGE_PREFIX}-python3"
            "${MINGW_PACKAGE_PREFIX}-python${_pybasever}")
  conflicts=("${MINGW_PACKAGE_PREFIX}-python3"
             "${MINGW_PACKAGE_PREFIX}-python${_pybasever}"
            "${MINGW_PACKAGE_PREFIX}-python2<2.7.16-7")
  replaces=("${MINGW_PACKAGE_PREFIX}-python3"
            "${MINGW_PACKAGE_PREFIX}-python${_pybasever}")
else
  pkgbase="mingw-w64-${_realname}${_pybasever}"
  pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}${_pybasever}")
fi
pkgver=${_pybasever}.9
pkgrel=1
pkgdesc="A high-level scripting language (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
license=('spdx:PSF-2.0')
url="https://www.python.org/"
msys2_repository_url="https://github.com/python/cpython"
msys2_references=(
  "cpe: cpe:/a:python:python"
  "cpe: cpe:/a:python_software_foundation:python"
)
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-expat"
         "${MINGW_PACKAGE_PREFIX}-bzip2"
         "${MINGW_PACKAGE_PREFIX}-libffi"
         "${MINGW_PACKAGE_PREFIX}-mpdecimal"
         "${MINGW_PACKAGE_PREFIX}-ncurses"
         "${MINGW_PACKAGE_PREFIX}-openssl"
         "${MINGW_PACKAGE_PREFIX}-sqlite3"
         "${MINGW_PACKAGE_PREFIX}-tcl"
         "${MINGW_PACKAGE_PREFIX}-tk"
         "${MINGW_PACKAGE_PREFIX}-zlib"
         "${MINGW_PACKAGE_PREFIX}-libb2"
         "${MINGW_PACKAGE_PREFIX}-xz"
         "${MINGW_PACKAGE_PREFIX}-tzdata")
makedepends=(
  "${MINGW_PACKAGE_PREFIX}-cc"
  "${MINGW_PACKAGE_PREFIX}-autotools"
  "autoconf-archive"
)
#options=('debug' '!strip')
source=("https://www.python.org/ftp/python/${pkgver%rc?}/Python-${pkgver}.tar.xz"
        "EXTERNALLY-MANAGED"
        0001-build-add-with-nt-threads-and-make-it-default-on-min.patch
        0002-build-Define-MS_WINDOWS-and-others-when-compiling-wi.patch
        0003-sysmodule-Implement-flags-_is_mingw-is_mingw_ucrt-an.patch
        0004-configure-add-MACHDEP-and-platform-on-MINGW.patch
        0005-build-Add-default-cross-configuration-for-MINGW.patch
        0006-configure-enable-largefile-support-by-default-for-Mi.patch
        0007-build-Add-PC-to-CPPFLAGS-and-to-SRCDIRS-on-Mingw.patch
        0008-build-add-MINGW-support-for-posixmodule.patch
        0009-exports.h-Add-support-for-MINGW.patch
        0010-configure-add-options-so-that-shared-build-is-possib.patch
        0011-build-Add-PYD_PLATFORM_TAG.patch
        0012-build-Add-dynload_win-support-for-MinGW.patch
        0013-build-Use-.pyd-extension-suffix-fix-import-lib-insta.patch
        0014-build-Configure-SOABI-and-EXT_SUFFIX-for-MINGW.patch
        0015-build-Define-MS_DLL_ID-for-sys.winver-on-MINGW.patch
        0016-build-Ignore-main-program-for-frozen-scripts-on-MING.patch
        0017-socketmodule-add-MINGW-support.patch
        0018-build-enable-winreg-msvcrt-_winapi-winsound-and-_ove.patch
        0019-sysconfig-make-_sysconfigdata.py-relocatable.patch
        0020-sysconfig-treat-MINGW-builds-as-POSIX-builds.patch
        0021-sysconfig-Change-the-get_platform-method-in-sysconfi.patch
        0022-build-semi-native-build-sysconfig.patch
        0023-ctypes-Add-support-for-stdcall-without-underscore.patch
        0024-ctypes-add-suppor-for-ctypes.pythonapi-under-MINGW.patch
        0025-ctypes-find_library-c-should-return-None-with-ucrt.patch
        0026-site-Customize-for-MINGW.patch
        0027-site-Change-user-site-packages-path-to-include-the-e.patch
        0028-python-config-output-Windows-paths-for-the-shell-var.patch
        0029-python-config-use-the-Python-variant-of-python-confi.patch
        0030-mingw-prefer-unix-sep-if-MSYSTEM-environment-variabl.patch
        0031-build-Remove-MAXPATHLEN-default.patch
        0032-build-dont-link-with-gettext.patch
        0033-use-gnu_printf-in-format.patch
        0034-build-remove-usage-of-MS_COREDLL.patch
        0035-getcompiler-expose-MINGW-toolchain-related-informati.patch
        0036-build-fix-signal-module-build.patch
        0037-build-build-winconsoleio-and-_testconsole.patch
        0038-multiprocessing-expose-sem_unlink-to-fix-multiproces.patch
        0039-build-link-win-resource-files-and-build-pythonw.patch
        0040-pycore_fileutils-add-MINGW-support.patch
        0041-configure-fix-inet_pton-check.patch
        0042-importlib-bootstrap-path-sep.patch
        0043-configure-set-MINGW-stack-reserve.patch
        0044-tests-fix-test_bytes.patch
        0045-timemodule-add-MINGW-support.patch
        0046-configure-Disable-checks-for-dlopen-dlfcn.patch
        0047-venvlauncher-Build-venvlauncher.exe-from-PC-launcher.patch
        0048-venvlauncher-try-looking-for-the-versioned-.exe-firs.patch
        0049-venvlauncher-Skip-find-python-in-Registry-for-mingw-.patch
        0050-configure-don-t-check-for-clock_-functions.patch
        0051-CI-test-the-build-and-add-some-mingw-specific-tests.patch
        0052-configure-Default-to-without-c-locale-coercion-on-Wi.patch
        0053-tests-Fix-some-failing-tests.patch
        0054-build-def-VPATH-when-compiling-Python-sysmodule.c.patch
        0055-configure-correctly-find-native-python.patch
        0056-build-Add-extra-flags-for-_bootstrap_python.patch
        0057-getpath-add-support-for-mingw.patch
        0058-build-Don-t-build-_posixsubprocess-on-Windows.patch
        0059-ssl-module-add-MINGW-support.patch
        0060-configure-Include-winsock.h-when-checking-for-netdb-.patch
        0061-configure-always-build-_multiprocessing-on-Windows.patch
        0062-configure-build-mmap-module-on-win32.patch
        0063-configure-set-BUILDEXEEXT-and-EXEEXT.patch
        0064-configure-fix-building-some-test-modules.patch
        0065-Always-convert-to-before-passing-though-pathcch-func.patch
        0066-pylifecycle.h-remove-conflicting-_Py_CheckPython3-de.patch
        0067-dynload_win-add-env-var-for-reverting-the-legacy-DLL.patch
        0068-dynload_win-Port-GetPythonImport-to-MINGW.patch
        0069-dynload_win-make-sure-to-only-use-backslashes-for-pa.patch
        0070-dynload_win-don-t-run-_Py_CheckPython3-for-MINGW-bui.patch
        0071-build-Build-and-install-libpython3.dll-stable-ABI.patch
        0072-configure-define-_DEBUG-for-a-debug-build.patch
        0073-configure-fix-multiprocessing-module.patch
        0074-build-add-MINGW-support-for-selectmodule.patch
        0075-configure-disable-various-modules-on-MINGW.patch
        0076-configure-Add-libraries-to-fix-ctypes-on-MINGW.patch
        0077-configure-Enable-_uuid-on-MINGW.patch
        0078-configure-make-incompatible-pointer-types-a-warning.patch
        0079-tests-test_makefile-normalize-path.patch
        0080-Fix-include-naming-for-cross-build.patch
        0081-Fix-format-warning.patch
        0082-Fix-pragma-warnings.patch
        0083-math-pyhash-MINGW-support.patch
        0084-tests-Fix-test-for-library-name.patch
        0085-dictobject-MINGW-support.patch
        0086-build-Fix-export-Py_GetBuildInfo-symbol.patch
        0087-build-Allow-profile-tests-failure.patch
        0088-build-add-support-for-building-C-modules.patch
        0089-build-build-fix-the-wmi-module.patch
        0090-Fix-exports-for-_suggestions-module.patch
        0091-compileall-Normalize-paths.patch
        0092-configure-enable-64-bit-time-support-for-32-bit-buil.patch
        0093-venv-also-install-the-versioned-launchers.patch
        0094-configure-set-_WIN32_WINNT-version.patch
        0095-tests-fix-sysconfig.test_get_platform.patch
        0096-pycore_time-fix-missing-timeval.patch
        0097-mmapmodule-define-DONT_USE_SEH.patch
        0098-build-Add-ABIFLAGS-to-targets-when-needed.patch
        0099-sysconfig-patch-nt-schemes-again.patch
        0100-configure-define-_PYTHREAD_NAME_MAXLEN-for-MINGW.patch
        0101-configure-allow-older-autoconf.patch
        0102-tests-allow-sys.abiflags-to-exist.patch
        0103-makesetup-make-sure-to-link-the-built-libpython.patch)

# Helper macros to help make tasks easier #
apply_patch_with_msg() {
  for _patch in "$@"
  do
    msg2 "Applying ${_patch}"
    patch -Nbp1 -i "${srcdir}/${_patch}"
  done
}

prepare() {
  cd "${srcdir}/Python-${pkgver}"

 apply_patch_with_msg 0001-build-add-with-nt-threads-and-make-it-default-on-min.patch \
  0002-build-Define-MS_WINDOWS-and-others-when-compiling-wi.patch \
  0003-sysmodule-Implement-flags-_is_mingw-is_mingw_ucrt-an.patch \
  0004-configure-add-MACHDEP-and-platform-on-MINGW.patch \
  0005-build-Add-default-cross-configuration-for-MINGW.patch \
  0006-configure-enable-largefile-support-by-default-for-Mi.patch \
  0007-build-Add-PC-to-CPPFLAGS-and-to-SRCDIRS-on-Mingw.patch \
  0008-build-add-MINGW-support-for-posixmodule.patch \
  0009-exports.h-Add-support-for-MINGW.patch \
  0010-configure-add-options-so-that-shared-build-is-possib.patch \
  0011-build-Add-PYD_PLATFORM_TAG.patch \
  0012-build-Add-dynload_win-support-for-MinGW.patch \
  0013-build-Use-.pyd-extension-suffix-fix-import-lib-insta.patch \
  0014-build-Configure-SOABI-and-EXT_SUFFIX-for-MINGW.patch \
  0015-build-Define-MS_DLL_ID-for-sys.winver-on-MINGW.patch \
  0016-build-Ignore-main-program-for-frozen-scripts-on-MING.patch \
  0017-socketmodule-add-MINGW-support.patch \
  0018-build-enable-winreg-msvcrt-_winapi-winsound-and-_ove.patch \
  0019-sysconfig-make-_sysconfigdata.py-relocatable.patch \
  0020-sysconfig-treat-MINGW-builds-as-POSIX-builds.patch \
  0021-sysconfig-Change-the-get_platform-method-in-sysconfi.patch \
  0022-build-semi-native-build-sysconfig.patch \
  0023-ctypes-Add-support-for-stdcall-without-underscore.patch \
  0024-ctypes-add-suppor-for-ctypes.pythonapi-under-MINGW.patch \
  0025-ctypes-find_library-c-should-return-None-with-ucrt.patch \
  0026-site-Customize-for-MINGW.patch \
  0027-site-Change-user-site-packages-path-to-include-the-e.patch \
  0028-python-config-output-Windows-paths-for-the-shell-var.patch \
  0029-python-config-use-the-Python-variant-of-python-confi.patch \
  0030-mingw-prefer-unix-sep-if-MSYSTEM-environment-variabl.patch \
  0031-build-Remove-MAXPATHLEN-default.patch \
  0032-build-dont-link-with-gettext.patch \
  0033-use-gnu_printf-in-format.patch \
  0034-build-remove-usage-of-MS_COREDLL.patch \
  0035-getcompiler-expose-MINGW-toolchain-related-informati.patch \
  0036-build-fix-signal-module-build.patch \
  0037-build-build-winconsoleio-and-_testconsole.patch \
  0038-multiprocessing-expose-sem_unlink-to-fix-multiproces.patch \
  0039-build-link-win-resource-files-and-build-pythonw.patch \
  0040-pycore_fileutils-add-MINGW-support.patch \
  0041-configure-fix-inet_pton-check.patch \
  0042-importlib-bootstrap-path-sep.patch \
  0043-configure-set-MINGW-stack-reserve.patch \
  0044-tests-fix-test_bytes.patch \
  0045-timemodule-add-MINGW-support.patch \
  0046-configure-Disable-checks-for-dlopen-dlfcn.patch \
  0047-venvlauncher-Build-venvlauncher.exe-from-PC-launcher.patch \
  0048-venvlauncher-try-looking-for-the-versioned-.exe-firs.patch \
  0049-venvlauncher-Skip-find-python-in-Registry-for-mingw-.patch \
  0050-configure-don-t-check-for-clock_-functions.patch \
  0051-CI-test-the-build-and-add-some-mingw-specific-tests.patch \
  0052-configure-Default-to-without-c-locale-coercion-on-Wi.patch \
  0053-tests-Fix-some-failing-tests.patch \
  0054-build-def-VPATH-when-compiling-Python-sysmodule.c.patch \
  0055-configure-correctly-find-native-python.patch \
  0056-build-Add-extra-flags-for-_bootstrap_python.patch \
  0057-getpath-add-support-for-mingw.patch \
  0058-build-Don-t-build-_posixsubprocess-on-Windows.patch \
  0059-ssl-module-add-MINGW-support.patch \
  0060-configure-Include-winsock.h-when-checking-for-netdb-.patch \
  0061-configure-always-build-_multiprocessing-on-Windows.patch \
  0062-configure-build-mmap-module-on-win32.patch \
  0063-configure-set-BUILDEXEEXT-and-EXEEXT.patch \
  0064-configure-fix-building-some-test-modules.patch \
  0065-Always-convert-to-before-passing-though-pathcch-func.patch \
  0066-pylifecycle.h-remove-conflicting-_Py_CheckPython3-de.patch \
  0067-dynload_win-add-env-var-for-reverting-the-legacy-DLL.patch \
  0068-dynload_win-Port-GetPythonImport-to-MINGW.patch \
  0069-dynload_win-make-sure-to-only-use-backslashes-for-pa.patch \
  0070-dynload_win-don-t-run-_Py_CheckPython3-for-MINGW-bui.patch \
  0071-build-Build-and-install-libpython3.dll-stable-ABI.patch \
  0072-configure-define-_DEBUG-for-a-debug-build.patch \
  0073-configure-fix-multiprocessing-module.patch \
  0074-build-add-MINGW-support-for-selectmodule.patch \
  0075-configure-disable-various-modules-on-MINGW.patch \
  0076-configure-Add-libraries-to-fix-ctypes-on-MINGW.patch \
  0077-configure-Enable-_uuid-on-MINGW.patch \
  0078-configure-make-incompatible-pointer-types-a-warning.patch \
  0079-tests-test_makefile-normalize-path.patch \
  0080-Fix-include-naming-for-cross-build.patch \
  0081-Fix-format-warning.patch \
  0082-Fix-pragma-warnings.patch \
  0083-math-pyhash-MINGW-support.patch \
  0084-tests-Fix-test-for-library-name.patch \
  0085-dictobject-MINGW-support.patch \
  0086-build-Fix-export-Py_GetBuildInfo-symbol.patch \
  0087-build-Allow-profile-tests-failure.patch \
  0088-build-add-support-for-building-C-modules.patch \
  0089-build-build-fix-the-wmi-module.patch \
  0090-Fix-exports-for-_suggestions-module.patch \
  0091-compileall-Normalize-paths.patch \
  0092-configure-enable-64-bit-time-support-for-32-bit-buil.patch \
  0093-venv-also-install-the-versioned-launchers.patch \
  0094-configure-set-_WIN32_WINNT-version.patch \
  0095-tests-fix-sysconfig.test_get_platform.patch \
  0096-pycore_time-fix-missing-timeval.patch \
  0097-mmapmodule-define-DONT_USE_SEH.patch \
  0098-build-Add-ABIFLAGS-to-targets-when-needed.patch \
  0099-sysconfig-patch-nt-schemes-again.patch \
  0100-configure-define-_PYTHREAD_NAME_MAXLEN-for-MINGW.patch \
  0101-configure-allow-older-autoconf.patch \
  0102-tests-allow-sys.abiflags-to-exist.patch \
  0103-makesetup-make-sure-to-link-the-built-libpython.patch
 
  autoreconf -vfi
}

build() {
  declare -a _extra_config
  if check_option "debug" "n"; then
    _extra_config+=("--enable-optimizations")
    # Upstream defaults to -O3, so we can do too
    CFLAGS+=" -O3"
    # FIXME: https://github.com/msys2-contrib/cpython-mingw/issues/10
    if [[ $MINGW_PACKAGE_PREFIX == *-clang-* ]]; then
      _extra_config+=("--with-lto=full")
    fi
  else
    CFLAGS+=" -O0 -ggdb"
    CXXFLAGS+=" -O0 -ggdb"
    _extra_config+=("--with-pydebug")
  fi

  # FIXME: enable for all once GCC stops crashing
  if [[ ${MSYSTEM} == CLANG* ]]; then
    _extra_config+=("--with-tail-call-interp")
  fi

  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../Python-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --host=${MINGW_CHOST} \
    --build=${MINGW_CHOST} \
    --enable-shared \
    --with-system-expat \
    --with-system-ffi \
    --with-system-libmpdec \
    --without-ensurepip \
    --enable-loadable-sqlite-extensions \
    --with-tzpath=${MINGW_PREFIX}/share/zoneinfo \
    "${_extra_config[@]}"

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  # Some basic tests to ensure nothing major or MSYS2 specific features are broken
  ./python.exe "../Python-${pkgver}/mingw_smoketests.py"
  MSYSTEM= ./python.exe "../Python-${pkgver}/mingw_smoketests.py"
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  make -j1 install DESTDIR="${pkgdir}"

  # gdb pretty printers for debugging Python itself; to use:
  # python
  # sys.path.append('C:/msys64/mingw64/share/gdb/python3')
  # import python_gdb
  # reload(python_gdb)
  # end
  if [[ "${_primary_python}" == "yes" ]]; then
    [[ -d "${pkgdir}${MINGW_PREFIX}"/share/gdb/python3/ ]] || mkdir -p "${pkgdir}${MINGW_PREFIX}"/share/gdb/python3/
    cp -f python.exe-gdb.py "${pkgdir}${MINGW_PREFIX}"/share/gdb/python3/python_gdb.py
  fi

  # some useful "stuff"
  install -dm755 "${pkgdir}${MINGW_PREFIX}"/lib/python${_pybasever}/Tools/{i18n,scripts}
  install -m755 "${srcdir}/Python-${pkgver}"/Tools/i18n/{msgfmt,pygettext}.py "${pkgdir}${MINGW_PREFIX}"/lib/python${_pybasever}/Tools/i18n/
  install -m755 "${srcdir}/Python-${pkgver}"/Tools/scripts/{README,*py} "${pkgdir}${MINGW_PREFIX}"/lib/python${_pybasever}/Tools/scripts/

  # License
  install -Dm644 "${srcdir}/Python-${pkgver}/LICENSE" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}${_pybasever}/LICENSE"

  # PEP668
  install -Dm644 "${srcdir}/EXTERNALLY-MANAGED" -t "${pkgdir}${MINGW_PREFIX}/lib/python${_pybasever}/"

  # fixup shebangs
  for fscripts in idle3 idle${_pybasever} pydoc3 pydoc${_pybasever}; do
    sed -e '1 { s|^#!.*$|#!/usr/bin/env python'"${_pybasever}"'.exe| }' -i "${pkgdir}${MINGW_PREFIX}"/bin/${fscripts}
  done

  # default aliases for all scripts/binaries
  if [[ "${_primary_python}" == "yes" ]]; then
    # Default names are aliases for Python now
    cp "${pkgdir}${MINGW_PREFIX}"/bin/python3.exe "${pkgdir}${MINGW_PREFIX}"/bin/python.exe
    cp "${pkgdir}${MINGW_PREFIX}"/bin/python3w.exe "${pkgdir}${MINGW_PREFIX}"/bin/pythonw.exe
    cp "${pkgdir}${MINGW_PREFIX}"/bin/python3-config "${pkgdir}${MINGW_PREFIX}"/bin/python-config
    cp "${pkgdir}${MINGW_PREFIX}"/bin/idle3 "${pkgdir}${MINGW_PREFIX}"/bin/idle
    cp "${pkgdir}${MINGW_PREFIX}"/bin/pydoc3 "${pkgdir}${MINGW_PREFIX}"/bin/pydoc
  fi

  # delete anything that could conflict with the primary Python
  if [[ "${_primary_python}" != "yes" ]]; then
    rm "${pkgdir}${MINGW_PREFIX}"/bin/python3.exe
    rm "${pkgdir}${MINGW_PREFIX}"/bin/python3w.exe
    rm "${pkgdir}${MINGW_PREFIX}"/bin/python3-config
    rm "${pkgdir}${MINGW_PREFIX}"/bin/idle3
    rm "${pkgdir}${MINGW_PREFIX}"/bin/pydoc3
    rm "${pkgdir}${MINGW_PREFIX}"/bin/libpython3.dll
    rm "${pkgdir}${MINGW_PREFIX}"/lib/libpython3.dll.a
    rm "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/python3-embed.pc
    rm "${pkgdir}${MINGW_PREFIX}"/lib/pkgconfig/python3.pc
    rm "${pkgdir}${MINGW_PREFIX}"/share/man/man1/python3.1
  fi
}

sha256sums=('e02d9ac21cebda6e46435369744a92c65cc7cd8669697694122cf97ffacd1e53'
            '3981fed74ee7d43ad69bd67e634e03d7bf6890558a87062380112e195688728a'
            'de4e0ab9d3631e76f573912447a9c46156e250349d2870a842df5c90bcc24f9b'
            '29649ed5b5f3c020386761a6c613e9c769f11624a88ff844ceca8021ddddde74'
            '143e27b923acb2c36cc507f23a8c260fd898d5bb3b261726a2ecae9f505facf3'
            'c7e52ae6f8c518f146c6c6d72ce7f5a7f6288f6c428d8cd9a5353dabf4ee96dd'
            'b94329042cd28aed993f3bc00a27d0cdf67f2594502fbd3af03ecdbfc07531c9'
            '3486c50d9231b56877b51f8e34373f8c3b744f9282f8485312f3ba07a281186c'
            '3346eeb16afa30ac7b34003872b99657e2f0bd14d1988497d9ff7eedf460466c'
            '9813c28b3cd48182608a1f812ec55ffa25e4352a05f7e8cd17944042588a66d7'
            '51c0e12712be81effc4fc5771838a5c8625745aeb1730730359f03da4d1f8e7a'
            'e45d3cbd6503e0a56f73f1cbd1ab51a4b87859cf8d25c6d62a03345d5447e3a1'
            'f615dd731f39056b2550d9a14338dbf949027f327ebf348cfb33a5d98ff20a7e'
            'd20a716cc35bc010769775893f5adbb405020bbada6a8e43e7875512c8ef0db6'
            '180ee9c4239300bc6d582a708fa6a33db39dfef7419244e2bff05daae8260857'
            '67157d4b0aae45b002028f57b112229f493c431027553fe185f72d51531f80da'
            '641361bfa384dd88fcef6c804951481a43fd650e4f6812e59fb6d9d51fc31a54'
            'bc1239291bf309bf3e4753838553f2520331a422c6fc7ee870e38aea93e6391a'
            '62942223e27dba5080a91a44a21e55072506f25578cb8f5f02d8f5508011137b'
            'b078558c35df1b0c8b7d61c28abfbd7c59c46e26160b66ac9e987dbf6bce6076'
            'bb784b60de62b459301c0b8ce7939ecbd9ae40593b7a28fa39c57832059adc32'
            '086963c9184cc3d26d0c52f60aac2bff41fff21ad0c3a789ca863a0e7b5e00b8'
            '4cb5741077505fcb1c5056ec3c0dcf734e1e3bcbf6c895733ca9e1c7f7938ad0'
            '52549bc830b280bd90494547c04c8b3143d72ce3c3b267f0af4f34523327702d'
            '690f5266d91509b895feab387d1afa46f00bcbbb0e357596ad3c16afb2f65270'
            'bedc9f79457b86ea7a758edf64160de476ea035fc14676bf0d293565a16be29b'
            '9542f4b89a52d6abfbcbea8d43296796d2777dbfbdc69dbaecfb8a5386c0176c'
            '1c8bf31262800d1f7184524365ef381c99059f6cabaf83116c4f76f6a045c550'
            '53357ad53d332ddb4cc2903b941828a4885405cc32675278b7f018ca04c87447'
            'eba1e2711e4fac64524104992b504f66387d00a4bd488828352163c73037da64'
            '031b279ecd4b6127b744314b4b4c48cb5dfaeb5e008e648fdf301884fd3e2e59'
            'a13873668de7fda04feadc1c7753de96929215aeafd0e3684c827e3dccb11414'
            'd95facd08df911071ff66f18980dc0854dbc8a7328a0aece98ce9b78eb653496'
            '9cb754089bb171fe6b9155ded32de46d128aa32434471f64cf6890741a6a6c10'
            '6b1026edd65a4a9247dd7fdae3124e0a1eaad5e7ee223e3f155ef5415d1655a4'
            'b009ac090781a1a1fcffa1c9b207b549c3e2776273d8a5409737a1b7aa249988'
            '1f572593563ead34789525aa9fc4214269b5c744028bacc9a0d377a1c6f6c528'
            'a734270c92ceb50352988c719cbd06c6b86a31b5583929ca2954d24edef85379'
            '6c376ae0053c289c9ce2a3f3340ae9fe02d6b62414f3a09178c17f00826e770f'
            'f3ca3e4e013b9942d56845ae6df0126773369b3f17dcb396b989e086c3b8022f'
            '6c59eb1d0aca31293f4593322f1e05f01f879eec57ca5961acc272655fdc91a3'
            '8eeb7846f4e729ffb60e07e4d6a9e6bd14810e3a39b6a2ffc5b3470e5857e851'
            '43ae4d87b1a4e0b05bf455c183e312a611574387c2b615e23c93c9bf59325d77'
            '13b9d3cdccc724949e285d9c5a89c4fccb86f9e0a22e91e2a5d70e3f3854caa3'
            '84e4d33c9b92f4381e7979309e22c295fc102508bdc30f3a58d8fe2325b4fdbb'
            'a0fd8c318f133d5f59c4b8961b36e829be77d06cfd8bde2151d765f24af78421'
            'a5c9b5ead98433b3e56cbce407d0f7378653e623a8df4de7f2831e5101e73f80'
            'f42a24460ae7ec0013c48ce458ddc927b2e18bec13fafb378ececf969e48411c'
            '4c4e1e32d7f9373961e592045fa8deb2714a6901e605b74873991825e9165a42'
            '74d4ba55c08f36cf326c626bc5dfb703619bf20ab58468f0b1ca74905c43d7e8'
            '61c2cacc4668d37bb86a40b2812197596dac26eed1c43b63f18d474a6b51e58e'
            '3968678080b105da3c1db9b0f674567ebbdbc5f7f6411dd05f913dbe3ef69581'
            '68de2cdf4efd01382426a0d1c828f96c2f63ebbb0f005012cfb376c5439e8f22'
            '3e87494b2dd6d8ab9648842a275972fb2a44018d12a672de30ead3e6e520543c'
            '7979150805e045044d383702d9899130f0996cfacc71f16e6f76d6ca370e1ee7'
            'e864b51a8a3ebd64b8b7c29975aebd689ddf55de502cf53cf1c6ea0c3ded860b'
            'fc9dac4577f93c754764b0977ea9069e2a85d3c2640693892e257e7f6b841cb1'
            '09ef0f179256e967989288f0459ded9280d9a51f6ebdb0fd6058c613ff29393f'
            '205eeaf9a4c4c3f8b519288f73aab3044b4a7126f4bcec62f61e879e4b58561b'
            '51936a445157abeea12694aa67ca664c571c7f7be940b3bb310f65efaa1c5965'
            'ddab3d391673e0cbdd43b8201b8df629e401ff115b68f9560edc3ddfd045670b'
            '800d9e4e4c412ccdf927120ba09d67b55d8ddaa4e1f2bef444d3636fab7046de'
            'd0df19e42f3e4ffa0f16bbd86879cbf683082b1180cc9af799eb8c7011533548'
            '6d60a08ef80d49af5a533a89d8702e400eae9044956eda04d6c0cc34c4034d5c'
            '98c2b95715dd081920b2305c66d6a69e261f05b5c669cf3d938565da4e2c0463'
            '55770541cc6f85f9115beaf4f283236809e66a965bf0eaf3fdf3ed222c6a9257'
            'dcb66ead8db37591efbf1d24b601c0e7119b7f1c6ce12f47a17d71e107ee2dea'
            'a8fe3e91fe92ac02d445dc7741169cb193503c6346ed47971e286e1b2b03bc57'
            '362d9f2a1382a1a1d6a24bc0846826162df8792dc65c3b2eed7583e0a0ec1212'
            '91d31334a34b5f3a1c5b769cbcfe5a36f04a0d65f97653f1062a67334b28948e'
            '11aaa523e2527052e269d596175275fb20b20a2a8834cfa8ff0a59a352630591'
            '7736169a7511056b31174378545373d4af4b7baa972d558e5018e0b86ada3689'
            '45882666d4c0557700d2e24f2ce21d3045170e556a2b9ca966965d488a823b01'
            '5452c34756beb6489caadbca7bce125b4f1ec606e30f652553f1270a71e06222'
            '3774c1ee314df6f9e1b7c5ff3645e0f80505ef54253010bbc260556c47d59fca'
            '9609f3573a446a89598eb908b4fcd51fe3ec48186bbe4771846140914550aac1'
            '09ea7455ff81ca9aa05f5835195281b0cd4eee204ee578bd3e18c40f42478279'
            '60ede122c42712e75d707e6f6eb316bdc6ef99c6d7923414c073fac1ac8c301c'
            '9fad128a5539b4045269dd221fe77dcf8194fe22f57477c00176be83dc30f283'
            '7b8b1b657837ccd8a2419ccf89ee46402c6cf83e19321cf273f84c3740e42901'
            '4bb537ed6c68e3e847cb24682e7f13d1e979f03eb10619816d605e65ee90a387'
            '3ef4d1f74de2ed270878cbc32fbf57805212dd7909c08542e7729936d105f75f'
            'b11482de5d6c32de4a79e407ba315344edfeccbd863f86f7b0ccba6695b775b2'
            '64fe80312706d0a1ef48dd53d7c9c80921e0f76add25f0a42e64e69b3b996cf8'
            '4efd858f626c773632184a99f8ee7f1cfdab1f951026da676875971778e782ad'
            '44601bd47ba500d9c81de17748ae4b237cf62d2ecfce521e0bb905c549645a76'
            '2ab7ee036dddb1639ae22989f86fd362e543cd92747998296ee50b9cb3027dd0'
            '5030afc61f52c91b959c10091382dd6e88061d6b41d622551c8daedf79bcc496'
            'aa06815c5498a4c2b0bfd2bda5bad26726117bf4e2e7abf28c8108411e499f00'
            '3afbda9dce4ab12a5908b3ad1d1120d114261aa4ddc84daffaf039c927eab957'
            '5b6f79d0b6ff0ce64989c4a1633cb544e0fa329dadff2f2bd49d56aaeef1efe5'
            '25d63e7d02baf9553259017092b16cbb207786f14584027b36a669f8c643fa70'
            '55d2b18be08250ed5c5101554243b9553c2d54ebf71483b7ce9244fa9dd52deb'
            '9601d02b12840f08862077e82cc34f18d4ed1b5cd9e9349a932eddf4dc200b63'
            '7a5873aa1f2bdb562270ecbce4db81af5b56bf0e8003afdc053235e2dc69e11d'
            'b8f4b7cd802d1af588e5dd1d3ad87a5ae2ab999826713064e61e24c6e9a05508'
            'd5f1c7e9f59dd1d5f1ff559e386fcda572d98cf4913b52f37d85da8e4c0fcf2e'
            'faa73fe0c51433e6190b1abdcb1cdf45ba7fc51d6510ebfdaa7653bbbad36f3b'
            'e8d9b37014dfd52971b8ddee415e0a8601a631836312623f7dd6481a43e6d4f8'
            '3ac2bc48047fb5bc6701066dd357b8506ca8b156e9c9ea4a395535f63c0efe48'
            '8e67e1632ecc5aea494d4b9728293873c62c91048e1b108ad084b9c16a46453b'
            '20746912da63add69fe7f131d950cfb66a29299a868e2e35d60273196703b3a8'
            'bcb7787d2c7cc07aab8270b26ab3e0c07e684d1fdcc7c21f1ae8f0ee623c6e0e'
            'e0a940b23bd60710be20fe8d017e6fbf7db1d7da961c62f73ec004bfdcf5e130'
            '371481cf319627cc22c578ad43f0ca6f1d3c74f5baf7daf597591a0e4e4628b7')
