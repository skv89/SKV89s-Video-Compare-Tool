# Maintainer: Alexey Pavlov <alexpux@gmail.com>
# Contributor: Renato Silva <br.renatosilva@gmail.com>

_realname=libtiff
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}"
         $([[ ${CARCH} == i686 ]] || echo "${MINGW_PACKAGE_PREFIX}-${_realname}-docs"))
pkgver=4.7.2
pkgrel=2
pkgdesc="Library for manipulation of TIFF images (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://libtiff.gitlab.io/libtiff/"
msys2_repository_url="https://gitlab.com/libtiff/libtiff"
msys2_references=(
  'cygwin: tiff'
  'gentoo: media-libs/tiff'
  "cpe: cpe:/a:libtiff:libtiff"
  "cpe: cpe:/a:remotesensing:libtiff"
  "cpe: cpe:/a:simplesystems:libtiff"
)
license=('spdx:MIT')
depends=("${MINGW_PACKAGE_PREFIX}-cc-libs"
         "${MINGW_PACKAGE_PREFIX}-jbigkit"
         "${MINGW_PACKAGE_PREFIX}-lerc"
         "${MINGW_PACKAGE_PREFIX}-libjpeg-turbo"
         "${MINGW_PACKAGE_PREFIX}-libdeflate"
         "${MINGW_PACKAGE_PREFIX}-libwebp"
         "${MINGW_PACKAGE_PREFIX}-xz"
         "${MINGW_PACKAGE_PREFIX}-zlib"
         "${MINGW_PACKAGE_PREFIX}-zstd")
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-autotools"
             $([[ ${CARCH} == i686 ]] || echo "${MINGW_PACKAGE_PREFIX}-python-sphinx"))
source=(https://download.osgeo.org/libtiff/tiff-${pkgver}.tar.gz
        0002-libtiff-install-headers.patch)
sha256sums=('672bd7d10aee4606171afb864f3570b83340f6a33e2c186dc0512f7145ffdf6a'
            '493742947c8667655b6b89f2d7d27e92e1438a490ed86f50811112394b432a12')

prepare() {
  cd tiff-${pkgver}
  patch -p1 -i "${srcdir}/0002-libtiff-install-headers.patch"

  # autoreconf to get updated libtool files for clang support
  autoreconf -fiv
}

build() {
  export CFLAGS+=" -fno-strict-aliasing"
  export CXXFLAGS+=" -fno-strict-aliasing"

  mkdir -p "${srcdir}/build-${MSYSTEM}-static" && cd "${srcdir}/build-${MSYSTEM}-static"

  ../tiff-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --enable-static \
    --disable-shared \
    --enable-cxx \
    --enable-jbig \
    --enable-lerc \
    --enable-libdeflate \
    --enable-webp \
    --disable-docs

  make

  declare -a extra_config
  if [[ ${CARCH} == i686 ]]; then
    extra_config+=("--disable-docs")
  fi

  mkdir -p "${srcdir}/build-${MSYSTEM}-shared" && cd "${srcdir}/build-${MSYSTEM}-shared"

  ../tiff-${pkgver}/configure \
    --prefix=${MINGW_PREFIX} \
    --disable-static \
    --enable-shared \
    --enable-cxx \
    --enable-jbig \
    --enable-lerc \
    --enable-libdeflate \
    --enable-webp \
    "${extra_config[@]}"

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}-static"
  make check || true

  cd "${srcdir}/build-${MSYSTEM}-shared"
  make check || true
}

package_libtiff() {
  make DESTDIR="${pkgdir}" -C "${srcdir}/build-${MSYSTEM}-static" install
  make DESTDIR="${pkgdir}" -C "${srcdir}/build-${MSYSTEM}-shared" install

  # License
  # See https://fedoraproject.org/wiki/Licensing:MIT#Hylafax_Variant
  install -Dm644 "${srcdir}/tiff-${pkgver}/LICENSE.md" "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE.md"

  if [[ ${CARCH} != i686 ]]; then
    # split docs
    mkdir -p dest${MINGW_PREFIX}/share
    mv "${pkgdir}${MINGW_PREFIX}"/share/doc dest${MINGW_PREFIX}/share/doc
  fi
}

package_libtiff-docs() {
  pkgdesc+=" (documentation)"
  depends=()

  mv dest/* "${pkgdir}"
}

# template start; name=mingw-w64-splitpkg-wrappers; version=1.0;
# vim: set ft=bash :

# generate wrappers
for _name in "${pkgname[@]}"; do
  _short="package_${_name#${MINGW_PACKAGE_PREFIX}-}"
  _func="$(declare -f "${_short}")"
  eval "${_func/#${_short}/package_${_name}}"
done
# template end;
