# Maintainer: Alexey Pavlov <alexpux@gmail.com>

_realname=dlfcn
pkgbase=mingw-w64-${_realname}
pkgname="${MINGW_PACKAGE_PREFIX}-${_realname}"
pkgver=1.4.2
pkgrel=1
pkgdesc="A wrapper for dlfcn to the Win32 API (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url="https://github.com/dlfcn-win32/dlfcn-win32"
license=('spdx:MIT')
makedepends=("${MINGW_PACKAGE_PREFIX}-cc"
             "${MINGW_PACKAGE_PREFIX}-cmake"
             "${MINGW_PACKAGE_PREFIX}-ninja")
source=(${_realname}-${pkgver}.tar.gz::https://github.com/dlfcn-win32/dlfcn-win32/archive/v${pkgver}.tar.gz)
sha256sums=('f61a874bc9163ab488accb364fd681d109870c86e8071f4710cbcdcbaf9f2565')

build() {
  declare -a extra_config
  if check_option "debug" "n"; then
    extra_config+=("-DCMAKE_BUILD_TYPE=Release")
  else
    extra_config+=("-DCMAKE_BUILD_TYPE=Debug")
  fi

  for SHARED in YES NO; do
    mkdir -p "${srcdir}/build-${MSYSTEM}-${SHARED}" && cd "${srcdir}/build-${MSYSTEM}-${SHARED}"
    MSYS2_ARG_CONV_EXCL="-DCMAKE_INSTALL_PREFIX=" \
      ${MINGW_PREFIX}/bin/cmake.exe \
        -GNinja \
        -DBUILD_SHARED_LIBS=${SHARED} \
        -DCMAKE_INSTALL_PREFIX="${MINGW_PREFIX}"  \
        -DBUILD_TESTS=OFF \
        ../${_realname}-win32-${pkgver}
    ${MINGW_PREFIX}/bin/cmake.exe --build .
  done
}

check() {
  for SHARED in YES NO; do
    msg "Test: MSYSTEM variable: ${MSYSTEM}"
    msg "Test: Shared version:   ${SHARED}"
    cd "${srcdir}/build-${MSYSTEM}-${SHARED}"
    ${MINGW_PREFIX}/bin/cmake -DBUILD_TESTS=ON ../${_realname}-win32-${pkgver}
    ${MINGW_PREFIX}/bin/cmake --build .
    ${MINGW_PREFIX}/bin/ctest
  done
}

package() {
  for SHARED in NO YES; do
    cd "${srcdir}/build-${MSYSTEM}-${SHARED}"
    DESTDIR="${pkgdir}" ${MINGW_PREFIX}/bin/cmake.exe --install .
  done
  cd "${srcdir}"/dlfcn-win32-${pkgver}
  install -Dm644 README.md "${pkgdir}${MINGW_PREFIX}/share/doc/${_realname}/README.md"
  install -Dm644 COPYING "${pkgdir}${MINGW_PREFIX}/share/licenses/${_realname}/LICENSE"
}
