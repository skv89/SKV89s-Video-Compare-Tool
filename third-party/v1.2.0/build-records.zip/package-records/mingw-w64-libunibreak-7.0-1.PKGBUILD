# Maintainer: Christoph Reiter <reiter.christoph@gmail.com>

_realname=libunibreak
pkgbase=mingw-w64-${_realname}
pkgname=("${MINGW_PACKAGE_PREFIX}-${_realname}")
pkgver=7.0
pkgrel=1
pkgdesc="An implementation of the line breaking algorithm as described in Unicode 5.2.0 Standard Annex 14, Revision 24 (mingw-w64)"
arch=('any')
mingw_arch=('mingw32' 'mingw64' 'ucrt64' 'clang64' 'clangarm64')
url='https://github.com/adah1972/libunibreak/'
msys2_repository_url='https://github.com/adah1972/libunibreak'
license=('spdx:Zlib')
makedepends=("${MINGW_PACKAGE_PREFIX}-autotools"
             "${MINGW_PACKAGE_PREFIX}-cc")
source=("https://github.com/adah1972/libunibreak/archive/libunibreak_${pkgver//./_}/$_realname-$pkgver.tar.gz")
sha256sums=('e4cb1a0d9aebb129c9856ec75e3d98e675997e385cce4e0106ef8f68e09afaa3')

prepare() {
  mv "${srcdir}/${_realname}-${_realname}_${pkgver//./_}" "${srcdir}/${_realname}-${pkgver}"
  cd "${srcdir}/${_realname}-${pkgver}"

  ./bootstrap
}

build() {
  cd "${srcdir}/${_realname}-${pkgver}"
  mkdir -p "${srcdir}/build-${MSYSTEM}" && cd "${srcdir}/build-${MSYSTEM}"

  ../"${_realname}-${pkgver}"/configure \
    --prefix="${MINGW_PREFIX}" \
    --build="${MINGW_CHOST}" \
    --host="${MINGW_CHOST}" \
    --target="${MINGW_CHOST}" \
    --enable-static \
    --enable-shared

  make
}

check() {
  cd "${srcdir}/build-${MSYSTEM}"

  make check
}

package() {
  cd "${srcdir}/build-${MSYSTEM}"

  make install DESTDIR="${pkgdir}"

  install -Dm644 "${srcdir}"/${_realname}-${pkgver}/LICENCE \
    "${pkgdir}"${MINGW_PREFIX}/share/licenses/${_realname}/LICENCE
}
